# Time to Manager 26/27

Telegram football manager bot with local football data.

## Bothost

Set the environment variable `BOT_TOKEN` to the token from @BotFather. The bot uses Telegram polling and does not require a webhook or a public URL.

Start command:

```bash
python bot.py
```

Logs are written to stdout and `logs/bot.log`.

Do not commit your real token.
