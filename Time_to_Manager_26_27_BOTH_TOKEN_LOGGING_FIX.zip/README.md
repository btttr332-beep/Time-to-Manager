# Time to Manager 26/27

Telegram football manager game for group careers.

## What is included
- Telegram bot source (`bot.py`)
- Local football database (`data/football_database.json`)
- League configuration (`data/leagues.json`)
- Game engine (`game/engine.py`)
- Local data provider (`game/provider.py`)
- Optional web files in `web/`
- Help menu with bot commands and gameplay sections

## Data architecture
- Football data is stored locally in the repository.
- No runtime football-data API is required.
- Second divisions remain in the database but are hidden from gameplay with `playable: false`.
- Player cards use the stored player records and game attributes.
- Match simulation uses team strength, player OVR, morale, form, fitness and other game factors.

## Run locally

### 1. Create a Telegram bot
Create the bot with `@BotFather` and copy its token.

### 2. Configure the token
Copy `.env.example` to `.env` and set your token:

```env
BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN
```

The `.env` file is ignored by Git and must never be committed.

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Start the bot

```bash
python bot.py
```

## GitHub
Upload the contents of this directory to your repository. Do **not** upload `.env`, `__pycache__` or generated `.pyc` files.

## Bot hosting
For a Python host such as BotHost, upload the repository/project files, install `requirements.txt`, set the `BOT_TOKEN` environment variable and use:

```bash
python bot.py
```
