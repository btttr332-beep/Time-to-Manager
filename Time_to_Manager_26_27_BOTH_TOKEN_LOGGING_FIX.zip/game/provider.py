import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DB_FILE = ROOT / 'data' / 'football_database.json'
LEAGUES_FILE = ROOT / 'data' / 'leagues.json'

class SquadProvider:
    """Offline embedded football database. No network access."""
    def __init__(self):
        self.database = json.loads(DB_FILE.read_text(encoding='utf-8'))
        self.leagues = json.loads(LEAGUES_FILE.read_text(encoding='utf-8'))['leagues']

    def load_league(self, key: str, force: bool = False) -> dict[str, Any]:
        if key not in self.database['leagues']:
            raise KeyError(f'Embedded league not found: {key}')
        return self.database['leagues'][key]

    def load(self, force: bool = False) -> dict[str, Any]:
        return self.database

    def refresh_all(self) -> dict[str, Any]:
        # Kept as a compatibility method, but deliberately does not access the internet.
        return self.database
