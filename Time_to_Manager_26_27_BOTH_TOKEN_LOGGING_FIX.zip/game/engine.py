import random
from dataclasses import dataclass

POS_MAP={'G':'GK','GK':'GK','D':'DF','DF':'DF','M':'MF','MF':'MF','F':'FW','FW':'FW'}
FORMATIONS={'4-3-3':(1,4,3,3),'4-2-3-1':(1,4,5,1),'4-4-2':(1,4,4,2),'3-5-2':(1,3,5,2),'3-4-3':(1,3,4,3),'5-3-2':(1,5,3,2)}
STYLES={'Balanced':0,'Possession':1,'Pressing':2,'Counter':-1,'Defensive':-2}
@dataclass
class MatchResult:
    home:str; away:str; hs:int; ascore:int; scorers_home:list; scorers_away:list
class GameEngine:
    def __init__(self,db=None): self.db=db
    def player_ovr(self,p): return int(p.get('ovr') or 70)
    def player_power(self,p):
        o=self.player_ovr(p); morale=int(p.get('morale') or 70); form=int(p.get('form') or 70); fit=int(p.get('fitness') or 80)
        return o + (morale-70)*0.10 + (form-70)*0.12 + (fit-80)*0.08
    def squad_power(self,players,formation='4-3-3',style='Balanced'):
        vals=sorted([self.player_power(p) for p in players],reverse=True)[:11]
        if not vals:return 60
        return sum(vals)/len(vals)+STYLES.get(style,0)*0.7
    def play(self,home,away,hp,ap,home_adv=2.5):
        diff=(hp+home_adv)-ap
        lam_h=max(.20,1.35+diff/18); lam_a=max(.15,1.05-diff/22)
        hs=min(7,max(0,int(random.gauss(lam_h,.95)))); a=min(7,max(0,int(random.gauss(lam_a,.9))))
        return MatchResult(home,away,hs,a,[],[])
    def game_value(self,age,pos,market_hint=None):
        if market_hint and market_hint>0:return int(market_hint)
        base={'GK':3500000,'DF':6500000,'MF':9000000,'FW':12000000}.get(pos,7000000); age=age or 24
        if age<21:base*=1.15
        elif age>30:base*=.72
        return int(base)
    def derive_attributes(self,p):
        age=p.get('age') or 24; pos=POS_MAP.get(p.get('position','M'),'MF'); seed=sum(ord(c) for c in str(p.get('id') or p.get('name')))
        ovr=max(62,min(91,67+(seed%19)+(3 if age<=24 else 0))); potential=max(ovr,min(94,ovr+(8 if age<=20 else 5 if age<=23 else 2 if age<=27 else 0)))
        value=self.game_value(age,pos,p.get('market_value')); return {**p,'pos':pos,'ovr':ovr,'potential':potential,'value':value,'salary':max(15000,int(value*.018)),'form':70+(seed%26),'morale':75+(seed%21),'fitness':88+(seed%13)}
