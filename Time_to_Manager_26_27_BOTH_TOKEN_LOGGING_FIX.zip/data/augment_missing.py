import json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'data'/'football_database.json'
LEAGUES=ROOT/'data'/'leagues.json'
d=json.loads(DB.read_text(encoding='utf8'))
meta=json.loads(LEAGUES.read_text(encoding='utf8'))['leagues']

def pid(key,club,name): return int(hashlib.sha1(f'{key}:{club}:{name}'.encode()).hexdigest()[:8],16)
def tid(key,club): return int(hashlib.sha1(f'{key}:{club}'.encode()).hexdigest()[:8],16)
def add_league(key, entries):
    out=[]
    existing={x['name'] for x in d['leagues'].get(key,{}).get('teams',[])}
    for club, stadium, city, cap, players in entries:
        if club in existing: continue
        ps=[]
        for name,pos in players:
            ps.append({'id':pid(key,club,name),'name':name,'short_name':name,'position':pos,'age':None,'country':None,'jersey':None,'photo':''})
        out.append({'id':tid(key,club),'name':club,'short_name':club,'logo':'','stadium':{'name':stadium,'city':city,'capacity':cap},'players':ps})
    base=d['leagues'].get(key,dict(meta[key]))
    base.update({'name':meta[key]['name'],'country':meta[key]['country'],'season':'2026/27','teams':d['leagues'].get(key,{}).get('teams',[])+out})
    d['leagues'][key]=base

# 2026/27 public squad snapshots used only to fill the previously empty local leagues.
# They are embedded; the game never fetches them at runtime.
eng={
'Arsenal':('Emirates Stadium','London',60704,[('David Raya','GK'),('William Saliba','DF'),('Ben White','DF'),('Gabriel Magalhaes','DF'),('Jurrien Timber','DF'),('Martin Odegaard','MF'),('Declan Rice','MF'),('Bukayo Saka','FW'),('Eberechi Eze','MF'),('Viktor Gyokeres','FW'),('Kai Havertz','FW')]),
'Aston Villa':('Villa Park','Birmingham',42682,[('Zion Suzuki','GK'),('Matty Cash','DF'),('Victor Lindelof','DF'),('Tyrone Mings','DF'),('Pau Torres','DF'),('Ross Barkley','MF'),('John McGinn','MF'),('Boubacar Kamara','MF'),('Nicolas Jackson','FW'),('Emiliano Buendia','MF'),('Alejandro Garnacho','FW')]),
'AFC Bournemouth':('Vitality Stadium','Bournemouth',11329,[('Djordje Petrovic','GK'),('Julian Araujo','DF'),('Adrien Truffert','DF'),('Lewis Cook','MF'),('James Hill','DF'),('Tyler Adams','MF'),('Alex Scott','MF'),('David Brooks','FW'),('Evanilson','FW'),('Justin Kluivert','FW'),('Amine Adli','FW')]),
'Brentford':('Gtech Community Stadium','London',17250,[('Caoimhin Kelleher','GK'),('Aaron Hickey','DF'),('Rico Henry','DF'),('Sepp van den Berg','DF'),('Kristoffer Ajer','DF'),('Mathias Jensen','MF'),('Vitaly Janelt','MF'),('Mikkel Damsgaard','MF'),('Kevin Schade','FW'),('Igor Thiago','FW'),('Callum Wilson','FW')]),
'Brighton & Hove Albion':('Amex Stadium','Brighton',31872,[('Bart Verbruggen','GK'),('Lewis Dunk','DF'),('Pascal Struijk','DF'),('Olivier Boscagli','DF'),('Ferdi Kadioglu','DF'),('Mats Wieffer','MF'),('Pascal Gross','MF'),('Kaoru Mitoma','FW'),('Georginio Rutter','FW'),('Yankuba Minteh','FW'),('Evan Ferguson','FW')]),
'Chelsea':('Stamford Bridge','London',40343,[('Emiliano Martinez','GK'),('Wesley Fofana','DF'),('Levi Colwill','DF'),('Jorrel Hato','DF'),('Reece James','DF'),('Moises Caicedo','MF'),('Jordan Henderson','MF'),('Cole Palmer','MF'),('Pedro Neto','FW'),('Jamie Gittens','FW'),('Joao Pedro','FW')]),
'Coventry City':('Coventry Building Society Arena','Coventry',32609,[('Ben Wilson','GK'),('Ethan Pinnock','DF'),('Bobby Thomas','DF'),('Joel Latibeaudiere','DF'),('Jake Bidwell','DF'),('Matt Grimes','MF'),('Frank Onyeka','MF'),('Gustavo Hamer','MF'),('Haji Wright','FW'),('Ellis Simms','FW'),('Taiwo Awoniyi','FW')]),
'Crystal Palace':('Selhurst Park','London',26309,[('Dean Henderson','GK'),('Tyrick Mitchell','DF'),('Axel Disasi','DF'),('Chris Richards','DF'),('Takehiro Tomiyasu','DF'),('Jefferson Lerma','MF'),('Adam Wharton','MF'),('Daichi Kamada','MF'),('Yeremy Pino','FW'),('Eddie Nketiah','FW'),('Jean-Philippe Mateta','FW')]),
'Everton':('Hill Dickinson Stadium','Liverpool',52888,[('Jordan Pickford','GK'),('Jarrad Branthwaite','DF'),('James Tarkowski','DF'),('Jake OBrien','DF'),('Vitalii Mykolenko','DF'),('Christian Norgaard','MF'),('Kiernan Dewsbury-Hall','MF'),('James Garner','MF'),('Jack Grealish','FW'),('Brennan Johnson','FW'),('Thierno Barry','FW')]),
'Fulham':('Craven Cottage','London',29589,[('Bernd Leno','GK'),('Kenny Tete','DF'),('Joachim Andersen','DF'),('Calvin Bassey','DF'),('Antonee Robinson','DF'),('Sander Berge','MF'),('Harrison Reed','MF'),('Alex Iwobi','MF'),('Gonzalo Garcia','FW'),('Rodrigo Muniz','FW'),('Oscar Bobb','FW')]),
'Hull City':('MKM Stadium','Hull',25586,[('Jack Butland','GK'),('Lewie Coyle','DF'),('Charlie Hughes','DF'),('Semi Ajayi','DF'),('Matt Targett','DF'),('Hidemasa Morita','MF'),('Regan Slater','MF'),('Eliot Matazo','MF'),('Mohamed Belloumi','FW'),('Oliver McBurnie','FW'),('Mohamed-Ali Cho','FW')]),
'Ipswich Town':('Portman Road','Ipswich',30311,[('Alex Palmer','GK'),('Darnell Furlong','DF'),('Leif Davis','DF'),('Cedric Kipre','DF'),('Issa Diop','DF'),('Azor Matusiwa','MF'),('Sasa Lukic','MF'),('Exequiel Palacios','MF'),('Julio Enciso','FW'),('Chuba Akpom','FW'),('Daizen Maeda','FW')]),
'Leeds United':('Elland Road','Leeds',40204,[('James Trafford','GK'),('Jayden Bogle','DF'),('Gabriel Gudmundsson','DF'),('Joe Rodon','DF'),('Jaka Bijol','DF'),('Ethan Ampadu','MF'),('Anton Stach','MF'),('Sean Longstaff','MF'),('Harry Wilson','FW'),('Dominic Calvert-Lewin','FW'),('Noah Okafor','FW')]),
'Liverpool':('Anfield','Liverpool',61276,[('Alisson Becker','GK'),('Virgil van Dijk','DF'),('Joe Gomez','DF'),('Milos Kerkez','DF'),('Jeremie Frimpong','DF'),('Ryan Gravenberch','MF'),('Florian Wirtz','MF'),('Dominik Szoboszlai','MF'),('Mohamed Salah','FW'),('Alexander Isak','FW'),('Hugo Ekitike','FW')]),
'Manchester City':('Etihad Stadium','Manchester',55097,[('Gianluigi Donnarumma','GK'),('Ruben Dias','DF'),('Marc Guehi','DF'),('Josko Gvardiol','DF'),('Rayan Ait-Nouri','DF'),('Mateo Kovacic','MF'),('Enzo Fernandez','MF'),('Rayan Cherki','MF'),('Erling Haaland','FW'),('Jeremy Doku','FW'),('Phil Foden','FW')]),
'Manchester United':('Old Trafford','Manchester',74310,[('Senne Lammens','GK'),('Diogo Dalot','DF'),('Matthijs de Ligt','DF'),('Lisandro Martinez','DF'),('Leny Yoro','DF'),('Bruno Fernandes','MF'),('Mason Mount','MF'),('Carlos Baleba','MF'),('Bryan Mbeumo','FW'),('Matheus Cunha','FW'),('Benjamin Sesko','FW')]),
'Newcastle United':('St James Park','Newcastle',52387,[('Nick Pope','GK'),('Sven Botman','DF'),('Fabian Schar','DF'),('Dan Burn','DF'),('Tino Livramento','DF'),('Bruno Guimaraes','MF'),('Joelinton','MF'),('Jacob Ramsey','MF'),('Anthony Elanga','FW'),('Yoane Wissa','FW'),('Harvey Barnes','FW')]),
'Nottingham Forest':('City Ground','Nottingham',30576,[('Matz Sels','GK'),('Murillo','DF'),('Nikola Milenkovic','DF'),('Neco Williams','DF'),('Ola Aina','DF'),('Ibrahim Sangare','MF'),('Morgan Gibbs-White','MF'),('Nicolas Dominguez','MF'),('Callum Hudson-Odoi','FW'),('Chris Wood','FW'),('Liam Delap','FW')]),
'Sunderland':('Stadium of Light','Sunderland',49000,[('Robin Roefs','GK'),('Daniel Ballard','DF'),('Kevin Danso','DF'),('Nordi Mukiele','DF'),('Reinildo Mandava','DF'),('Granit Xhaka','MF'),('Enzo Le Fee','MF'),('Noah Sadiki','MF'),('Chris Rigg','MF'),('Brian Brobbey','FW'),('Wilson Isidor','FW')]),
'Tottenham Hotspur':('Tottenham Hotspur Stadium','London',62850,[('Brandon Austin','GK'),('Andrew Robertson','DF'),('Tosin Adarabioyo','DF'),('Marcos Senesi','DF'),('Pedro Porro','DF'),('Conor Gallagher','MF'),('Sandro Tonali','MF'),('Xavi Simons','MF'),('James Maddison','MF'),('Mohammed Kudus','FW'),('Dominic Solanke','FW')])}
add_league('eng_pl',[(c,*v) for c,v in eng.items()])

ger={
'FC Bayern München':('Allianz Arena','München',75024,['Manuel Neuer','Sven Ulreich','Jonas Urbig','Dayot Upamecano','Minjae Kim','Jonathan Tah','Alphonso Davies','Hiroki Ito','Josip Stanisic','Joshua Kimmich','Jamal Musiala','Harry Kane']),
'Borussia Dortmund':('Signal Iduna Park','Dortmund',81365,['Gregor Kobel','Patrick Drewes','Waldemar Anton','Nico Schlotterbeck','Ramy Bensebaini','Julian Ryerson','Jobe Bellingham','Felix Nmecha','Carney Chukwuemeka','Marcel Sabitzer','Serhou Guirassy','Maximilian Beier']),
'1. FC Union Berlin':('An der Alten Försterei','Berlin',22012,['Frederik Ronnow','Carl Klaus','Felix Uduokhai','Marvin Friedrich','Leopold Querfeld','Josip Juranovic','Rani Khedira','Andras Schafer','Tim Skarke','Robert Skov','Oliver Burke','Emmanuel Latte Lath']),
'Borussia Mönchengladbach':('Borussia Park','Mönchengladbach',54042,['Moritz Nicolas','Tobias Sippel','Fabio Chiarodia','Kevin Diks','Ko Itakura','Joe Scally','Kevin Stoger','Florian Neuhaus','Franck Honorat','Nicolas Kuhn','Tim Kleindienst','Shuto Machino']),
'Hamburger SV':('Volksparkstadion','Hamburg',57000,['Daniel Heuer Fernandes','Sander Tangvik','David Moller Wolfe','Zakaria El Ouahdi','Warmed Omari','Jordan Torunarigha','Miro Muheim','Albert Sambi Lokonga','Fabio Vieira','Albert Gronbaek','Yussuf Poulsen','Patson Daka']),
'1. FC Köln':('RheinEnergieSTADION','Köln',50000,['Marvin Schwabe','Ron-Robert Zieler','Joel Schmied','Borna Sosa','Timo Hubers','Gideon Mensah','Ellyes Skhiri','Isak Johannesson','Saïd El Mala','Linton Maina','Luca Waldschmidt','Thijs Dallinga']),
'SV Werder Bremen':('Weserstadion','Bremen',42100,['Karl Hein','Markus Kolke','Olivier Deman','Niklas Stark','Mitchell Weiser','Marco Friedl','Jens Stage','Senne Lynen','Ludovit Reis','Niclas Fullkrug','Keke Topp','Justin Njinmah']),
'FC Schalke 04':('VELTINS-Arena','Gelsenkirchen',62271,['Loris Karius','Kevin Muller','Hasan Kurucay','Timo Becker','Robin Gosens','Nikola Katic','Ron Schallenberg','Dejan Ljubicic','Adil Aouchiche','Edin Dzeko','Moussa Sylla','Kenan Karaman']),
'SV Elversberg':('URSAPHARM-Arena','Spiesen-Elversberg',9500,['Frank Lehmann','Nicolas Kristof','Nicholas Mickelson','Florian Le Joncour','Lukas Pinckert','Jan Gyamerah','Amara Conde','Maurice Krattenmacher','Noah Darvich','Lukas Petkov','Noel Futkeu','Luca Schnellbacher']),
'SC Paderborn 07':('Home Deluxe Arena','Paderborn',15000,['Markus Schubert','Nahuel Noll','Ruben Muller','Felix Gotze','Niklas Mohr','Santiago Castaneda','Tom Baack','Raphael Obermair','Laurin Ulrich','Rayan Philippe','Sven Michel','Marvin Pieringer']),
'RB Leipzig':('Red Bull Arena','Leipzig',47069,['Orjan Nyland','Maarten Vandevoordt','Abdoul Kone','Willi Orban','Castello Lukeba','David Raum','Lukas Klostermann','Christoph Baumgartner','Nicolas Seiwald','Antonio Nusa','Johan Bakayoko','Christopher Nkunku']),
'VfB Stuttgart':('MHPArena','Stuttgart',60449,['Fabian Bredlow','Dennis Seimen','Ameen Al-Dakhil','Ramon Hendriks','Maximilian Mittelstadt','Jeff Chabot','Angelo Stiller','Chris Fuhrich','Bilal El Khannouss','Tiago Tomas','Ermedin Demirovic','Deniz Undav']),
'TSG Hoffenheim':('SNP Arena','Sinsheim',30150,['Oliver Baumann','Lukas Petersson','Robin Hranac','Ozan Kabak','Valentin Gendrey','Koki Machida','Vladimir Coufal','Patrick Wimmer','Wouter Burger','Andrej Kramaric','Adam Hlozek','Fisnik Asllani']),
'Bayer 04 Leverkusen':('BayArena','Leverkusen',30210,['Mark Flekken','Janis Blaswich','Facundo Medina','Jarell Quansah','Loic Bade','Edmond Tapsoba','Aleix Garcia','Robert Andrich','Malik Tillman','Ibrahim Maza','Patrik Schick','Victor Boniface']),
'Sport-Club Freiburg':('Europa-Park Stadion','Freiburg',34700,['Mio Backhaus','Florian Muller','Philipp Lienhart','Matthias Ginter','Christian Gunter','Max Rosenfelder','Patrick Osterhage','Maximilian Eggestein','Vincenzo Grifo','Derry Scherhant','Lucas Holer','Igor Matanovic']),
'Eintracht Frankfurt':('Deutsche Bank Park','Frankfurt',58000,['Noah Atubolu','Jens Grahl','Robin Koch','Nnamdi Collins','Otavio','Elias Baum','Ritsu Doan','Mario Gotze','Can Uzun','Ansgar Knauff','Jonathan Burkardt','Jessic Ngankam']),
'FC Augsburg':('WWK ARENA','Augsburg',30660,['Finn Dahmen','Nediljko Labrovic','Calvin Brackelmann','Jeffrey Gouweleeuw','Marius Wolf','Chrislain Matsima','Yannik Keitel','Mert Komur','Fabian Rieder','Arijon Ibrahimovic','Michael Gregoritsch','Steve Mounie']),
'1. FSV Mainz 05':('MEWA ARENA','Mainz',34034,['Alexander Schwolow','Robin Zentner','Stefan Posch','Eric Martel','Anthony Caci','Dominik Kohr','Kaishu Sano','Nadiem Amiri','Paul Nebel','Phillip Tietz','Benedict Hollerbach','Sheraldo Becker'])}
pos_by_order=['GK','GK','DF','DF','DF','DF','MF','MF','MF','FW','FW','FW']
add_league('ger_bundesliga',[(c,s,('München' if c.startswith('FC Bayern') else 'Dortmund' if c.startswith('Borussia Dortmund') else ''),cap,[(n,pos_by_order[i]) for i,n in enumerate(ps)]) for c,(s,city,cap,ps) in ger.items()])

# Italy: compact 2026/27 first-team cores from the published 20-club squad list.
ita={
'Atalanta':['Marco Carnesecchi','Marco Sportiello','Giorgio Scalvini','Isak Hien','Odilon Kossounou','Sead Kolasinac','Davide Zappacosta','Ederson','Mario Pasalic','Charles De Ketelaere','Gianluca Scamacca','Nikola Krstovic'],
'Bologna':['Lukasz Skorupski','Nadir Zortea','Lorenzo De Silvestri','Emil Holm','Nicolò Casale','Martin Vitik','Arthur Theate','Lewis Ferguson','Tommaso Pobega','Riccardo Orsolini','Artem Dovbyk','Roberto Piccoli'],
'Cagliari':['Elia Caprile','Boris Radunovic','Yukinari Sugawara','Yerry Mina','Adam Obert','Zé Pedro','Harry Winks','Alessandro Deiola','Daniel Maldini','Alieu Fadera','Kevin Carlos','M Bala Nzola'],
'Como':['Jean Butez','Robert Sanchez','Ivan Smolcic','Yan Couto','Jacobo Ramon','Marc Oliver Kempf','Trevoh Chalobah','Samuele Ricci','Maxence Caqueret','Nico Paz','Moise Kean','Anastasios Douvikas'],
'Fiorentina':['David de Gea','Luca Lezzerini','Dodo','Luca Ranieri','Radu Dragusin','Fabiano Parisi','Nicolò Fagioli','Marco Brescianini','Cher Ndour','Franco Mastantuono','Wilfried Gnonto','Beto'],
'Frosinone':['Lorenzo Palmisani','Matteo Pisseri','Anthony Oyono','Enzo Tchato','Giorgio Cittadini','Kevin Akpoguma','Omar Fayed','Giacomo Calo','Luis Hasa','Alessio Zerbin','Daniel Birligea','Antonio Raimondo'],
'Genoa':['Daniele Sommariva','Justin Bijlow','Stefano Sabelli','Johan Vasquez','Leo Ostigard','Mario Mitaj','Morten Frendrup','Djibril Sow','Junior Messias','Tommaso Baldanzi','Vitinha','Lorenzo Colombo'],
'Inter':['Raffaele Di Gennaro','Josep Martinez','Benjamin Pavard','Alessandro Bastoni','Manuel Akanji','John Stones','Federico Dimarco','Hakan Calhanoglu','Nicolo Barella','Curtis Jones','Lautaro Martinez','Marcus Thuram'],
'Juventus':['Carlo Pinsoglio','Guglielmo Vicario','Bremer','Federico Gatti','Pierre Kalulu','Lloyd Kelly','Jhon Lucumi','Andrea Cambiaso','Manuel Locatelli','Teun Koopmeiners','Kenan Yildiz','Vlahovic'],
'Lazio':['Ivan Provedel','Christos Mandas','Adam Marusic','Mario Gila','Alessio Romagnoli','Nuno Tavares','Matteo Guendouzi','Nicolo Rovella','Mattia Zaccagni','Gustav Isaksen','Taty Castellanos','Boulaye Dia'],
'Lecce':['Wladimiro Falcone','Francesco Camarda','Federico Baschirotto','Patrick Dorgu','Kialonda Gaspar','Antonino Gallo','Balthazar Pierret','Lassana Coulibaly','Hamza Rafia','Lameck Banda','Nikola Krstovic','Santiago Pierotti'],
'Milan':['Mike Maignan','Guglielmo Vicario','Fikayo Tomori','Pavlovic','Theo Hernandez','Kyle Walker','Youssouf Fofana','Tijjani Reijnders','Christian Pulisic','Rafael Leao','Santiago Gimenez','Rasmus Hojlund'],
'Monza':['Demba Thiam','Samuele Birindelli','Lorenzo Lucchesi','Andrea Carboni','Valentin Antov','Ricardo Mangas','Matteo Pessina','Michael Folorunsho','Andrea Colpani','Keita Balde','Patrick Cutrone','Dany Mota'],
'Napoli':['Alex Meret','Guglielmo Vicario','Giovanni Di Lorenzo','Alessandro Buongiorno','Amir Rrahmani','Mathias Olivera','Stanislav Lobotka','Scott McTominay','Khvicha Kvaratskhelia','Romelu Lukaku','David Neres','Giacomo Raspadori'],
'Parma':['Zion Suzuki','Leandro Chichizola','Enrico Del Prato','Alessandro Circati','Botond Balogh','Emanuele Valeri','Adrian Bernabe','Mandela Keita','Simon Sohm','Dennis Man','Matteo Cancellieri','Ange-Yoan Bonny'],
'Roma':['Mile Svilar','Gianluca Mancini','Evan Ndicka','Mario Hermoso','Angeliño','Zeki Celik','Manu Kone','Bryan Cristante','Paulo Dybala','Artem Dovbyk','Matias Soulé','Lorenzo Pellegrini'],
'Sassuolo':['Stefano Turati','Josh Doig','Martin Erlic','Filippo Romagna','Jeremy Toljan','Daniel Boloca','Kristian Thorstvedt','Luca Lipani','Domenico Berardi','Andrea Pinamonti','Armand Lauriente','Nedim Bajrami'],
'Torino':['Vanja Milinkovic-Savic','Alessandro Buongiorno','Saul Coco','Adam Masina','Valentino Lazaro','Mergim Vojvoda','Samuele Ricci','Ivan Ilic','Nikola Vlasic','Duvan Zapata','Che Adams','Yann Karamoh'],
'Udinese':['Maduka Okoye','Razvan Sava','Oumar Solet','Jaka Bijol','Kingsley Ehizibue','Jordan Zemura','Jesper Karlstrom','Sandi Lovric','Lazar Samardzic','Florian Thauvin','Keinan Davis','Lucca'],
'Venezia':['Filip Stankovic','Jesse Joronen','Jay Idzes','Michael Svoboda','Ridgeciano Haps','Alfred Duncan','Hans Nicolussi Caviglia','Gaetano Oristanio','Magnus Kofod Andersen','Joel Pohjanpalo','Gianluca Busio','Christian Gytkjaer']}
# fix league-specific names used in the project
ita_keys=['Atalanta','Bologna','Cagliari','Como','Fiorentina','Frosinone','Genoa','Inter','Juventus','Lazio','Lecce','Milan','Monza','Napoli','Parma','Roma','Sassuolo','Torino','Udinese','Venezia']
ita_stadium={
'Atalanta':('Gewiss Stadium','Bergamo',24900),'Bologna':('Renato Dall Ara','Bologna',38279),'Cagliari':('Unipol Domus','Cagliari',16416),'Como':('Giuseppe Sinigaglia','Como',13602),'Fiorentina':('Artemio Franchi','Florence',43147),'Frosinone':('Benito Stirpe','Frosinone',16227),'Genoa':('Luigi Ferraris','Genoa',36599),'Inter':('San Siro','Milan',75923),'Juventus':('Allianz Stadium','Turin',41507),'Lazio':('Stadio Olimpico','Rome',70634),'Lecce':('Via del Mare','Lecce',33876),'Milan':('San Siro','Milan',75923),'Monza':('U-Power Stadium','Monza',16700),'Napoli':('Diego Armando Maradona','Naples',54726),'Parma':('Ennio Tardini','Parma',27906),'Roma':('Stadio Olimpico','Rome',70634),'Sassuolo':('Mapei Stadium','Reggio Emilia',21525),'Torino':('Olimpico Grande Torino','Turin',27958),'Udinese':('Bluenergy Stadium','Udine',25144),'Venezia':('Pier Luigi Penzo','Venice',12434)}
add_league('ita_a',[(c,*ita_stadium[c],[(n,'GK' if i<2 else 'DF' if i<6 else 'MF' if i<9 else 'FW') for i,n in enumerate(ita[c])]) for c in ita_keys])

fra={
'PSG':['Lucas Chevalier','Matvey Safonov','Achraf Hakimi','Marquinhos','Willian Pacho','Nuno Mendes','Lucas Hernandez','Vitinha','Joao Neves','Warren Zaire-Emery','Ousmane Dembele','Khvicha Kvaratskhelia','Ferran Torres'],
'Marseille':['Geronimo Rulli','Emerson','Nayef Aguerd','Facundo Medina','Ulisses Garcia','Timothy Weah','Pierre-Emile Hojbjerg','Angel Gomes','Amine Harit','Igor Paixao','Amine Gouiri','Mason Greenwood'],
'Monaco':['Lukas Hradecky','Philipp Kohn','Eric Dier','Thilo Kehrer','Jordan Teze','Mohammed Salisu','Flavio Nazinho','Vanderson','Aleksandr Golovin','Denis Zakaria','Lamine Camara','Folarin Balogun','Ansu Fati'],
'Lille':['Ozer','Alexsandro','Thomas Meunier','Tiago Santos','Ayyoub Bouaddi','Benjamin Andre','Ngalayel Mukau','Ethan Mbappe','Hakon Haraldsson','Ousmane Toure','Jonathan David','Ueda'],
'Lyon':['Dominik Greif','Nicolas Tagliafico','Moussa Niakhate','Duje Caleta-Car','Ainsley Maitland-Niles','Tolisso','Tyler Morton','Corentin Tolisso','Pavel Sulc','Ernest Nuamah','Lois Openda','Alexandre Lacazette'],
'Rennes':['Brice Samba','Christopher Wooh','Cresswell','Frankowski','Nagida','Jordan James','Rongier','Martin Terrier','Ludovic Blas','Esteban Lepaul','Al-Tamari','Mikautadze'],
'Strasbourg':['Filip Jorgensen','Ismael Doukoure','Mamadou Sarr','Andrew Omobamidele','Ferdinand','Diego Moreira','Fofana','Habib Diarra','Dilane Bakwa','Joaquin Panichelli','Pape Diong','Santos'],
'Toulouse':['Guillaume Restes','McKenzie','Mawissa','Koumbassa','Tapé','Casseres','Vincent Sierro','Hidalgo','Jorgensen','Azizi','Russell-Rowe','Donnum'],
'Lorient':['Yvon Mvogo','Montassar Talbi','Julien Laporte','Benjamin Mendy','Arsene Kouassi','Laurent Abergel','Arthur Avom','Imran Louza','Eli Junior Kroupi','Bamba Dieng','Sirin','Soumano'],
'Paris FC':['Kevin Trapp','Arouna Sangante','Mamadou Mbow','Dylan Batubinsika','Herve Traore','Mouhamadou Sarr','Jordan Ferri','Moses Simon','Kebbal','Pagis','Sinayoko','Lees-Melou'],
'Lens':['Robin Risser','Jonathan Gradit','Jean-Kevin Duverne','Jean-Clair Todibo','Ruben Aguilar','Abdukodir Khusanov','Adrien Thomasson','Florian Thauvin','Wesley Said','Anass Zaroury','Odsonne Edouard','Sima'],
'Brest':['Selvik','Kenny Lala','Le Guen','Brendan Chardonnet','Bradley Locko','Julien Le Cardinal','Chotard','Hugo Magnetti','Kamory Doumbia','Ludovic Ajorque','Mama Balde','Mboup'],
'Angers':['Anthony Lopes','Carlens Arcus','Jordan Lefort','Emmanuel Biumla','Joseph Kalulu','Haris Belkebla','Branco van den Boomen','Louis Mouton','Jim Allevinah','Amine El Ouazzani','Amine Sbai','Prosper Peter'],
'Le Havre':['Gallon','Seko Fofana','Gautier Lloris','Mwanga','Jelert','Richardson','Ndiaye','Nakamura','Samatta','Maja','Ayew','Kuzyaev'],
'Auxerre':['Paul Nardi','Francisco Sierralta','Axel Tuanzebe','Sinaly Diomande','Marvin Senaya','Lamine Sy','Assane Diousse','Romain Faivre','Kevin Danois','Daniel Namaso','Cameron Archer','Lasso Coulibaly'],
'Nice':['Yehvann Diouf','Mohamed Abdelmonem','Ndayishimiye','Antoine Mendy','Jonathan Clauss','Wout Faes','Witsel','Dante','Hicham Boudaoui','Amine Gouiri','Amine Gouiri','Wahi'],
'Troyes':['Zacharie Boucher','Hillel Konate','Adrien Monfray','Paolo Gozzi','Ismael Boura','Lucas Maronnier','Yvann Titi','Xavier Chavalerin','Renaud Ripart','Junior Diaz','Rafiki Said','Mama Balde'],
'Le Mans':['Alexandre Oukidja','Pierre Lemonnier','Kévin Van Den Kerkhof','Yannis Moussadek','Billal Brahimi','Demba Seck','Mamadou Soro','Nolan Roux','Teddy Okou','Samuel Grandsir','Thibault Cissé','Edouard Michut']}
fra_names={'PSG':'Paris Saint-Germain','Marseille':'Olympique de Marseille','Monaco':'AS Monaco','Lille':'LOSC Lille','Lyon':'Olympique Lyonnais','Rennes':'Stade Rennais FC','Strasbourg':'RC Strasbourg Alsace','Toulouse':'Toulouse FC','Lorient':'FC Lorient','Paris FC':'Paris FC','Lens':'RC Lens','Brest':'Stade Brestois 29','Angers':'Angers SCO','Le Havre':'Le Havre AC','Auxerre':'AJ Auxerre','Nice':'OGC Nice','Troyes':'ESTAC Troyes','Le Mans':'Le Mans FC'}
fra_stadium={'PSG':('Parc des Princes','Paris',47929),'Marseille':('Orange Vélodrome','Marseille',67394),'Monaco':('Stade Louis II','Monaco',18523),'Lille':('Stade Pierre-Mauroy','Villeneuve-d Ascq',50186),'Lyon':('Groupama Stadium','Décines',59186),'Rennes':('Roazhon Park','Rennes',29778),'Strasbourg':('Stade de la Meinau','Strasbourg',29371),'Toulouse':('Stadium de Toulouse','Toulouse',33150),'Lorient':('Stade Yves Allainmat','Lorient',18600),'Paris FC':('Stade Sébastien Charléty','Paris',20000),'Lens':('Stade Bollaert-Delelis','Lens',38223),'Brest':('Stade Francis-Le Blé','Brest',15000),'Angers':('Stade Raymond Kopa','Angers',18752),'Le Havre':('Stade Océane','Le Havre',25178),'Auxerre':('Stade de l Abbé Deschamps','Auxerre',18000),'Nice':('Allianz Riviera','Nice',36178),'Troyes':('Stade de l Aube','Troyes',21877),'Le Mans':('MMArena','Le Mans',25000)}
add_league('fra_l1',[(fra_names[k],*fra_stadium[k],[(n,'GK' if i<1 else 'DF' if i<5 else 'MF' if i<9 else 'FW') for i,n in enumerate(v)]) for k,v in fra.items()])

# Ensure all six active leagues are marked playable in the embedded data too.
for k in d['leagues']:
    d['leagues'][k]['playable']=k in {'eng_pl','esp_laliga','ger_bundesliga','ita_a','fra_l1','rus_rpl'}
DB.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
print({k:(len(v.get('teams',[])),sum(len(t.get('players',[])) for t in v.get('teams',[]))) for k,v in d['leagues'].items()})
