import json, hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
meta=json.loads((ROOT/'data/leagues.json').read_text(encoding='utf-8'))['leagues']

# User-supplied 2026/27 squads/stadiums currently available in this project turn.
data={}

def add(key, club, stadium, city, cap, squad):
    data.setdefault(key,[]).append({
        'id': int(hashlib.sha1((key+':'+club).encode()).hexdigest()[:8],16),
        'name': club, 'short_name': club, 'logo':'',
        'stadium': {'name':stadium,'city':city,'capacity':cap},
        'players':[{'id':int(hashlib.sha1((key+':'+club+':'+n).encode()).hexdigest()[:8],16),'name':n,'short_name':n,'position':'M','age':None,'country':None,'jersey':None,'photo':''} for n in squad]
    })

# Russia — supplied by the user
ru={
'Краснодар':('Краснодар','Краснодар',35074,'Станислав Агкацев;Евгений Сафонов;Александр Ерохин;Кайо Панталеан;Батчи;Витор Тормена;Александр Эктов;Сергей Волков;Лео Гогличидзе;Эдуард Сперцян;Александр Черников;Никита Кривцов;Алексей Ионов;Кади Боржес;Виктор Са;Жуан Батчи;Джон Кордоба;Мозес Кобнан;Диего Коста'),
'Зенит':('Газпром Арена','Санкт-Петербург',67378,'Денис Адамов;Евгений Латышонок;Данил Круговой;Нуралы Алиев;Нино;Ваня Дркушич;Михаил Кержаков;Вильмар Барриос;Вендел;Александр Ерохин;Алексей Сутормин;Дмитрий Васильев;Максим Глушенков;Андрей Мостовой;Густаво Мантуан;Педро;Лусиано Гонду;Матео Кассьерра'),
'ЦСКА':('ВЭБ Арена','Москва',30548,'Игорь Акинфеев;Владислав Тороп;Кирилл Набабкин;Данил Круговой;Игорь Дивеев;Виктор Мендес;Мойзес;Милан Гайич;Дмитрий Баринов;Иван Обляков;Матвей Кисляк;Келвен;Кирилл Глебов;Тамерлан Мусаев;Аббосбек Файзуллаев;Секу Койта'),
'Спартак Москва':('Лукойл Арена','Москва',45360,'Александр Максименко;Илья Помазун;Александр Довбня;Кристофер Ву;Александр Джикия;Срджан Бабич;Даниил Денисов;Маркизио;Олег Рябчук;Наиль Умяров;Руслан Литвинов;Роман Зобнин;Игорь Дмитриев;Данил Пруцев;Зелимхан Бакаев;Эсекьель Барко;Пабло Солари;Ливай Гарсия;Манфред Угальде;Тео Бонгонда'),
'Динамо Москва':('ВТБ Арена','Москва',25474,'Курбан Расулов;Игорь Лещук;Андрей Лунёв;Николас Маричаль;Хуан Хосе Касерес;Милан Майсторович;Роберто Фернандес;Дмитрий Скопинцев;Бахтиёр Зайнутдинов;Максим Осипенко;Леон Зайдензаль;Дэвид Рикардо;Рубенс;Бителло;Данил Глебов;Антон Миранчук;Луис Чавес;Александр Кутицкий;Даниил Фомин;Виктор Окишор;Артур Гомес;Максимилиано Гутьеррес;Иван Сергеев;Константин Тюкавин;Жозуэ Казимир;Ярослав Гладышев'),
'Локомотив Москва':('РЖД Арена','Москва',27320,'Антон Митрюшкин;Илья Лантратов;Лукас Фассон;Сесар Монтес;Александр Сильянов;Евгений Морозов;Дмитрий Живоглядов;Наир Тикнизян;Александр Никишин;Дмитрий Баринов;Алексей Батраков;Арсений Морозов;Сергей Пиняев;Александр Руденко;Дмитрий Воробьёв;Вадим Раков;Николай Комличенко'),
'Рубин':('Ак Барс Арена','Казань',45379,'Егор Кореньков;Артём Исмагилов;Александр Мартынович;Руслан Литвинов;Уго Нова;Илья Рожков;Марат Айтбаев;Александр Зотов;Устинов;Олег Иванов;Рустам Литвинов;Марадишвили;Валентин Вада;Мирлинд Даку;Мирослав Богосавац'),
'Ростов':('Ростов Арена','Ростов-на-Дону',45000,'Рустам Ятимов;Сергей Песьяков;Данила Прохин;Максим Осипенко;Илья Вахания;Дмитрий Чистяков;Усман Ндонг;Кирилл Щетинин;Иван Комаров;Хорен Байрамян;Данил Глебов;Илья Кучук;Георгий Мелкадзе;Егор Голенков;Тимур Сулейманов;Максим Сидоров'),
'Акрон':('Солидарность Самара Арена','Самара',44918,'Виталий Гудиев;Игнат Тереховский;Матвей Безрогов;Вячеслав Бардыбахин;Егор Ведерников;Ионуц Неделчару;Йомар Роча;Марат Бокоев;Марат Хаметов;Максим Кузьмин;Денис Попенков;Ифет Джаковац;Кевин Науэль Аревало;Александр Эктов;Кирилл Данилов;Артём Дзюба;Санель Гонду;Максим Болдырев'),
'Крылья Советов':('Солидарность Самара Арена','Самара',44918,'Сергей Песьяков;Евгений Фролов;Никита Кокарев;Кирилл Печенин;Томас Гальдамес;Юрий Горшков;Алоис Орос;Николай Рассказов;Роман Евгеньев;Александр Солдатенков;Александр Эджуке;Илья Гапонов;Александр Коваленко;Роман Ежов;Бенхамин Гарре;Иван Сергеев;Владислав Шитов'),
'Динамо Махачкала':('Анжи Арена','Каспийск',31250,'Давид Волк;Зайнудин Зайнудинов;Никита Карабашев;Тимур Магомедов;Александр Сандрачук;Андрес Аларкон;Идар Шумахов;Ильяс Ахмедов;Махмуджон Махамаджонов;Сосланбек Кожокарь;Сергей Паршивлюк;Мохамед Аззи;Гамид Агаларов;Яхья Магомедов;Сослан Аджиев'),
'Ахмат':('Ахмат Арена','Грозный',30597,'Вадим Ульянов;Гиорги Шелия;Расул Мицаев;Арсен Адамов;Ахмед Эльбердов;Клисман Цаке;Максим Сидоров;Мирослав Богосовац;Турпал-Али Ибишев;Усман Ндонг;Лечи Садулаев;Александр Трошечкин;Марат Аюбов;Лечи Бериша;Гамид Агаларов;Сергей Пряхин;Максим Самородов;Герман Игнатов'),
'Балтика':('Ростех Арена','Калининград',35016,'Евгений Латышонок;Егор Любаков;Иван Кукушкин;Александр Филин;Илья Кирш;Лорис Муйоколо;Максим Шнапцев;Мингиян Бевеев;Михаил Рядно;Натан Гассама;Александр Осипов;Алексей Кузнецов;Александр Ломовицкий;Антон Зиньковский;Александр Каштанов;Данила Козлов;Тигран Аванесян;Максим Петров'),
'Оренбург':('Газовик','Оренбург',7500,'Евгений Госев;Никита Хлусевич;Михаил Сиваков;Михаил Першин;Сидней;Андрей Хрипунов;Дмитрий Воробьёв;Дмитрий Воронин;Иван Башич;Дмитрий Воробьёв;Юрий Ковалёв;Степан Оганесян;Джастин Айков;Дмитрий Воробьёв;Химад Абдуллаев'),
'Родина':('Арена Химки','Химки',18636,'Александр Довбня;Иван Будачёв;Иван Ломаев;Сергей Волков;Мамаду Сако;Сергей Бородин;Александр Эктов;Данила Козлов;Артём Попов;Александр Ломовицкий;Иван Тимошенко;Михаил Казимир;Амур Калмыков;Сердер Сердеров;Илья Шабалин'),
'Факел':('Факел','Воронеж',22300,'Алексей Кеняйкин;Александр Беленов;Василий Чернов;Роман Магаль;Игорь Калинин;Сергей Божин;Виктор Кравченко;Ильнур Альшин;Роман Акбашев;Владислав Мастерной;Никита Моцпан;Андрей Мендель;Руслан Магаль;Вячеслав Кротов;Максим Петров;Евгений Марков')}
for club,(stad,city,cap,s) in ru.items(): add('rus_rpl',club,stad,city,cap,s.split(';'))

# Spain — user stated this entire supplied set is first division 26/27.
es={
'Athletic Club':('San Mamés','Bilbao',53289,'Unai Simón;Julen Agirrezabala;Álex Padilla;Dani Vivian;Aitor Paredes;Yeray Álvarez;Aymeric Laporte;Andoni Gorosabel;Jesús Areso;Yuri Berchiche;Iñigo Lekue;Mikel Vesga;Beñat Prados;Iñigo Ruiz de Galarreta;Mikel Jauregizar;Oihan Sancet;Álex Berenguer;Iñaki Williams;Nico Williams;Gorka Guruzeta;Nico Serrano;Álvaro Djaló;Peio Canales;Maroan Sannadi'),
'Atlético de Madrid':('Riyadh Air Metropolitano','Madrid',70460,'Jan Oblak;Juan Musso;Horatiu Moldovan;José María Giménez;Robin Le Normand;Axel Witsel;Clément Lenglet;Nahuel Molina;Marcos Llorente;Javi Galán;Reinildo Mandava;Rodrigo De Paul;Koke;Pablo Barrios;Conor Gallagher;Giuliano Simeone;Samuel Lino;Antoine Griezmann;Julián Álvarez;Alexander Sørloth;Ángel Correa;Thierry Correia'),
'CA Osasuna':('El Sadar','Pamplona',23516,'Sergio Herrera;Aitor Fernández;Jesús Areso;Alejandro Catena;David García;Jorge Herrando;Juan Cruz;Abel Bretones;Rubén Peña;Lucas Torró;Jon Moncayola;Iker Muñoz;Aimar Oroz;Pablo Ibáñez;Moi Gómez;Rubén García;Bryan Zaragoza;Ante Budimir;Raúl García de Haro;Kike Barja'),
'Celta':('Abanca Balaídos','Vigo',22803,'Ionuț Radu;Iván Villar;Vicente Guaita;Javi Rodríguez;Carl Starfelt;Óscar Mingueza;Marcos Alonso;Carlos Domínguez;Hugo Álvarez;Fran Beltrán;Ilaix Moriba;Hugo Sotelo;Luca de la Torre;Óscar Rodríguez;Jonathan Bamba;Fer López;Williot Swedberg;Borja Iglesias;Pablo Durán;Alfon González'),
'Deportivo Alavés':('Mendizorroza','Vitoria-Gasteiz',19840,'Antonio Sivera;Jesús Owono;Abdelkabir Abqar;Nahuel Tenaglia;Moussa Diarra;Aleksandar Sedlar;Rafa Marín;Rubén Duarte;Carlos Vicente;Ander Guevara;Antonio Blanco;Jon Guridi;Carlos Martín;Stoichkov;Toni Martínez;Kike García;Abde Rebbach;Tomás Conechny'),
'Elche CF':('Estadio Manuel Martínez Valero','Elche',33732,'Matías Dituro;San Román;Pedro Bigas;Nicolás Castro;Bambo Diaby;Álex Martín;José Salinas;Nicolás Fernández Mercau;Gerard Hernández;Aleix Febas;Nteka;John Donald;Óscar Plano;Nico Castro;Mourad;Sergio León'),
'FC Barcelona':('Spotify Camp Nou','Barcelona',105000,'Joan García;Marc-André ter Stegen;Wojciech Szczęsny;Áron Yaakobishvili;Diego Kochen;Pau Cubarsí;Ronald Araújo;Andreas Christensen;Eric García;Gerard Martín;Alejandro Balde;Jules Koundé;João Cancelo;Frenkie de Jong;Pedri;Gavi;Marc Casadó;Fermín López;Dani Olmo;Raphinha;Lamine Yamal;Ferran Torres;Robert Lewandowski;Rodri;Hamza Abdelkarim'),
'Getafe CF':('Coliseum','Getafe',16800,'David Soria;Jirí Letáček;Abdel Abqar;Zaid Romero;Juan Berrocal;Sebastián Boselli;Dakonam Djené;Jean Ives Valou;Davinchi;Kiko Femenía;Ismael Bekhoucha;Mario Martín;Yvan Neyou;Ramón Terrats;Javi Muñoz;Coba da Costa;Juanmi;Peter Federico;Álex Sancris;Christantus Uche;Martín Satriano;Borja Mayoral'),
'Levante UD':('Ciutat de València','Valencia',26354,'Andrés Fernández;Pablo Cuñat;Unai Elgezabal;Óscar Clemente;Adrián de la Fuente;Marcos Navarro;Carlos Espí;Pablo Martínez;Oriol Rey;Sergio Lozano;José Campaña;Iván Romero;Roger Brugué;Carlos Álvarez;Giorgi Kochorashvili;Dani Gómez'),
'Málaga CF':('La Rosaleda','Málaga',30044,'Alfonso Herrero;Hernán Pérez;Nelson Monte;Einar Galilea;Nélson Benítez;Víctor García;Dani Lorenzo;Manu Molina;David Larrubia;Dioni;Antonio Cordero;Sergio Castel;Kevin Medina;Jokin Gabilondo;Luismi'),
'Racing Club':('Campos de Sport de El Sardinero','Santander',22222,'Jokin Ezkieta;Miquel Parera;Manu Hernando;Pablo Rodríguez;Rubén Alves;Saúl García;Álex Martín;Aritz Aldasoro;Íñigo Vicente;Aritz Arambarri;Pablo Torre;Lago Junior;Jon Karrikaburu;Andrés Martín;Juan Carlos Arana'),
'Rayo Vallecano':('Estadio de Vallecas','Madrid',14708,'Augusto Batalla;Dani Cárdenas;Florian Lejeune;Abdul Mumin;Aridane Hernández;Iván Balliu;Pep Chavarría;Andrei Rațiu;Óscar Valentín;Pathé Ciss;Unai López;Pedro Díaz;Jorge de Frutos;Isi Palazón;Adrián Embarba;Álvaro García;Sergio Camello;Randy Nteka'),
'RC Deportivo':('Estadio de Riazor','A Coruña',32660,'Helton Leite;Eric Puerto;Pablo Vázquez;Pablo Martínez;Dani Barcia;Ximo Navarro;Rafa Obrador;Paris Adot;Diego Villares;José Ángel Jurado;Mikel Jauregizar;Yeremay Hernández;David Mella;Mario Soriano;Hugo Rama;Iván Barbero;Lucas Pérez;Barbero'),
'RCD Espanyol':('RCDE Stadium','Cornellà de Llobregat',40500,'Joan García;Fernando Pacheco;Leandro Cabrera;Sergi Gómez;Brian Oliván;Omar El Hilali;Pol Lozano;Edu Expósito;Jofre Carreras;Javi Puado;Pere Milla;Roberto Fernández;Alejo Véliz;Antoniu Roca;Naci Ünüvar'),
'Real Betis':('Estadio Benito Villamarín','Seville',60721,'Álvaro Valles;Pau López;Guilherme Fernandes;Natan;Valentín Gómez;Diego Llorente;Marc Bartra;Adrián;Héctor Bellerín;Romain Perraud;Marc Roca;Johnny Cardoso;Guido Rodríguez;Isco;Pablo Fornals;Sergi Altimira;Jesús Rodríguez;Abde Ezzalzouli;Antony;Aitor Ruibal;Cédric Bakambu;Cucho Hernández'),
'Real Madrid':('Santiago Bernabéu','Madrid',84744,'Thibaut Courtois;Andriy Lunin;Kepa Arrizabalaga;Dean Huijsen;Antonio Rüdiger;Éder Militão;David Alaba;Raúl Asencio;Ferland Mendy;Fran García;Trent Alexander-Arnold;Daniel Carvajal;Jude Bellingham;Eduardo Camavinga;Aurélien Tchouaméni;Federico Valverde;Arda Güler;Brahim Díaz;Rodrygo;Vinícius Júnior;Kylian Mbappé;Endrick;Gonzalo García'),
'Real Sociedad':('Reale Arena','San Sebastián',40000,'Álex Remiro;Unai Marrero;Jon Mikel Aramburu;Álvaro Odriozola;Iñaki Rupérez;Jon Pacheco;Igor Zubeldia;Robin Le Normand;Aihen Muñoz;Jon Gorrotxategi;Beñat Turrientes;Luka Sučić;Carlos Soler;Brais Méndez;Martín Zubimendi;Takefusa Kubo;Sergio Gómez;Ander Barrenetxea;Mikel Oyarzabal;Orri Óskarsson;Sheraldo Becker'),
'Sevilla FC':('Ramón Sánchez-Pizjuán','Seville',43883,'Ørjan Nyland;Álvaro Fernández;Kike Salas;Andrés Castrín;Loïc Badé;Nemanja Gudelj;Tanguy Nianzou;Adri Pedrosa;Juanlu Sánchez;José Ángel Carmona;Djibril Sow;Lucien Agoumé;Manu Bueno;Suso;Dodi Lukebakio;Chidera Ejuke;Peque Fernández;Isaac Romero;Akór Adams;Alfon González'),
'Valencia CF':('Mestalla','Valencia',49430,'Stole Dimitrievski;Cristian Rivero;Giorgi Mamardashvili;César Tárrega;Mouctar Diakhaby;Cristhian Mosquera;Yarek Gasiorowski;Jesús Vázquez;José Gayà;Dimitri Foulquier;Thierry Correia;Pepelu;Javi Guerra;Enzo Barrenechea;André Almeida;Diego López;Fran Pérez;Sergi Canós;Hugo Duro;Roman Yaremchuk'),
'Villarreal CF':('Estadio de la Cerámica','Villarreal',23500,'Luiz Júnior;Diego Conde;Filip Jørgensen;Raúl Albiol;Logan Costa;Willy Kambwala;Pau Navarro;Sergio Cardona;Alfonso Pedraza;Juan Foyth;Dani Parejo;Santi Comesaña;Pape Gueye;Álex Baena;Yeremy Pino;Ilias Akhomach;Nicolas Pépé;Gerard Moreno;Ayoze Pérez;Thierno Barry;Arnaut Danjuma')}
for club,(stad,city,cap,s) in es.items(): add('esp_laliga',club,stad,city,cap,s.split(';'))

# Keep every division represented in the embedded file; second divisions remain stored/hidden.
leagues={}
for key,m in meta.items():
    teams=data.get(key,[])
    leagues[key]={**m,'season':'2026/27','teams':teams}

out={'season':'2026/27','source':'embedded_user_data','leagues':leagues}
(ROOT/'data/football_database.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print('leagues:', {k:len(v['teams']) for k,v in leagues.items()})
