# Локальная футбольная база TIME TO MANAGER 26/27

База встроена в проект и не требует внешнего футбольного API во время игры.

## Игровые лиги
- England — Premier League
- Spain — LaLiga
- Germany — Bundesliga
- Italy — Serie A
- France — Ligue 1
- Russia — РПЛ

У каждой активной лиги в базе есть клубы, стадионы и игроки. Вторые дивизионы сохранены в `leagues.json`, но имеют `playable: false` и не показываются при создании карьеры.

Источник рантайм-данных: `football_database.json` (embedded/local).
Sofascore и сетевое обновление составов не используются.
