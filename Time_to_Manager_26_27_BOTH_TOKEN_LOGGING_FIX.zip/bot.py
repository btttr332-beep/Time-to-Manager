import os, json, random, sqlite3, asyncio, urllib.parse, hmac, hashlib, logging
from pathlib import Path
from contextlib import closing
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters
import uvicorn
from game.provider import SquadProvider
from game.engine import GameEngine

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(name)s | %(message)s')
log = logging.getLogger('time_to_manager')

BASE = Path(__file__).parent
DB = BASE / 'career.db'
WEB = BASE / 'web'
TOKEN = (os.getenv('BOT_TOKEN') or os.getenv('TELEGRAM_BOT_TOKEN') or os.getenv('TOKEN') or '').strip()
WEBAPP_URL = os.getenv('WEBAPP_URL', '').strip().rstrip('/')
PORT = int(os.getenv('PORT', '8000'))
META = json.loads((BASE / 'data/leagues.json').read_text(encoding='utf8'))['leagues']
provider = SquadProvider()
engine = GameEngine(None)
conn = sqlite3.connect(DB, check_same_thread=False)
conn.row_factory = sqlite3.Row

def db(sql, args=(), fetch=False, many=False):
    with closing(conn.cursor()) as c:
        c.executemany(sql, args) if many else c.execute(sql, args)
        out = c.fetchall() if fetch else c.lastrowid
        conn.commit()
        return out

def init_db():
    db('''CREATE TABLE IF NOT EXISTS profiles(user_id INTEGER PRIMARY KEY,nickname TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    db('''CREATE TABLE IF NOT EXISTS achievements(user_id INTEGER PRIMARY KEY,cups INTEGER DEFAULT 0,titles INTEGER DEFAULT 0,europa INTEGER DEFAULT 0,finals INTEGER DEFAULT 0,seasons INTEGER DEFAULT 0)''')
    db('''CREATE TABLE IF NOT EXISTS games(chat_id INTEGER PRIMARY KEY,league_key TEXT,season INTEGER DEFAULT 1,phase TEXT DEFAULT 'lobby',matchday INTEGER DEFAULT 1,season_year TEXT DEFAULT '2026/27',max_seasons INTEGER DEFAULT 5)''')
    db('''CREATE TABLE IF NOT EXISTS managers(user_id INTEGER,chat_id INTEGER,nickname TEXT,username TEXT,club TEXT,reputation INTEGER DEFAULT 50,money INTEGER DEFAULT 100000000,wage_budget INTEGER DEFAULT 2500000,trust INTEGER DEFAULT 70,objective TEXT DEFAULT 'Финишировать в верхней половине таблицы',formation TEXT DEFAULT '4-3-3',style TEXT DEFAULT 'Balanced',wins INTEGER DEFAULT 0,draws INTEGER DEFAULT 0,losses INTEGER DEFAULT 0,PRIMARY KEY(user_id,chat_id),UNIQUE(chat_id,club))''')
    db('''CREATE TABLE IF NOT EXISTS teams(chat_id INTEGER,club TEXT,team_id INTEGER,logo TEXT,stadium_name TEXT,stadium_city TEXT,capacity INTEGER,played INTEGER DEFAULT 0,won INTEGER DEFAULT 0,draw INTEGER DEFAULT 0,lost INTEGER DEFAULT 0,gf INTEGER DEFAULT 0,ga INTEGER DEFAULT 0,points INTEGER DEFAULT 0,PRIMARY KEY(chat_id,club))''')
    db('''CREATE TABLE IF NOT EXISTS players(chat_id INTEGER,club TEXT,player_id INTEGER,name TEXT,short_name TEXT,pos TEXT,age INTEGER,country TEXT,jersey INTEGER,photo TEXT,ovr INTEGER,potential INTEGER,value INTEGER,salary INTEGER,form INTEGER,morale INTEGER,fitness INTEGER,injured INTEGER DEFAULT 0,suspended INTEGER DEFAULT 0,PRIMARY KEY(chat_id,club,player_id))''')
    db('''CREATE TABLE IF NOT EXISTS fixtures(chat_id INTEGER,md INTEGER,home TEXT,away TEXT,hs INTEGER,ascore INTEGER,played INTEGER DEFAULT 0,PRIMARY KEY(chat_id,md,home,away))''')
    db('''CREATE TABLE IF NOT EXISTS transfers(id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id INTEGER,player_id INTEGER,player_name TEXT,from_club TEXT,to_club TEXT,fee INTEGER,kind TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    db('''CREATE TABLE IF NOT EXISTS transfer_offers(id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id INTEGER,player_id INTEGER,from_club TEXT,to_club TEXT,fee INTEGER,source_user INTEGER DEFAULT 0,status TEXT DEFAULT 'pending')''')
    db('''CREATE TABLE IF NOT EXISTS news(id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id INTEGER,text TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    db('''CREATE TABLE IF NOT EXISTS nickname_wait(user_id INTEGER PRIMARY KEY)''')
init_db()

def profile(uid):
    r = db('SELECT * FROM profiles WHERE user_id=?', (uid,), True); return r[0] if r else None

def achievements(uid):
    r = db('SELECT * FROM achievements WHERE user_id=?', (uid,), True)
    return r[0] if r else db('INSERT OR IGNORE INTO achievements(user_id) VALUES(?)', (uid,)) and db('SELECT * FROM achievements WHERE user_id=?',(uid,),True)[0]

def game(chat):
    r = db('SELECT * FROM games WHERE chat_id=?', (chat,), True); return r[0] if r else None

def manager(chat, uid):
    r = db('SELECT * FROM managers WHERE chat_id=? AND user_id=?', (chat, uid), True); return r[0] if r else None

def add_news(chat, text): db('INSERT INTO news(chat_id,text) VALUES(?,?)', (chat, text))

def nickname_for(user):
    p = profile(user.id)
    return p['nickname'] if p else (user.first_name or f'Manager{user.id}')

def private_main_kb():
    return InlineKeyboardMarkup([[InlineKeyboardButton('🏆 Достижения', callback_data='profile_ach')],
                                 [InlineKeyboardButton('❓ Подсказки', callback_data='help')],
                                 [InlineKeyboardButton('🎮 Начать новую игру', callback_data='new_game_private')]])

def help_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton('🏠 Клуб', callback_data='help:club'), InlineKeyboardButton('👥 Состав', callback_data='help:squad')],
        [InlineKeyboardButton('🔄 Трансферы', callback_data='help:transfers'), InlineKeyboardButton('⚽ Матчи', callback_data='help:matches')],
        [InlineKeyboardButton('💰 Финансы', callback_data='help:finances'), InlineKeyboardButton('📋 Руководство', callback_data='help:board')],
        [InlineKeyboardButton('🏆 Турниры', callback_data='help:tournaments'), InlineKeyboardButton('🧠 Тактика', callback_data='help:tactics')],
        [InlineKeyboardButton('📅 Календарь', callback_data='help:calendar'), InlineKeyboardButton('⬅️ В меню', callback_data='help:back')]
    ])

def help_text(topic=None):
    topics = {
        'club': '🏠 КЛУБ\n\n/career — открыть твою карьеру: клуб, бюджет, репутацию, доверие и цель сезона.',
        'squad': '👥 СОСТАВ\n\n/squad — открыть состав и управлять своей командой. Карточки игроков показывают OVR, возраст, форму, мораль, физику, стоимость, зарплату и потенциал.',
        'transfers': '🔄 ТРАНСФЕРЫ\n\n/transfers — рынок игроков. Здесь можно покупать игроков, продавать своих и выставлять игроков на трансфер. Предложения и стоимость зависят от игрока и сделки.',
        'matches': '⚽ МАТЧИ\n\n/match — работа с ближайшим туром и симуляцией. /fixtures — календарь. /table — текущая турнирная таблица. Результаты матчей обновляют таблицу.',
        'finances': '💰 ФИНАНСЫ\n\nБюджет клуба используется для трансферов и других расходов. Следи за стоимостью сделок и зарплатами игроков.',
        'board': '📋 РУКОВОДСТВО\n\nЗдесь отображается цель совета директоров и доверие к менеджеру. По итогам сезона выполнение целей влияет на продолжение карьеры.',
        'tournaments': '🏆 ТУРНИРЫ\n\nВ карьере учитываются национальный чемпионат, кубковые турниры и еврокубки. Квалификация в Европу зависит от итогового места в чемпионате.',
        'tactics': '🧠 ТАКТИКА\n\n/tactics — выбор схемы и стиля игры. Настройки влияют на силу команды при симуляции матчей.',
        'calendar': '📅 КАЛЕНДАРЬ\n\n/fixtures — ближайшие матчи и расписание сезона. /match — переход к симуляции текущего тура.'
    }
    if topic in topics:
        return topics[topic]
    return ('❓ ПОДСКАЗКИ\n\n'
            '/start — профиль и главное меню\n'
            '/career — моя карьера и клуб\n'
            '/squad — состав команды\n'
            '/transfers — трансферы и переговоры\n'
            '/tactics — тактика и схема\n'
            '/fixtures — календарь\n'
            '/match — матч и симуляция тура\n'
            '/table — турнирная таблица\n'
            '/board — требования руководства\n'
            '/help — открыть это меню\n\n'
            'Нажми кнопку ниже, чтобы узнать подробнее о каждом разделе.')

async def help_menu(update,ctx,cb=False,topic=None):
    text=help_text(topic)
    if cb:
        await update.callback_query.edit_message_text(text,reply_markup=help_kb())
    else:
        await update.message.reply_text(text,reply_markup=help_kb())

async def help_command(update,ctx):
    await help_menu(update,ctx)

def main_kb():
    rows=[]
    if WEBAPP_URL: rows.append([InlineKeyboardButton('📱 Web App', web_app=WebAppInfo(url=WEBAPP_URL))])
    rows += [[InlineKeyboardButton('👔 Моя карьера',callback_data='career'),InlineKeyboardButton('📊 Таблица',callback_data='table')],
             [InlineKeyboardButton('👥 Состав',callback_data='squad'),InlineKeyboardButton('💼 Трансферы',callback_data='transfers')],
             [InlineKeyboardButton('📅 Календарь',callback_data='fixtures'),InlineKeyboardButton('🎯 Руководство',callback_data='board')],
             [InlineKeyboardButton('🧠 Тактика',callback_data='tactics'),InlineKeyboardButton('📰 Новости',callback_data='news')],
             [InlineKeyboardButton('❓ Подсказки',callback_data='help')]]
    return InlineKeyboardMarkup(rows)

def admin(uid, chat):
    try:
        member = _admin_cache.get((chat,uid)); return bool(member)
    except NameError: return False
_admin_cache = {}

async def is_admin(update, uid=None):
    chat=update.effective_chat; uid=uid or update.effective_user.id
    if chat.type=='private': return False
    member=await chat.get_member(uid); ok=member.status in ('administrator','creator'); _admin_cache[(chat.id,uid)]=ok; return ok

async def start(update,ctx):
    if update.effective_chat.type != 'private':
        await update.message.reply_text('👋 Профиль создаётся в личном чате с ботом. Нажми /start здесь в личке.')
        return
    uid=update.effective_user.id; p=profile(uid)
    if not p:
        db('INSERT OR REPLACE INTO nickname_wait(user_id) VALUES(?)',(uid,))
        await update.message.reply_text('⚽ TIME TO MANAGER 26/27\n\nДобро пожаловать!\n\nПридумай свой игровой ник:')
        return
    a=achievements(uid)
    await update.message.reply_text(f'⚽ TIME TO MANAGER 26/27\n\n👤 {p["nickname"]}\n\n🏆 Достижения\nКубки: {a["cups"]}\nЧемпионства: {a["titles"]}\nЕврокубки: {a["europa"]}\nСыграно сезонов: {a["seasons"]}', reply_markup=private_main_kb())

async def text_nickname(update,ctx):
    if update.effective_chat.type!='private': return
    uid=update.effective_user.id
    if not db('SELECT 1 FROM nickname_wait WHERE user_id=?',(uid,),True): return
    nick=update.message.text.strip().lstrip('@')[:24]
    if len(nick)<2: await update.message.reply_text('Ник должен содержать минимум 2 символа.'); return
    db('DELETE FROM nickname_wait WHERE user_id=?',(uid,)); db('INSERT OR REPLACE INTO profiles(user_id,nickname) VALUES(?,?)',(uid,nick)); db('INSERT OR IGNORE INTO achievements(user_id) VALUES(?)',(uid,))
    await update.message.reply_text(f'✅ Профиль создан.\n\n👤 {nick}', reply_markup=private_main_kb())

async def newgame(update,ctx):
    if update.effective_chat.type=='private':
        await update.message.reply_text('🎮 Новую карьеру можно начать только в группе. Добавь бота в группу и используй /newgame.')
        return
    if not profile(update.effective_user.id):
        await update.message.reply_text('Сначала открой личный чат с ботом и создай профиль через /start.')
        return
    if not await is_admin(update):
        await update.message.reply_text('Только администратор группы может начать новую игру.')
        return
    if game(update.effective_chat.id): await update.message.reply_text('В этой группе уже есть активная карьера.'); return
    rows=[]
    for key,m in META.items():
        if m.get('playable') and key in provider.database.get('leagues',{}) and provider.database['leagues'][key].get('teams'):
            rows.append([InlineKeyboardButton(f'{m["country"]} — {m["name"]}',callback_data='lg:'+key)])
    await update.message.reply_text('🏆 НОВАЯ КАРЬЕРА\n\nАдминистратор выбирает лигу:',reply_markup=InlineKeyboardMarkup(rows))

async def choose_league(update,ctx):
    q=update.callback_query; chat=q.message.chat
    if not await is_admin(update,q.from_user.id): await q.answer('Только администратор.',show_alert=True); return
    key=q.data[3:]
    if key not in META or not META[key].get('playable'): await q.answer('Эта лига сейчас скрыта.',show_alert=True); return
    league=provider.load_league(key)
    db('INSERT INTO games(chat_id,league_key,season,phase,matchday,season_year) VALUES(?,?,1,\'lobby\',1,\'2026/27\')',(chat.id,key))
    for t in league['teams']:
        stadium=t.get('stadium',{})
        db('INSERT OR IGNORE INTO teams(chat_id,club,team_id,logo,stadium_name,stadium_city,capacity) VALUES(?,?,?,?,?,?,?)',(chat.id,t['name'],t['id'],t.get('logo',''),stadium.get('name',''),stadium.get('city',''),stadium.get('capacity',0)))
        for raw in t.get('players',[]):
            p=engine.derive_attributes(raw); db('INSERT OR IGNORE INTO players(chat_id,club,player_id,name,short_name,pos,age,country,jersey,photo,ovr,potential,value,salary,form,morale,fitness) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(chat.id,t['name'],p['id'],p['name'],p['short_name'],p['pos'],p.get('age'),p.get('country'),p.get('jersey'),p.get('photo'),p['ovr'],p['potential'],p['value'],p['salary'],p['form'],p['morale'],p['fitness']))
    db('UPDATE games SET phase=\'lobby\' WHERE chat_id=?',(chat.id,))
    kb=InlineKeyboardMarkup([[InlineKeyboardButton('🙋 Войти в набор',callback_data='join')],[InlineKeyboardButton('🔒 Завершить набор',callback_data='finish_lobby')]])
    await q.edit_message_text(f'🏆 {META[key]["name"]} · 2026/27\n\n👥 Набор менеджеров открыт.\nНажми «Войти в набор».\n\nПосле завершения набора администратор распределит клубы.',reply_markup=kb)

async def join_game(update,ctx):
    q=update.callback_query; chat=q.message.chat.id; uid=q.from_user.id
    if not profile(uid): await q.answer('Сначала зайди к боту в личку и создай профиль.',show_alert=True); return
    g=game(chat)
    if not g or g['phase']!='lobby': await q.answer('Набор уже закрыт.',show_alert=True); return
    p=profile(uid)
    already_joined = manager(chat,uid) is not None
    if not already_joined:
        db('INSERT OR IGNORE INTO managers(user_id,chat_id,nickname,username,club) VALUES(?,?,?,?,NULL)',(uid,chat,p['nickname'],q.from_user.username))
    joined=db('SELECT nickname FROM managers WHERE chat_id=?',(chat,),True)
    if already_joined:
        await q.answer('Ты уже в наборе.')
    else:
        await q.answer('Ты вошёл в набор!')
    lobby_kb=InlineKeyboardMarkup([
        [InlineKeyboardButton('🙋 Войти в набор',callback_data='join')],
        [InlineKeyboardButton('🔒 Завершить набор',callback_data='finish_lobby')]
    ])
    await q.edit_message_text(
        '👥 НАБОР МЕНЕДЖЕРОВ\n\n'
        + ('\n'.join(f'• {x["nickname"]}' for x in joined) if joined else 'Пока никто не присоединился.')
        + '\n\nНажимайте «Войти в набор». Администратор завершит набор, когда все готовы.',
        reply_markup=lobby_kb
    )

async def finish_lobby(update,ctx):
    q=update.callback_query
    if not await is_admin(update,q.from_user.id): await q.answer('Только администратор.',show_alert=True); return
    chat=q.message.chat.id; g=game(chat)
    if not g or g['phase']!='lobby': await q.answer('Набор уже закрыт.',show_alert=True); return
    joined=db('SELECT user_id,nickname FROM managers WHERE chat_id=? AND club IS NULL',(chat,),True)
    if not joined: await q.answer('Никто не вошёл в набор.',show_alert=True); return
    clubs=db('SELECT club FROM teams WHERE chat_id=? ORDER BY club',(chat,),True); random.Random(f'{chat}:clubs').shuffle(clubs)
    for i,m in enumerate(joined): db('UPDATE managers SET club=? WHERE chat_id=? AND user_id=?',(clubs[i]['club'],chat,m['user_id']))
    db('UPDATE games SET phase=\'active\' WHERE chat_id=?',(chat,))
    await q.edit_message_text(
        '🎮 НАБОР ЗАВЕРШЁН\n\n'
        'Клубы распределены между участниками.\n\n'
        + '\n'.join(f'👔 {m["nickname"]} → {clubs[i]["club"]}' for i,m in enumerate(joined))
        + '\n\n🚦 Карьера начинается! Нажми «Моя карьера», чтобы открыть свой клуб.',
        reply_markup=main_kb()
    )


async def pick_club(update,ctx):
    q=update.callback_query; chat=q.message.chat.id; uid=q.from_user.id; g=game(chat)
    if not g or g['phase']!='club_select': await q.answer('Выбор клубов закрыт.',show_alert=True); return
    m=manager(chat,uid)
    if not m or m['club']: await q.answer('У тебя уже есть клуб.',show_alert=True); return
    taken={x['club'] for x in db('SELECT club FROM managers WHERE chat_id=? AND club IS NOT NULL',(chat,),True)}
    clubs=[x['club'] for x in db('SELECT club FROM teams WHERE chat_id=? ORDER BY club',(chat,),True) if x['club'] not in taken]
    await q.edit_message_text('🏠 ВЫБОР КЛУБА\n\nВыбери свободный клуб:',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(c,callback_data='takeclub:'+c)] for c in clubs]))

async def take_club(update,ctx):
    q=update.callback_query; chat=q.message.chat.id; uid=q.from_user.id; g=game(chat)
    if not g or g['phase']!='club_select': await q.answer('Выбор закрыт.',show_alert=True); return
    m=manager(chat,uid); club=q.data.split(':',1)[1]
    if not m or m['club']: await q.answer('Клуб уже выбран.',show_alert=True); return
    if db('SELECT 1 FROM managers WHERE chat_id=? AND club=?',(chat,club),True): await q.answer('Этот клуб уже занят.',show_alert=True); return
    db('UPDATE managers SET club=? WHERE chat_id=? AND user_id=?',(club,chat,uid))
    await q.answer(f'Ты возглавил {club}!')
    await finish_club_selection(chat,q.message)

async def random_club(update,ctx):
    q=update.callback_query; chat=q.message.chat.id; uid=q.from_user.id; g=game(chat)
    if not g or g['phase']!='club_select': await q.answer('Выбор закрыт.',show_alert=True); return
    m=manager(chat,uid)
    if not m or m['club']: await q.answer('У тебя уже есть клуб.',show_alert=True); return
    taken={x['club'] for x in db('SELECT club FROM managers WHERE chat_id=? AND club IS NOT NULL',(chat,),True)}
    clubs=[x['club'] for x in db('SELECT club FROM teams WHERE chat_id=? ORDER BY club',(chat,),True) if x['club'] not in taken]
    if not clubs: await q.answer('Свободных клубов нет.',show_alert=True); return
    club=random.choice(clubs); db('UPDATE managers SET club=? WHERE chat_id=? AND user_id=?',(club,chat,uid)); await q.answer(f'🎲 Тебе достался {club}!'); await finish_club_selection(chat,q.message)

async def finish_club_selection(chat,message):
    left=db('SELECT nickname FROM managers WHERE chat_id=? AND club IS NULL',(chat,),True)
    if left: return
    db('UPDATE games SET phase=\'active\' WHERE chat_id=?',(chat,))
    ms=db('SELECT nickname,club FROM managers WHERE chat_id=? ORDER BY nickname',(chat,),True)
    await message.reply_text('🚦 КАРЬЕРА НАЧАЛАСЬ\n\n'+'\n'.join(f'👔 {m["nickname"]} → {m["club"]}' for m in ms)+'\n\nТеперь начинается сезон 2026/27.',reply_markup=main_kb())

async def career(update,ctx,cb=False):
    chat=update.effective_chat.id; uid=update.effective_user.id; m=manager(chat,uid)
    if not m: text='У тебя нет клуба в этой карьере.'
    else: text=f'🏟️ TIME TO MANAGER 26/27\n\n👔 {m["nickname"]}\n🏠 {m["club"]}\n💰 €{m["money"]:,}\n⭐ Репутация: {m["reputation"]}\n🤝 Доверие: {m["trust"]}/100\n🎯 {m["objective"]}\n\n📅 Тур {game(chat)["matchday"]}'
    if cb: await update.callback_query.edit_message_text(text,reply_markup=main_kb())
    else: await update.message.reply_text(text,reply_markup=main_kb())

async def table(update,ctx,cb=False):
    chat=update.effective_chat.id; rows=db('SELECT * FROM teams WHERE chat_id=? ORDER BY points DESC,(gf-ga) DESC,gf DESC,club',(chat,),True)
    text='📊 ТАБЛИЦА\n\n'+'\n'.join(f'{i:>2}. {r["club"]} — {r["points"]} оч. | {r["gf"]}:{r["ga"]}' for i,r in enumerate(rows,1)) or 'Нет данных.'
    if cb: await update.callback_query.edit_message_text(text,reply_markup=main_kb())
    else: await update.message.reply_text(text,reply_markup=main_kb())

def player_card(p):
    icons={'GK':'🧤','DF':'🛡️','MF':'🎯','FW':'⚡'}; icon=icons.get(p['pos'],'⚽')
    return (f'{icon} {p["name"]}\n\nPOSITION  {p["pos"]}   ·   OVR {p["ovr"]}\n'
            f'Возраст: {p["age"] or "—"}\nФорма: {p["form"]}/100\nМораль: {p["morale"]}/100\nФизика: {p["fitness"]}/100\n\n'
            f'💶 Стоимость: €{p["value"]:,}\n💰 Зарплата: €{p["salary"]:,}\n📈 Потенциал: {p["potential"]}')

async def squad(update,ctx,cb=False):
    chat=update.effective_chat.id; m=manager(chat,update.effective_user.id)
    if not m: text='Сначала вступи в карьеру.'; kb=main_kb()
    else:
        ps=db('SELECT * FROM players WHERE chat_id=? AND club=? ORDER BY ovr DESC,name',(chat,m['club']),True)
        text=f'👥 СОСТАВ · {m["club"]}\n\nВыбери футболиста:'
        kb=InlineKeyboardMarkup([[InlineKeyboardButton(f'{p["name"]} · {p["pos"]} · {p["ovr"]} OVR',callback_data=f'player:{p["player_id"]}')] for p in ps]+[[InlineKeyboardButton('↩️ Назад',callback_data='career')]])
    if cb: await update.callback_query.edit_message_text(text,reply_markup=kb)
    else: await update.message.reply_text(text,reply_markup=kb)

async def player_view(update,ctx):
    q=update.callback_query; chat=q.message.chat.id; uid=q.from_user.id; pid=int(q.data.split(':')[1]); m=manager(chat,uid)
    p=db('SELECT * FROM players WHERE chat_id=? AND player_id=?',(chat,pid),True)
    if not m or not p: await q.answer('Игрок не найден.',show_alert=True); return
    p=p[0]; own=p['club']==m['club']; buttons=[]
    if own: buttons.append([InlineKeyboardButton('📤 Выставить на трансфер',callback_data=f'list:{pid}')])
    else: buttons.append([InlineKeyboardButton(f'💶 Сделать предложение · €{p["value"]:,}',callback_data=f'buy:{pid}')])
    buttons.append([InlineKeyboardButton('↩️ К составу',callback_data='squad')])
    await q.edit_message_text(player_card(p)+f'\n\n🏠 Клуб: {p["club"]}',reply_markup=InlineKeyboardMarkup(buttons))

async def transfers(update,ctx,cb=False):
    chat=update.effective_chat.id; m=manager(chat,update.effective_user.id)
    if not m: text='Сначала вступи в карьеру.'; kb=main_kb()
    else:
        ps=db('SELECT * FROM players WHERE chat_id=? AND club!=? ORDER BY value DESC LIMIT 20',(chat,m['club']),True)
        text=f'💼 ТРАНСФЕРНЫЙ РЫНОК\n\n💰 Бюджет: €{m["money"]:,}\n\nВыбери футболиста:'
        kb=InlineKeyboardMarkup([[InlineKeyboardButton(f'{p["name"]} · €{p["value"]:,} · {p["club"]}',callback_data=f'player:{p["player_id"]}')] for p in ps]+[[InlineKeyboardButton('↩️ Назад',callback_data='career')]])
    if cb: await update.callback_query.edit_message_text(text,reply_markup=kb)
    else: await update.message.reply_text(text,reply_markup=kb)

async def buy_player(update,ctx):
    q=update.callback_query; await q.answer(); chat=q.message.chat.id; uid=q.from_user.id; m=manager(chat,uid); pid=int(q.data.split(':')[1]); p=db('SELECT * FROM players WHERE chat_id=? AND player_id=?',(chat,pid),True)
    if not m or not p: await q.answer('Игрок не найден.',show_alert=True); return
    p=p[0]
    if p['club']==m['club']: await q.answer('Он уже у тебя.',show_alert=True); return
    # Player willingness changes the accepted fee; no automatic sale without an offer/acceptance.
    willingness=max(0,min(100,50 + (m['reputation']-50)//2 + (m['trust']-70)//3))
    fee=int(p['value']*(1.00 + (50-willingness)/500))
    if m['money']<fee: await q.edit_message_text(f'❌ Недостаточно средств. Требуется около €{fee:,}.',reply_markup=main_kb()); return
    db('UPDATE players SET club=? WHERE chat_id=? AND club=? AND player_id=?',(m['club'],chat,p['club'],pid)); db('UPDATE managers SET money=money-? WHERE chat_id=? AND user_id=?',(fee,chat,uid)); db('INSERT INTO transfers(chat_id,player_id,player_name,from_club,to_club,fee,kind) VALUES(?,?,?,?,?,?,?)',(chat,pid,p['name'],p['club'],m['club'],fee,'purchase')); add_news(chat,f'💼 {m["club"]} подписал {p["name"]} за €{fee:,}.')
    await q.edit_message_text(f'✅ Сделка завершена\n\n{p["name"]} → {m["club"]}\n💶 €{fee:,}',reply_markup=main_kb())

async def list_player(update,ctx):
    q=update.callback_query; chat=q.message.chat.id; uid=q.from_user.id; pid=int(q.data.split(':')[1]); m=manager(chat,uid); p=db('SELECT * FROM players WHERE chat_id=? AND player_id=?',(chat,pid),True)
    if not m or not p or p[0]['club']!=m['club']: await q.answer('Недоступно.',show_alert=True); return
    p=p[0]; fee=int(p['value']*1.05); db('INSERT INTO transfer_offers(chat_id,player_id,from_club,to_club,fee,source_user,status) VALUES(?,?,?,?,?,?,?)',(chat,pid,m['club'],'FREE_MARKET',fee,uid,'listed')); add_news(chat,f'📤 {p["name"]} выставлен на трансфер за €{fee:,}.')
    await q.edit_message_text(f'📤 {p["name"]} выставлен на трансфер.\n\nСтартовая цена: €{fee:,}\n\nИИ или другой менеджер может прислать предложение.',reply_markup=main_kb())

async def fixtures(update,ctx,cb=False):
    chat=update.effective_chat.id; m=manager(chat,update.effective_user.id); rows=db('SELECT * FROM fixtures WHERE chat_id=? AND (home=? OR away=?) ORDER BY md LIMIT 15',(chat,m['club'],m['club']),True) if m else []
    text='📅 КАЛЕНДАРЬ\n\n'+'\n'.join(f'{r["md"]} тур · {r["home"]} — {r["away"]}' + (f' · {r["hs"]}:{r["ascore"]}' if r['played'] else '') for r in rows) if rows else 'Календарь появится после старта тура.'
    if cb: await update.callback_query.edit_message_text(text,reply_markup=main_kb())
    else: await update.message.reply_text(text,reply_markup=main_kb())

async def board(update,ctx,cb=False):
    chat=update.effective_chat.id; m=manager(chat,update.effective_user.id); text='🎯 РУКОВОДСТВО\n\n'+(f'Доверие: {m["trust"]}/100\nЦель: {m["objective"]}' if m else 'Сначала вступи в карьеру.')
    if cb: await update.callback_query.edit_message_text(text,reply_markup=main_kb())
    else: await update.message.reply_text(text,reply_markup=main_kb())

def create_round(chat,md):
    teams=[x['club'] for x in db('SELECT club FROM teams WHERE chat_id=?',(chat,),True)]
    if not teams: return
    # Deterministic round-robin style rotation for repeatable calendars.
    teams.sort(); n=len(teams)
    if n%2: teams.append('BYE'); n+=1
    arr=teams[:]
    for _ in range(md-1): arr=[arr[0]]+[arr[-1]]+arr[1:-1]
    for i in range(n//2):
        h,a=arr[i],arr[n-1-i]
        if h!='BYE' and a!='BYE': db('INSERT OR IGNORE INTO fixtures(chat_id,md,home,away) VALUES(?,?,?,?)',(chat,md,h,a))

def update_team(chat,club,gf,ga): db('UPDATE teams SET played=played+1,won=won+?,draw=draw+?,lost=lost+?,gf=gf+?,ga=ga+?,points=points+? WHERE chat_id=? AND club=?',(int(gf>ga),int(gf==ga),int(gf<ga),gf,ga,3 if gf>ga else 1 if gf==ga else 0,chat,club))

def simulate(chat):
    g=game(chat); md=g['matchday']; create_round(chat,md); fs=db('SELECT * FROM fixtures WHERE chat_id=? AND md=? AND played=0',(chat,md),True); results=[]
    for f in fs:
        hp=db('SELECT * FROM players WHERE chat_id=? AND club=?',(chat,f['home']),True); ap=db('SELECT * FROM players WHERE chat_id=? AND club=?',(chat,f['away']),True)
        hm=db('SELECT formation,style FROM managers WHERE chat_id=? AND club=?',(chat,f['home']),True); am=db('SELECT formation,style FROM managers WHERE chat_id=? AND club=?',(chat,f['away']),True)
        hpw=engine.squad_power(hp,hm[0]['formation'] if hm else '4-3-3',hm[0]['style'] if hm else 'Balanced'); apw=engine.squad_power(ap,am[0]['formation'] if am else '4-3-3',am[0]['style'] if am else 'Balanced')
        r=engine.play(f['home'],f['away'],hpw,apw)
        def scorer_list(players, count):
            ranked=sorted(players, key=engine.player_power, reverse=True)
            if not ranked or count<=0: return []
            return [ranked[i % min(len(ranked),8)]['name'] for i in range(count)]
        r.scorers_home=scorer_list(hp,r.hs); r.scorers_away=scorer_list(ap,r.ascore)
        db('UPDATE fixtures SET hs=?,ascore=?,played=1 WHERE chat_id=? AND md=? AND home=? AND away=?',(r.hs,r.ascore,chat,md,r.home,r.away)); update_team(chat,r.home,r.hs,r.ascore); update_team(chat,r.away,r.ascore,r.hs); results.append(r)
    db('UPDATE games SET matchday=matchday+1 WHERE chat_id=?',(chat,));
    for r in results: add_news(chat,f'⚽ {r.home} {r.hs} — {r.ascore} {r.away}')
    return md,results

async def match(update,ctx,cb=False):
    chat=update.effective_chat.id
    if not game(chat): text='Сначала /newgame.'; kb=main_kb()
    elif not await is_admin(update,update.effective_user.id): text='Только администратор запускает тур.'; kb=main_kb()
    else:
        md=game(chat)['matchday']; create_round(chat,md); fs=db('SELECT * FROM fixtures WHERE chat_id=? AND md=? AND played=0',(chat,md),True)
        text=f'⚽ ТУР {md}\n\nВыбери режим симуляции:'; kb=InlineKeyboardMarkup([[InlineKeyboardButton('⚡ Быстрая',callback_data='sim:quick'),InlineKeyboardButton('🎙 Обычная',callback_data='sim:normal')],[InlineKeyboardButton('📖 Подробная',callback_data='sim:detailed')]])
    if cb: await update.callback_query.edit_message_text(text,reply_markup=kb)
    else: await update.message.reply_text(text,reply_markup=kb)

async def run_sim(update,ctx):
    q=update.callback_query; await q.answer(); mode=q.data.split(':')[1]; chat=q.message.chat.id
    if not await is_admin(update,q.from_user.id): await q.answer('Только администратор.',show_alert=True); return
    md,res=await asyncio.to_thread(simulate,chat)
    if mode=='quick': body='\n'.join(f'{r.home} {r.hs}:{r.ascore} {r.away}' for r in res)
    elif mode=='normal': body='\n'.join(f'⚽ {r.home} {r.hs}:{r.ascore} {r.away}\n   Голы: {", ".join(r.scorers_home) or "—"} | {", ".join(r.scorers_away) or "—"}' for r in res)
    else:
        lines=[]
        for r in res:
            events='\n'.join([f'  {random.choice([12,24,37,51,68,79])}\' — опасная атака {r.home}',f'  {random.choice([31,44,57,72,86])}\' — момент {r.away}'] + ([f'  ⚽ {r.home} забивает' for _ in range(r.hs)] if r.hs else []) + ([f'  ⚽ {r.away} забивает' for _ in range(r.ascore)] if r.ascore else []))
            lines.append(f'🏟 {r.home} — {r.away}\n{events}\n  ФИНАЛ: {r.hs}:{r.ascore}')
        body='\n\n'.join(lines)
    await q.edit_message_text(f'⚽ ТУР {md}\n\n{body}\n\n📊 Таблица обновлена.',reply_markup=main_kb())

async def news(update,ctx,cb=False):
    chat=update.effective_chat.id; rows=db('SELECT text FROM news WHERE chat_id=? ORDER BY id DESC LIMIT 10',(chat,),True); text='📰 НОВОСТИ\n\n'+'\n'.join(x['text'] for x in rows) if rows else '📰 Пока новостей нет.'
    if cb: await update.callback_query.edit_message_text(text,reply_markup=main_kb())
    else: await update.message.reply_text(text,reply_markup=main_kb())

async def tactics(update,ctx,cb=False):
    chat=update.effective_chat.id; m=manager(chat,update.effective_user.id)
    if not m: text='Сначала вступи в карьеру.'; kb=main_kb()
    else:
        forms=['4-3-3','4-2-3-1','4-4-2','3-5-2','3-4-3','5-3-2']; styles=['Balanced','Possession','Pressing','Counter','Defensive']
        rows=[[InlineKeyboardButton(f,callback_data='formation:'+f) for f in forms[i:i+2]] for i in range(0,len(forms),2)]+[[InlineKeyboardButton(x,callback_data='style:'+x) for x in styles[i:i+2]] for i in range(0,len(styles),2)]
        text=f'🧠 ТАКТИКА\n\nСхема: {m["formation"]}\nСтиль: {m["style"]}'; kb=InlineKeyboardMarkup(rows)
    if cb: await update.callback_query.edit_message_text(text,reply_markup=kb)
    else: await update.message.reply_text(text,reply_markup=kb)

async def set_tactic(update,ctx):
    q=update.callback_query; await q.answer(); chat=q.message.chat.id; uid=q.from_user.id; m=manager(chat,uid)
    if not m:return
    if q.data.startswith('formation:'): db('UPDATE managers SET formation=? WHERE chat_id=? AND user_id=?',(q.data.split(':',1)[1],chat,uid))
    else: db('UPDATE managers SET style=? WHERE chat_id=? AND user_id=?',(q.data.split(':',1)[1],chat,uid))
    await tactics(update,ctx,True)

async def profile_ach(update,ctx):
    q=update.callback_query; a=achievements(q.from_user.id); await q.edit_message_text(f'🏆 ДОСТИЖЕНИЯ\n\nКубки: {a["cups"]}\nЧемпионства: {a["titles"]}\nЕврокубки: {a["europa"]}\nФиналы: {a["finals"]}\nСезонов: {a["seasons"]}',reply_markup=private_main_kb())

async def callbacks(update,ctx):
    q=update.callback_query
    if q.data=='profile_ach': return await profile_ach(update,ctx)
    if q.data=='help': return await help_menu(update,ctx,True)
    if q.data=='help:back':
        if q.message.chat.type=='private':
            p=profile(q.from_user.id); a=achievements(q.from_user.id)
            return await q.edit_message_text(f'⚽ TIME TO MANAGER 26/27\n\n👤 {p["nickname"] if p else q.from_user.first_name}\n\n🏆 Достижения\nКубки: {a["cups"]}\nЧемпионства: {a["titles"]}\nЕврокубки: {a["europa"]}\nСыграно сезонов: {a["seasons"]}',reply_markup=private_main_kb())
        return await q.edit_message_text(help_text(),reply_markup=help_kb())
    if q.data.startswith('help:'): return await help_menu(update,ctx,True,q.data.split(':',1)[1])
    if q.data=='new_game_private': await q.answer('Новую игру можно создать только в группе.',show_alert=True); return
    if q.data=='join': return await join_game(update,ctx)
    if q.data=='finish_lobby': return await finish_lobby(update,ctx)
    if q.data=='pickclub': return await pick_club(update,ctx)
    if q.data=='randomclub': return await random_club(update,ctx)
    if q.data.startswith('takeclub:'): return await take_club(update,ctx)
    if q.data.startswith('lg:'): return await choose_league(update,ctx)
    if q.data.startswith('player:'): return await player_view(update,ctx)
    if q.data.startswith('buy:'): return await buy_player(update,ctx)
    if q.data.startswith('list:'): return await list_player(update,ctx)
    if q.data.startswith('sim:'): return await run_sim(update,ctx)
    if q.data.startswith('formation:') or q.data.startswith('style:'): return await set_tactic(update,ctx)
    await q.answer()
    mp={'career':career,'table':table,'squad':squad,'transfers':transfers,'match':match,'news':news,'fixtures':fixtures,'board':board,'tactics':tactics}
    fn=mp.get(q.data)
    if fn:return await fn(update,ctx,True)

app=FastAPI()
@app.get('/')
async def index(): return FileResponse(WEB/'index.html')
@app.get('/app.js')
async def js(): return FileResponse(WEB/'app.js')
@app.get('/style.css')
async def css(): return FileResponse(WEB/'style.css')

def validate_init_data(init_data):
    if not init_data or not TOKEN:return {}
    data=dict(urllib.parse.parse_qsl(init_data,keep_blank_values=True)); received=data.pop('hash',None)
    if not received:return {}
    secret=hmac.new(b'WebAppData',TOKEN.encode(),hashlib.sha256).digest(); check='\n'.join(f'{k}={data[k]}' for k in sorted(data)); calc=hmac.new(secret,check.encode(),hashlib.sha256).hexdigest()
    return data if hmac.compare_digest(calc,received) else {}

def web_user(req):
    data=validate_init_data(req.headers.get('X-Telegram-Init-Data',''))
    if not data: raise HTTPException(401,'Invalid Telegram initData')
    return json.loads(data['user'])

@app.get('/api/state')
async def api_state(request:Request):
    u=web_user(request); chat=int(request.headers.get('X-Chat-Id','0')); m=manager(chat,u['id'])
    if not m:return {'manager':None}
    rows=db('SELECT * FROM teams WHERE chat_id=? ORDER BY points DESC,(gf-ga) DESC,gf DESC,club',(chat,),True); ps=db('SELECT * FROM players WHERE chat_id=? AND club=? ORDER BY ovr DESC',(chat,m['club']),True); fx=db('SELECT * FROM fixtures WHERE chat_id=? AND (home=? OR away=?) ORDER BY md LIMIT 10',(chat,m['club'],m['club']),True)
    return {'manager':dict(m),'game':dict(game(chat)),'table':[dict(x) for x in rows],'players':[dict(x) for x in ps],'fixtures':[dict(x) for x in fx]}

@app.post('/api/match')
async def api_match(request:Request):
    u=web_user(request); chat=int(request.headers.get('X-Chat-Id','0')); m=manager(chat,u['id'])
    if not m: raise HTTPException(403,'No career')
    md,res=await asyncio.to_thread(simulate,chat); return {'matchday':md,'results':[r.__dict__ for r in res]}

async def telegram_loop():
    if not TOKEN:
        raise RuntimeError('Telegram token is not set. Set BOT_TOKEN (or TELEGRAM_BOT_TOKEN/TOKEN) in the hosting environment.')
    log.info('Starting Telegram polling...')
    bot=Application.builder().token(TOKEN).build()
    for command,fn in [('start',start),('help',help_command),('newgame',newgame),('career',career),('table',table),('squad',squad),('transfers',transfers),('fixtures',fixtures),('match',match),('tactics',tactics)]: bot.add_handler(CommandHandler(command,fn))
    bot.add_handler(CallbackQueryHandler(callbacks)); bot.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,text_nickname))
    await bot.initialize(); await bot.start(); await bot.updater.start_polling(drop_pending_updates=False)
    log.info('Telegram polling started successfully.')
    try:
        while True: await asyncio.sleep(3600)
    finally: await bot.updater.stop(); await bot.stop(); await bot.shutdown()

async def main():
    log.info('Starting Time to Manager on port %s', PORT)
    try:
        server=uvicorn.Server(uvicorn.Config(app,host='0.0.0.0',port=PORT,log_level='info'))
        await asyncio.gather(server.serve(),telegram_loop())
    except Exception:
        log.exception('Bot process stopped with an error')
        raise
if __name__=='__main__': asyncio.run(main())
