# Time to Manager 26/27 — API Server

## Архитектура

Telegram Mini App → FastAPI → SQLite

Отдельно работают:
- `api` — Web App + REST API, порт 8000
- `manager-bot` — основной Telegram-бот
- `match-bot` — матчевый бот

Все три процесса используют одну базу `./state/career.db`.

## Вариант 1 — Docker (рекомендуется)

1. Установить Docker + Docker Compose.
2. Скопировать `.env.example` в `.env`.
3. В `.env` указать:

```env
BOT_TOKEN=токен_от_BotFather
WEBAPP_URL=https://твой-домен.example
```

4. Запустить:

```bash
docker compose up -d --build
```

5. Проверить API:

```bash
curl http://127.0.0.1:8000/api/health
```

Ожидается JSON с `ok: true`.

Swagger API: `https://твой-домен.example/docs`

## Вариант 2 — без Docker

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
python -m uvicorn api_server:app --host 0.0.0.0 --port 8000
```

В отдельном терминале:

```bash
python bot.py
```

Для бота обязательно нужен `BOT_TOKEN`.

## HTTPS

Telegram Mini Apps должны открываться по HTTPS. На VPS обычно ставят Nginx/Caddy перед портом 8000 и получают адрес вроде:

`https://manager.example.com`

Этот адрес указывается как `WEBAPP_URL`.

## API сейчас

- `GET /api/health` — проверка сервера
- `GET /api/state` — состояние карьеры
- `POST /api/match` — провести тур
- `POST /api/tactics` — сохранить тактику
- `POST /api/offer` — сделать трансферное предложение
- `POST /api/offer/decision` — принять/отклонить предложение
- `GET /docs` — Swagger

Авторизация Web App выполняется через Telegram `initData`; сервер проверяет подпись по `BOT_TOKEN`.

## Важно

Не публикуй `BOT_TOKEN` и не клади `.env` в Git.
