

## Career systems added

- **Continental competitions:** Champions League, Europa League and Conference League. Each has a 36-team league phase (8 rounds), play-offs for places 9–24, round of 16, quarter-finals, semi-finals and final. Start the next European round from the dedicated button in the match bot. `/europe` shows the current stage and top eight of each table.
- **Player availability:** injuries have match-based recovery timers; yellow-card accumulation and red cards can cause suspensions. Unavailable players are excluded from match strength.
- **Morale and fitness:** match outcomes and goals affect morale/form, while playing time and rest affect fitness. These attributes affect team strength.
- **Medical overview:** `/medical` in the manager bot and the Web App's “Медштаб” tab show injuries, suspensions, card counters and player morale.
- **European rewards:** continental winners receive a club prize and manager reputation/trust; the win is saved to achievements.

European places for the first season are seeded from squad strength because no previous season table exists; future seasons use the completed domestic standings for the selected playable league. External league participants are drawn from the embedded league database. This is a playable simulation, not an exact reproduction of UEFA's full access-list coefficient rules.

### Форма игроков и случайные события
Форма игроков считается как скользящая оценка последних матчей: учитываются результат команды, голы, сухие матчи и умеренная случайная вариативность индивидуального выступления. Игроки, не выходившие на поле, постепенно возвращаются к нейтральной форме. Физика снижается после участия в матчах и восстанавливается при отдыхе; форма, мораль и физическое состояние влияют на силу состава.

После некоторых туров у управляемых клубов могут происходить случайные события: прорыв молодого игрока, усталость после тренировки, поддержка болельщиков, давление прессы, спонсорский бонус, конфликт в раздевалке, травма на тренировке, восстановительная сессия или премия руководства. События меняют характеристики/доступность игроков, финансы или доверие руководства и сохраняются в новостях. Команда `/events` показывает историю событий клуба; `/medical` показывает травмы, дисквалификации и низкую мораль.
