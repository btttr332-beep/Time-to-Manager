#!/usr/bin/env python3
"""Offline import/validation of EA FC 27 ratings bundled with this project.

Uses only data/ea_fc27_players.csv supplied with the project. No network requests,
no guessed OVRs, and no overwriting of the explicitly estimated RPL ratings.
Players absent from both FC27 and the already-labelled FC26 fallback stay unrated.
"""
from __future__ import annotations
import csv, json
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "football_database.json"
CSV_PATH = ROOT / "data" / "ea_fc27_players.csv"
AUDIT_PATH = ROOT / "data" / "ratings_audit_2026-10-04.json"
FC27_SOURCE = "EA SPORTS FC 27 official ratings export (snapshot 2026-09-12)"
FC26_SOURCE = "EA SPORTS FC 26 via public EA ratings export"
RPL_SOURCE = "rpl_estimated_status_results_2026_27"
PLAYABLE = {"eng_pl", "esp_laliga", "ger_bundesliga", "ita_a", "fra_l1", "rus_rpl"}
POS_GROUP = {
    "GK":"GK", "CB":"DF", "LB":"DF", "RB":"DF", "LWB":"DF", "RWB":"DF",
    "CDM":"MF", "CM":"MF", "CAM":"MF", "LM":"MF", "RM":"MF",
    "LW":"FW", "RW":"FW", "CF":"FW", "ST":"FW"
}
STAT_COLUMNS = [
    "pace", "shooting", "passing", "dribbling", "defending", "physicality",
    "attacking_crossing", "attacking_finishing", "attacking_heading_accuracy",
    "attacking_short_passing", "attacking_volleys", "skill_dribbling", "skill_curve",
    "skill_fk_accuracy", "skill_long_passing", "skill_ball_control", "movement_acceleration",
    "movement_sprint_speed", "movement_agility", "movement_reactions", "movement_balance",
    "power_shot_power", "power_jumping", "power_stamina", "power_strength", "power_long_shots",
    "mentality_aggression", "mentality_interceptions", "mentality_positioning", "mentality_vision",
    "mentality_penalties", "mentality_composure", "defending_awareness", "defending_standing_tackle",
    "defending_sliding_tackle", "goalkeeping_diving", "goalkeeping_handling", "goalkeeping_kicking",
    "goalkeeping_positioning", "goalkeeping_reflexes", "skill_moves", "weak_foot"
]

def int_or_none(v):
    try: return int(v) if v not in (None, "") else None
    except (TypeError, ValueError): return None

def main():
    if not DB_PATH.is_file() or not CSV_PATH.is_file():
        raise SystemExit("Missing embedded database or data/ea_fc27_players.csv")
    with CSV_PATH.open(newline="", encoding="utf-8-sig") as f:
        source_rows = list(csv.DictReader(f))
    source_rows = [r for r in source_rows if r.get("gender") == "Men's Football" and int_or_none(r.get("player_id")) is not None]
    by_ea_id = {int(r["player_id"]): r for r in source_rows}
    if len(by_ea_id) < 17000:
        raise SystemExit(f"Ratings CSV validation failed: only {len(by_ea_id)} unique men's players")

    data = json.loads(DB_PATH.read_text(encoding="utf-8"))
    league_audit = {}
    total_updated = 0
    for league_id, league in data.get("leagues", {}).items():
        if league_id not in PLAYABLE:
            continue
        players = [p for team in league.get("teams", []) for p in team.get("players", [])]
        official27 = fc26 = estimated = missing = 0
        missing_players = []
        for team in league.get("teams", []):
            for p in team.get("players", []):
                if league_id == "rus_rpl":
                    if p.get("rating_source") == RPL_SOURCE and int_or_none(p.get("ovr")) is not None:
                        estimated += 1
                    else:
                        missing_players.append({"club": team.get("name"), "name": p.get("name"), "reason": "RPL rating not marked as estimate"})
                    continue
                ea_id = int_or_none(p.get("ea_player_id"))
                row = by_ea_id.get(ea_id) if ea_id is not None else None
                if row:
                    ovr = int_or_none(row.get("overall_rating"))
                    pos = (row.get("position") or "").upper()
                    if ovr is None or pos not in POS_GROUP:
                        missing_players.append({"club": team.get("name"), "name": p.get("name"), "reason": "invalid source OVR/position"})
                        missing += 1
                        continue
                    p["ovr"] = ovr
                    p["overall"] = ovr
                    p["position_detail"] = pos
                    p["position_alternatives"] = [x.upper() for x in (row.get("alternate_positions") or "").split() if x.upper() in POS_GROUP]
                    p["position"] = POS_GROUP[pos]
                    p["rating_source"] = FC27_SOURCE
                    p["ovr_source"] = FC27_SOURCE
                    p["position_source"] = FC27_SOURCE
                    p["rating_source_name"] = " ".join(x for x in [row.get("first_name", "").strip(), row.get("last_name", "").strip()] if x).strip()
                    p["rating_source_club"] = row.get("club", "")
                    p["rating_match_method"] = "ea_player_id"
                    p["rating_match_confidence"] = 1.0
                    p["ea_player_id"] = int(row["player_id"])
                    if row.get("birthdate"):
                        try:
                            b = date.fromisoformat(row["birthdate"])
                            snap = date(2026, 9, 12)
                            p["age"] = snap.year - b.year - ((snap.month, snap.day) < (b.month, b.day))
                        except ValueError:
                            pass
                    p["country"] = row.get("nationality") or p.get("country", "")
                    p["preferred_foot"] = row.get("preferred_foot") or ""
                    p["playstyles"] = row.get("playstyles") or ""
                    for col in STAT_COLUMNS:
                        v = int_or_none(row.get(col))
                        if v is not None:
                            p[col] = v
                    p["pac"] = int_or_none(row.get("pace"))
                    p["physical"] = int_or_none(row.get("physicality"))
                    total_updated += 1
                    official27 += 1
                elif p.get("rating_source") == FC26_SOURCE and int_or_none(p.get("ovr")) is not None and p.get("position_detail"):
                    fc26 += 1
                elif int_or_none(p.get("ovr")) is None or not p.get("position_detail"):
                    p["rating_status"] = "unrated_not_in_available_official_export"
                    missing_players.append({"club": team.get("name"), "name": p.get("name"), "reason": "not found in supplied FC27 export or labelled FC26 fallback"})
                    missing += 1
                else:
                    # Preserve only an already documented, non-generated source.
                    src = p.get("rating_source", "")
                    if src == FC27_SOURCE:
                        missing_players.append({"club": team.get("name"), "name": p.get("name"), "reason": "EA player ID absent from supplied CSV"})
                        missing += 1
                    else:
                        missing_players.append({"club": team.get("name"), "name": p.get("name"), "reason": f"unrecognized rating source: {src}"})
                        missing += 1
        league_audit[league_id] = {
            "total_players": len(players), "fc27_official": official27, "fc26_fallback": fc26,
            "rpl_estimated": estimated, "unrated_or_unverified": missing,
            "missing_players": missing_players
        }

    data["player_rating_data_source"] = FC27_SOURCE
    data["player_rating_snapshot_date"] = "2026-09-12"
    data["player_rating_import_date"] = "2026-10-04"
    data["player_rating_notes"] = {
        "source": FC27_SOURCE,
        "source_file": "data/ea_fc27_players.csv",
        "source_rows_total": 19789,
        "source_rows_mens": len(source_rows),
        "official_ratings_are_not_estimated": True,
        "rpl_method": "Status/results based estimated ratings requested by user; maximum OVR 81.",
        "unmatched_policy": "No OVR is fabricated for players absent from the supplied FC27 export and labelled FC26 fallback. These players are explicitly marked unrated.",
        "unmatched_by_league": {k: v["unrated_or_unverified"] for k, v in league_audit.items()},
        "unmatched_count": sum(v["unrated_or_unverified"] for v in league_audit.values()),
        "unmatched_players": [dict(league=k, **p) for k, v in league_audit.items() for p in v["missing_players"]],
        "fc26_fallback_count": sum(v["fc26_fallback"] for v in league_audit.values()),
        "fc26_fallback_policy": "FC26 ratings remain labelled FC26 and are preserved only where the existing database has a documented FC26 source and detailed position."
    }
    DB_PATH.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")
    audit = {
        "snapshot_date": "2026-09-12", "source": FC27_SOURCE,
        "source_file": "data/ea_fc27_players.csv", "source_rows_total": 19789,
        "source_rows_mens": len(source_rows), "official_ratings_are_not_estimated": True,
        "total_players_in_six_playable_leagues": sum(v["total_players"] for v in league_audit.values()),
        "total_fc27_official": sum(v["fc27_official"] for v in league_audit.values()),
        "total_fc26_fallback": sum(v["fc26_fallback"] for v in league_audit.values()),
        "total_rpl_estimated": sum(v["rpl_estimated"] for v in league_audit.values()),
        "total_unrated_or_unverified": sum(v["unrated_or_unverified"] for v in league_audit.values()),
        "leagues": league_audit,
        "policy": "Never invent official OVR values. RPL is the sole league with status/results-based estimates, capped at 81 as requested."
    }
    AUDIT_PATH.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in audit.items() if k != "leagues"}, ensure_ascii=False, indent=2))
    for lid, row in league_audit.items():
        print(f"{lid}: total={row['total_players']} FC27={row['fc27_official']} FC26={row['fc26_fallback']} RPL_est={row['rpl_estimated']} missing={row['unrated_or_unverified']}")
    print(f"FC27 rows refreshed from local CSV: {total_updated}")

if __name__ == "__main__":
    main()
