#!/usr/bin/env python3
"""Embed the provided official EA SPORTS FC 27 ratings CSV into the local game database.

This script is used once while building the release archive. It does not use the network
and does not generate OVR or positions. All non-RPL player ratings/positions come directly
from the supplied FC 27 export; RPL stays on the project's separately documented estimate.
"""
import csv, json, hashlib, re, unicodedata
from pathlib import Path
from datetime import date

ROOT = Path(__file__).resolve().parents[1]
CSV_PATH = ROOT / 'data' / 'ea_fc27_players.csv'
DB_PATH = ROOT / 'data' / 'football_database.json'
REPORT_PATH = ROOT / 'data' / 'ratings_audit_2026-10-04.json'
SOURCE = 'EA SPORTS FC 27 official ratings export (snapshot 2026-09-12)'
SNAPSHOT = date(2026, 9, 12)

# Source club display -> the exact club name already used by this project's 2026/27 league.
CLUB_MAP = {
    'eng_pl': {
        'AFC Bournemouth':'AFC Bournemouth','Arsenal':'Arsenal','Aston Villa':'Aston Villa','Brentford':'Brentford',
        'Brighton':'Brighton & Hove Albion','Chelsea':'Chelsea','Coventry City':'Coventry City','Crystal Palace':'Crystal Palace',
        'Everton':'Everton','Fulham':'Fulham','Hull City':'Hull City','Ipswich':'Ipswich Town','Leeds United':'Leeds United',
        'Liverpool':'Liverpool','Man Utd':'Manchester United','Manchester City':'Manchester City','Newcastle Utd':'Newcastle United',
        "Nott'm Forest":'Nottingham Forest','Spurs':'Tottenham Hotspur','Sunderland':'Sunderland',
    },
    'esp_laliga': {
        'Athletic Club':'Athletic Club','Atlético de Madrid':'Atlético de Madrid','CA Osasuna':'CA Osasuna','Celta':'Celta',
        'D. Alavés':'Deportivo Alavés','Elche CF':'Elche CF','FC Barcelona':'FC Barcelona','Getafe CF':'Getafe CF',
        'Levante UD':'Levante UD','Málaga CF':'Málaga CF','R. Racing Club':'Racing Club','Rayo Vallecano':'Rayo Vallecano',
        'RC Deportivo':'RC Deportivo','RCD Espanyol':'RCD Espanyol','Real Betis':'Real Betis','Real Madrid':'Real Madrid',
        'Real Sociedad':'Real Sociedad','Sevilla FC':'Sevilla FC','Valencia CF':'Valencia CF','Villarreal CF':'Villarreal CF',
    },
    'ger_bundesliga': {
        '1. FC Köln':'1. FC Köln','1. FSV Mainz 05':'1. FSV Mainz 05','Borussia Dortmund':'Borussia Dortmund',
        'FC Augsburg':'FC Augsburg','FC Bayern München':'FC Bayern München','FC Schalke 04':'FC Schalke 04',
        'Frankfurt':'Eintracht Frankfurt','Hamburger SV':'Hamburger SV','Leverkusen':'Bayer 04 Leverkusen',
        "M'gladbach":'Borussia Mönchengladbach','RB Leipzig':'RB Leipzig','SC Freiburg':'Sport-Club Freiburg',
        'SC Paderborn 07':'SC Paderborn 07','SV Elversberg':'SV Elversberg','SV Werder Bremen':'SV Werder Bremen',
        'TSG Hoffenheim':'TSG Hoffenheim','Union Berlin':'1. FC Union Berlin','VfB Stuttgart':'VfB Stuttgart',
    },
    'ita_a': {
        'AS Roma':'Roma','Bergamo Calcio':'Atalanta','Bologna':'Bologna','Cagliari':'Cagliari','Como':'Como',
        'Fiorentina':'Fiorentina','Frosinone':'Frosinone','Genoa':'Genoa','Juventus':'Juventus','Latium':'Lazio',
        'Lecce':'Lecce','Lombardia FC':'Inter','Milano FC':'Milan','Monza':'Monza','SSC Napoli':'Napoli',
        'Parma':'Parma','Sassuolo':'Sassuolo','Torino':'Torino','Udinese':'Udinese','Venezia':'Venezia',
    },
    'fra_l1': {
        'AJ Auxerre':'AJ Auxerre','AS Monaco':'AS Monaco','Angers SCO':'Angers SCO','ESTAC Troyes':'ESTAC Troyes',
        'FC Lorient':'FC Lorient','Havre AC':'Le Havre AC','LOSC Lille':'LOSC Lille','Le Mans FC':'Le Mans FC',
        'OGC Nice':'OGC Nice','OL':'Olympique Lyonnais','OM':'Olympique de Marseille','Paris FC':'Paris FC',
        'Paris SG':'Paris Saint-Germain','RC Lens':'RC Lens','Stade Brestois 29':'Stade Brestois 29',
        'Stade Rennais FC':'Stade Rennais FC','Strasbourg':'RC Strasbourg Alsace','Toulouse FC':'Toulouse FC',
    },
}

STAT_FIELDS = [
    'pace','shooting','passing','dribbling','defending','physicality','attacking_crossing','attacking_finishing',
    'attacking_heading_accuracy','attacking_short_passing','attacking_volleys','skill_dribbling','skill_curve',
    'skill_fk_accuracy','skill_long_passing','skill_ball_control','movement_acceleration','movement_sprint_speed',
    'movement_agility','movement_reactions','movement_balance','power_shot_power','power_jumping','power_stamina',
    'power_strength','power_long_shots','mentality_aggression','mentality_interceptions','mentality_positioning',
    'mentality_vision','mentality_penalties','mentality_composure','defending_awareness','defending_standing_tackle',
    'defending_sliding_tackle','goalkeeping_diving','goalkeeping_handling','goalkeeping_kicking',
    'goalkeeping_positioning','goalkeeping_reflexes'
]

def parse_int(v):
    if v is None or str(v).strip() == '': return None
    try: return int(v)
    except (TypeError, ValueError): return None

def norm(s):
    s = str(s or '').strip().lower().replace('’', "'")
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r'[^a-z0-9]+', ' ', s).strip()

def age_at(birthdate):
    try:
        b = date.fromisoformat(birthdate)
        return SNAPSHOT.year - b.year - ((SNAPSHOT.month, SNAPSHOT.day) < (b.month, b.day))
    except Exception:
        return None

def pos_group(pos):
    if pos == 'GK': return 'GK'
    if pos in {'CB','LB','RB','LWB','RWB'}: return 'DF'
    if pos in {'CDM','CM','CAM','LM','RM'}: return 'MF'
    if pos in {'LW','RW','CF','ST'}: return 'FW'
    return 'MF'

def stable_id(ea_id):
    # Disjoint from the existing game's small synthetic IDs and the EA id is stable.
    return 10_000_000_000 + int(ea_id)

def main():
    if not CSV_PATH.exists(): raise SystemExit(f'Missing supplied export: {CSV_PATH}')
    data = json.loads(DB_PATH.read_text(encoding='utf-8'))
    with CSV_PATH.open(newline='', encoding='utf-8-sig') as f:
        source_rows = list(csv.DictReader(f))
    rows = [r for r in source_rows if r.get('gender') == "Men's Football" and r.get('edition') == 'fc27']
    report = {
        'source': SOURCE, 'snapshot_date': '2026-09-12', 'input_rows': len(source_rows),
        'men_fc27_source_rows': len(rows), 'method': 'full roster replacement from exact mapped FC27 club rosters; no OVR/position synthesis',
        'leagues': {}, 'rpl': {'policy':'retain separately documented status/results estimates, max OVR 81'}
    }
    source_league = {
        'eng_pl':'Premier League', 'esp_laliga':'LALIGA EA SPORTS', 'ger_bundesliga':'Bundesliga',
        'ita_a':'Serie A Enilive', 'fra_l1':"Ligue 1 McDonald's"
    }
    for league_id, mapping in CLUB_MAP.items():
        league = data['leagues'][league_id]
        teams_by_name = {t['name']: t for t in league['teams']}
        if set(mapping.values()) != set(teams_by_name):
            raise RuntimeError(f'{league_id}: team-map mismatch; missing={sorted(set(teams_by_name)-set(mapping.values()))}; extra={sorted(set(mapping.values())-set(teams_by_name))}')
        old_by_team = {}
        for team in league['teams']:
            by_ea = {}
            by_name = {}
            for p in team.get('players', []):
                if p.get('ea_player_id') is not None: by_ea[int(p['ea_player_id'])] = p
                by_name[norm(p.get('name'))] = p
            old_by_team[team['name']] = (by_ea, by_name)
        per_team = {}
        seen_ids = set()
        total = 0
        for source_club, target_club in mapping.items():
            team = teams_by_name[target_club]
            club_rows = [r for r in rows if r.get('league') == source_league[league_id] and r.get('club') == source_club]
            if not club_rows:
                raise RuntimeError(f'No official FC27 rows for {league_id}/{target_club} (source club {source_club})')
            imported = []
            old_ea, old_name = old_by_team[target_club]
            for r in club_rows:
                ea_id = parse_int(r.get('player_id'))
                ovr = parse_int(r.get('overall_rating'))
                position = (r.get('position') or '').strip().upper()
                if ea_id is None or ovr is None or not position:
                    raise RuntimeError(f'Incomplete official row in {source_club}: {r}')
                # Keep old internal IDs when the exact EA player or exact normalized name already exists.
                old = old_ea.get(ea_id) or old_name.get(norm((r.get('first_name','')+' '+r.get('last_name','')).strip()))
                internal_id = int(old['id']) if old and old.get('id') is not None else stable_id(ea_id)
                if internal_id in seen_ids:
                    # Rare case: a legacy ID was duplicated in the old JSON; fall back to stable EA namespace.
                    internal_id = stable_id(ea_id)
                if internal_id in seen_ids:
                    raise RuntimeError(f'Duplicate internal player ID: {internal_id}')
                seen_ids.add(internal_id)
                first, last = (r.get('first_name') or '').strip(), (r.get('last_name') or '').strip()
                full = ' '.join(x for x in (first, last) if x).strip()
                common = (r.get('common_name') or '').strip()
                display = common if len(common.split()) > 1 else (full or common)
                alternatives = [x for x in (r.get('alternate_positions') or '').split() if x]
                p = {
                    'id': internal_id, 'name': display, 'short_name': display,
                    'position': pos_group(position), 'age': age_at(r.get('birthdate')),
                    'country': (r.get('nationality') or '').strip() or None, 'jersey': None, 'photo': '',
                    'ovr': ovr, 'overall': ovr, 'position_detail': position,
                    'position_alternatives': alternatives, 'rating_source': SOURCE,
                    'ovr_source': SOURCE, 'position_source': SOURCE,
                    'rating_source_name': display, 'rating_source_club': target_club,
                    'rating_match_method': 'full_club_roster_import', 'rating_match_confidence': 1.0,
                    'ea_player_id': ea_id, 'preferred_foot': (r.get('preferred_foot') or '').strip() or None,
                    'skill_moves': parse_int(r.get('skill_moves')), 'weak_foot': parse_int(r.get('weak_foot')),
                    'playstyles': (r.get('playstyles') or '').strip(), 'birthdate': (r.get('birthdate') or '').strip() or None,
                    'gender': r.get('gender'), 'league_source': r.get('league'), 'club_source': source_club,
                    'edition': r.get('edition'), 'snapshot_date': r.get('snapshot_date'),
                    'potential': None, 'market_value': None,
                }
                for key in STAT_FIELDS:
                    p[key] = parse_int(r.get(key))
                p['pac'] = p['pace']; p['physical'] = p['physicality']
                imported.append(p)
            # Sort by OVR descending then goalkeeper/defender/midfielder/forward order, stable by name.
            imported.sort(key=lambda p: (-p['ovr'], p['position_detail'], p['name'].casefold(), p['ea_player_id']))
            team['players'] = imported
            per_team[target_club] = {'players': len(imported), 'source_club': source_club,
                                     'rated': sum(p['ovr'] is not None and bool(p['position_detail']) for p in imported),
                                     'rating_min': min(p['ovr'] for p in imported), 'rating_max': max(p['ovr'] for p in imported)}
            total += len(imported)
        report['leagues'][league_id] = {
            'name': league.get('name'), 'teams': len(league['teams']), 'players': total,
            'rated': total, 'missing_rating_or_position': 0,
            'official_source': SOURCE, 'team_coverage': per_team
        }
    # Ensure RPL remains the separately requested hand-estimated dataset and obeys the 81 ceiling.
    rpl = data['leagues']['rus_rpl']
    rpl_players = [p for t in rpl['teams'] for p in t.get('players', [])]
    over_cap = [p for p in rpl_players if p.get('ovr') is None or int(p['ovr']) > 81 or not p.get('position_detail')]
    report['rpl'].update({'teams':len(rpl['teams']), 'players':len(rpl_players), 'rated':len(rpl_players)-len(over_cap),
                          'missing_or_over_81':len(over_cap), 'rating_min':min(int(p['ovr']) for p in rpl_players if p.get('ovr') is not None),
                          'rating_max':max(int(p['ovr']) for p in rpl_players if p.get('ovr') is not None)})
    if over_cap:
        raise RuntimeError(f'RPL constraints violated: {len(over_cap)} players missing rating/position or above 81')
    data['player_rating_data_source'] = SOURCE
    data['player_rating_snapshot_date'] = '2026-09-12'
    data['player_rating_import_date'] = '2026-10-04'
    data['player_rating_notes'] = {
        'official_leagues': 'All player OVR, primary/alternate positions, and published attributes in eng_pl, esp_laliga, ger_bundesliga, ita_a and fra_l1 are imported from the provided EA SPORTS FC 27 official ratings API export snapshot dated 2026-09-12. No OVR or position values are generated for these leagues.',
        'rpl': 'Russian Premier League ratings are separate game estimates based on club status, player role and results as requested; all OVR values are capped at 81 and are not represented as EA ratings.',
        'potential': 'The supplied CSV does not publish potential or market value. These fields remain null in imported official rows instead of being invented.'
    }
    # Cross-check all official records and all club counts before writing.
    for lid, league_report in report['leagues'].items():
        for team in data['leagues'][lid]['teams']:
            for p in team['players']:
                if p.get('rating_source') != SOURCE or p.get('ovr') is None or not p.get('position_detail'):
                    raise RuntimeError(f'Non-official or incomplete player left in official league {lid}/{team["name"]}: {p.get("name")}')
    DB_PATH.write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: {'players':v['players'],'teams':v['teams'],'rated':v['rated'],'missing':v['missing_rating_or_position']} for k,v in report['leagues'].items()}, ensure_ascii=False, indent=2))
    print('RPL:', json.dumps(report['rpl'], ensure_ascii=False))

if __name__ == '__main__': main()
