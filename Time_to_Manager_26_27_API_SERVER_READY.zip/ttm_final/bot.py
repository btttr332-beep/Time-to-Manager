import os, json, random, sqlite3, asyncio, urllib.parse, hmac, hashlib, logging, sys, threading, time
from pathlib import Path
from contextlib import closing, contextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters
import uvicorn
from game.provider import SquadProvider
from game.engine import GameEngine

BASE = Path(__file__).parent
LOG_DIR = BASE / 'logs'
LOG_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(name)s | %(message)s', handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(LOG_DIR / 'bot.log', encoding='utf-8')], force=True)
log = logging.getLogger('time_to_manager')
print('Time to Manager process starting...', flush=True)

DB = Path(os.getenv('DATABASE_PATH', str(BASE / 'career.db')))
DB.parent.mkdir(parents=True,exist_ok=True)
WEB = BASE / 'web'
TOKEN = (os.getenv('BOT_TOKEN') or os.getenv('TELEGRAM_BOT_TOKEN') or os.getenv('TOKEN') or '').strip()
WEBAPP_URL = os.getenv('WEBAPP_URL', '').strip().rstrip('/')
PORT = int(os.getenv('PORT', '8000'))
ENABLE_WEBAPP = (os.getenv('ENABLE_WEBAPP', '1').strip().lower() not in {'0','false','no'})
META = json.loads((BASE / 'data/leagues.json').read_text(encoding='utf8'))['leagues']
provider = SquadProvider()
engine = GameEngine(None)
conn = sqlite3.connect(DB, check_same_thread=False, timeout=15)
conn.execute('PRAGMA busy_timeout=15000')
conn.execute('PRAGMA journal_mode=WAL')
conn.row_factory = sqlite3.Row
DB_LOCK = threading.RLock()
SIM_LOCK = threading.RLock()
TX_ACTIVE = False

def db(sql, args=(), fetch=False, many=False):
    with DB_LOCK:
        with closing(conn.cursor()) as c:
            c.executemany(sql, args) if many else c.execute(sql, args)
            out = c.fetchall() if fetch else c.lastrowid
            if not TX_ACTIVE: conn.commit()
            return out

@contextmanager
def transaction():
    global TX_ACTIVE
    with DB_LOCK:
        conn.execute('BEGIN IMMEDIATE')
        TX_ACTIVE = True
        try:
            yield
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            TX_ACTIVE = False

def init_db():
    db('''CREATE TABLE IF NOT EXISTS profiles(user_id INTEGER PRIMARY KEY,nickname TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    db('''CREATE TABLE IF NOT EXISTS achievements(user_id INTEGER PRIMARY KEY,cups INTEGER DEFAULT 0,titles INTEGER DEFAULT 0,europa INTEGER DEFAULT 0,finals INTEGER DEFAULT 0,seasons INTEGER DEFAULT 0)''')
    db('''CREATE TABLE IF NOT EXISTS games(chat_id INTEGER PRIMARY KEY,league_key TEXT,season INTEGER DEFAULT 1,phase TEXT DEFAULT 'lobby',matchday INTEGER DEFAULT 1,season_year TEXT DEFAULT '2026/27',max_seasons INTEGER DEFAULT 5,europe_round INTEGER DEFAULT 1)''')
    db('''CREATE TABLE IF NOT EXISTS managers(user_id INTEGER,chat_id INTEGER,nickname TEXT,username TEXT,club TEXT,reputation INTEGER DEFAULT 50,money INTEGER DEFAULT 100000000,wage_budget INTEGER DEFAULT 2500000,trust INTEGER DEFAULT 70,objective TEXT DEFAULT 'Финишировать в верхней половине таблицы',formation TEXT DEFAULT '4-3-3',style TEXT DEFAULT 'Balanced',wins INTEGER DEFAULT 0,draws INTEGER DEFAULT 0,losses INTEGER DEFAULT 0,PRIMARY KEY(user_id,chat_id),UNIQUE(chat_id,club))''')
    db('''CREATE TABLE IF NOT EXISTS teams(chat_id INTEGER,club TEXT,team_id INTEGER,logo TEXT,stadium_name TEXT,stadium_city TEXT,capacity INTEGER,played INTEGER DEFAULT 0,won INTEGER DEFAULT 0,draw INTEGER DEFAULT 0,lost INTEGER DEFAULT 0,gf INTEGER DEFAULT 0,ga INTEGER DEFAULT 0,points INTEGER DEFAULT 0,PRIMARY KEY(chat_id,club))''')
    db('''CREATE TABLE IF NOT EXISTS players(chat_id INTEGER,club TEXT,player_id INTEGER,name TEXT,short_name TEXT,pos TEXT,age INTEGER,country TEXT,jersey INTEGER,photo TEXT,ovr INTEGER,potential INTEGER,value INTEGER,salary INTEGER,form INTEGER,morale INTEGER,fitness INTEGER,injured INTEGER DEFAULT 0,suspended INTEGER DEFAULT 0,rating_source TEXT,injury_matches INTEGER DEFAULT 0,suspension_matches INTEGER DEFAULT 0,yellow_cards INTEGER DEFAULT 0,red_cards INTEGER DEFAULT 0,PRIMARY KEY(chat_id,club,player_id))''')
    db('''CREATE TABLE IF NOT EXISTS fixtures(chat_id INTEGER,md INTEGER,home TEXT,away TEXT,hs INTEGER,ascore INTEGER,played INTEGER DEFAULT 0,PRIMARY KEY(chat_id,md,home,away))''')
    db('''CREATE TABLE IF NOT EXISTS fixture_history(chat_id INTEGER,season INTEGER,md INTEGER,home TEXT,away TEXT,hs INTEGER,ascore INTEGER,PRIMARY KEY(chat_id,season,md,home,away))''')
    # Career systems: European cups, player availability and persistent discipline counters.
    game_columns={row['name'] for row in db('PRAGMA table_info(games)',(),True)}
    if 'europe_round' not in game_columns: db('ALTER TABLE games ADD COLUMN europe_round INTEGER DEFAULT 1')
    player_columns={row['name'] for row in db('PRAGMA table_info(players)',(),True)}
    for col,decl in [('injury_matches','INTEGER DEFAULT 0'),('suspension_matches','INTEGER DEFAULT 0'),('yellow_cards','INTEGER DEFAULT 0'),('red_cards','INTEGER DEFAULT 0')]:
        if col not in player_columns: db(f'ALTER TABLE players ADD COLUMN {col} {decl}')
    db('''CREATE TABLE IF NOT EXISTS europe_teams(chat_id INTEGER,season INTEGER,competition TEXT,club TEXT,league_key TEXT,strength REAL,seed INTEGER DEFAULT 0,played INTEGER DEFAULT 0,won INTEGER DEFAULT 0,draw INTEGER DEFAULT 0,lost INTEGER DEFAULT 0,gf INTEGER DEFAULT 0,ga INTEGER DEFAULT 0,points INTEGER DEFAULT 0,qualified INTEGER DEFAULT 0,PRIMARY KEY(chat_id,season,competition,club))''')
    db('''CREATE TABLE IF NOT EXISTS europe_fixtures(chat_id INTEGER,season INTEGER,competition TEXT,round_no INTEGER,home TEXT,away TEXT,hs INTEGER,ascore INTEGER,played INTEGER DEFAULT 0,PRIMARY KEY(chat_id,season,competition,round_no,home,away))''')
    db('''CREATE TABLE IF NOT EXISTS europe_champions(chat_id INTEGER,season INTEGER,competition TEXT,champion TEXT,PRIMARY KEY(chat_id,season,competition))''')
    if 'rating_source' not in player_columns:
        db('ALTER TABLE players ADD COLUMN rating_source TEXT')
        db("UPDATE players SET rating_source='legacy_unverified' WHERE rating_source IS NULL")
    db('''CREATE TABLE IF NOT EXISTS transfers(id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id INTEGER,player_id INTEGER,player_name TEXT,from_club TEXT,to_club TEXT,fee INTEGER,kind TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    db('''CREATE TABLE IF NOT EXISTS transfer_offers(id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id INTEGER,player_id INTEGER,from_club TEXT,to_club TEXT,fee INTEGER,source_user INTEGER DEFAULT 0,status TEXT DEFAULT 'pending')''')
    db('''CREATE TABLE IF NOT EXISTS news(id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id INTEGER,text TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    db('''CREATE TABLE IF NOT EXISTS random_events(chat_id INTEGER,season INTEGER,md INTEGER,club TEXT,event_type TEXT,text TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(chat_id,season,md,club))''')
    db('''CREATE TABLE IF NOT EXISTS nickname_wait(user_id INTEGER PRIMARY KEY)''')
    db("UPDATE transfer_offers SET status='superseded' WHERE status='pending' AND id NOT IN (SELECT MIN(id) FROM transfer_offers WHERE status='pending' GROUP BY chat_id,player_id,to_club)")
    db("CREATE UNIQUE INDEX IF NOT EXISTS idx_one_pending_offer ON transfer_offers(chat_id,player_id,to_club) WHERE status='pending'")
    # Repair legacy duplicate player IDs across clubs without touching club names or saved careers.
    duplicate_groups=db('SELECT chat_id,player_id,COUNT(*) AS n FROM players GROUP BY chat_id,player_id HAVING COUNT(*)>1',(),True)
    for group in duplicate_groups:
        legacy=db('SELECT club,name FROM players WHERE chat_id=? AND player_id=?',(group['chat_id'],group['player_id']),True)
        for row in legacy:
            new_id=int(hashlib.sha256(f'legacy:{group["chat_id"]}:{row["club"]}:{group["player_id"]}:{row["name"]}'.encode()).hexdigest()[:15],16)
            db('UPDATE players SET player_id=? WHERE chat_id=? AND player_id=? AND club=?',(new_id,group['chat_id'],group['player_id'],row['club']))
            db('UPDATE transfer_offers SET player_id=? WHERE chat_id=? AND player_id=? AND from_club=?',(new_id,group['chat_id'],group['player_id'],row['club']))
            db('UPDATE transfers SET player_id=? WHERE chat_id=? AND player_id=? AND from_club=?',(new_id,group['chat_id'],group['player_id'],row['club']))

def backfill_saved_player_ratings():
    """Replace legacy ratings only when an exact sourced player match exists."""
    try:
        from tools.import_fc27_ratings import norm, club_norm
    except Exception:
        return
    valid={'EA SPORTS FC 27 official ratings export (snapshot 2026-09-12)','EA SPORTS FC 27 via FCCareer','EA SPORTS FC 26 via public EA ratings export','rpl_estimated_status_results_2026_27'}
    games=db('SELECT chat_id,league_key FROM games',(),True)
    repaired=0; unresolved=0
    for g in games:
        league=provider.database.get('leagues',{}).get(g['league_key'],{})
        index={}
        for team in league.get('teams',[]):
            for p in team.get('players',[]):
                if p.get('rating_source') not in valid or p.get('ovr') is None or not p.get('position_detail'):
                    continue
                index.setdefault(norm(p.get('name')),[]).append((team.get('name',''),p))
        saved=db('SELECT * FROM players WHERE chat_id=?',(g['chat_id'],),True)
        for old in saved:
            if old['rating_source'] in valid and old['ovr'] is not None:
                continue
            candidates=index.get(norm(old['name']),[])
            if len(candidates)>1:
                exact_club=[item for item in candidates if club_norm(item[0])==club_norm(old['club'])]
                if len(exact_club)==1: candidates=exact_club
            if len(candidates)!=1:
                db("UPDATE players SET rating_source='legacy_unverified' WHERE chat_id=? AND club=? AND player_id=?",(g['chat_id'],old['club'],old['player_id']))
                unresolved+=1
                continue
            _,src=candidates[0]
            value=int(src.get('market_value') or old['value'] or 0)
            salary=int(value*.012) if value else (old['salary'] or 0)
            db("UPDATE players SET pos=?,age=?,country=?,ovr=?,potential=?,value=?,salary=?,rating_source=? WHERE chat_id=? AND club=? AND player_id=?",
               (src.get('position_detail') or src.get('position'),src.get('age'),src.get('country') or src.get('nation'),src.get('ovr'),src.get('potential'),value,salary,src.get('rating_source'),g['chat_id'],old['club'],old['player_id']))
            repaired+=1
    if repaired or unresolved:
        log.info('Saved career rating migration: verified=%d; legacy/unmatched=%d',repaired,unresolved)

init_db()
backfill_saved_player_ratings()

def profile(uid):
    r = db('SELECT * FROM profiles WHERE user_id=?', (uid,), True); return r[0] if r else None

def achievements(uid):
    r = db('SELECT * FROM achievements WHERE user_id=?', (uid,), True)
    return r[0] if r else db('INSERT OR IGNORE INTO achievements(user_id) VALUES(?)', (uid,)) and db('SELECT * FROM achievements WHERE user_id=?',(uid,),True)[0]

def game(chat):
    r = db('SELECT * FROM games WHERE chat_id=?', (chat,), True); return r[0] if r else None

def manager(chat, uid):
    r = db('SELECT * FROM managers WHERE chat_id=? AND user_id=?', (chat, uid), True); return r[0] if r else None

def active_career_chat(uid):
    rows=db('SELECT m.chat_id FROM managers m JOIN games g ON g.chat_id=m.chat_id WHERE m.user_id=? AND m.club IS NOT NULL ORDER BY g.season DESC,m.chat_id DESC',(uid,),True)
    for row in rows:
        if game(row['chat_id']): return int(row['chat_id'])
    return None

def context_chat(update):
    chat=update.effective_chat
    if chat and chat.type=='private': return active_career_chat(update.effective_user.id) or chat.id
    return chat.id if chat else 0

async def guarded_management_command(update,ctx,fn):
    chat=update.effective_chat
    g=game(chat.id) if chat and chat.type!='private' else None
    if g and g['phase']!='lobby':
        await update.message.reply_text('Управление клубом доступно в личном чате с основным ботом. Эта группа используется для матчей через отдельный бот матчей.')
        return
    await fn(update,ctx)

def add_news(chat, text): db('INSERT INTO news(chat_id,text) VALUES(?,?)', (chat, text))

def backup_database(tag='manual'):
    folder=DB.parent/'backups'; folder.mkdir(parents=True,exist_ok=True)
    stamp=time.strftime('%Y%m%d_%H%M%S',time.gmtime())
    target=folder/f'career_{tag}_{stamp}.db'
    with DB_LOCK:
        dest=sqlite3.connect(target)
        try: conn.backup(dest)
        finally: dest.close()
    old=sorted(folder.glob('career_*.db'),key=lambda p:p.stat().st_mtime,reverse=True)
    for stale in old[10:]:
        try: stale.unlink()
        except OSError: pass
    log.info('Database backup created: %s',target.name)
    return target

def nickname_for(user):
    p = profile(user.id)
    return p['nickname'] if p else (user.first_name or f'Manager{user.id}')

def private_main_kb(uid=None):
    """Show only onboarding items until this user actually owns a club."""
    rows=[]
    if WEBAPP_URL: rows.append([InlineKeyboardButton('📱 Web App', web_app=WebAppInfo(url=WEBAPP_URL))])
    has_career = bool(uid is not None and active_career_chat(int(uid)) is not None)
    if has_career:
        rows += [[InlineKeyboardButton('👔 Моя карьера', callback_data='career'), InlineKeyboardButton('👥 Состав', callback_data='squad')],
                 [InlineKeyboardButton('💼 Трансферы', callback_data='transfers'), InlineKeyboardButton('📅 Календарь', callback_data='fixtures')],
                 [InlineKeyboardButton('📊 Таблица', callback_data='table'), InlineKeyboardButton('🧠 Тактика', callback_data='tactics')],
                 [InlineKeyboardButton('🎯 Руководство', callback_data='board'), InlineKeyboardButton('📰 Новости', callback_data='news')],
                 [InlineKeyboardButton('🩺 Медштаб', callback_data='medical'), InlineKeyboardButton('🎲 События', callback_data='events')],
                 [InlineKeyboardButton('🏆 Достижения', callback_data='profile_ach'), InlineKeyboardButton('❓ Подсказки', callback_data='help')]]
    else:
        rows += [[InlineKeyboardButton('🏆 Достижения', callback_data='profile_ach')],
                 [InlineKeyboardButton('❓ Подсказки', callback_data='help')]]
    return InlineKeyboardMarkup(rows)

def menu_for(update):
    chat=update.effective_chat
    if chat and chat.type=='private':
        return private_main_kb(update.effective_user.id)
    return main_kb()

def help_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton('🏠 Клуб', callback_data='help:club'), InlineKeyboardButton('👥 Состав', callback_data='help:squad')],
        [InlineKeyboardButton('🔄 Трансферы', callback_data='help:transfers'), InlineKeyboardButton('⚽ Матчи', callback_data='help:matches')],
        [InlineKeyboardButton('💰 Финансы', callback_data='help:finances'), InlineKeyboardButton('📋 Руководство', callback_data='help:board')],
        [InlineKeyboardButton('🏆 Турниры', callback_data='help:tournaments'), InlineKeyboardButton('🧠 Тактика', callback_data='help:tactics')],
        [InlineKeyboardButton('📅 Календарь', callback_data='help:calendar'), InlineKeyboardButton('⬅️ В меню', callback_data='help:back')]
    ])

def help_text(topic=None):
    topics = {
        'club': '🏠 КЛУБ\n\n/career — открыть твою карьеру: клуб, бюджет, репутацию, доверие и цель сезона.',
        'squad': '👥 СОСТАВ\n\n/squad — открыть состав и управлять своей командой. Карточки игроков показывают OVR, возраст, форму, мораль, физику, стоимость, зарплату и потенциал.',
        'transfers': '🔄 ТРАНСФЕРЫ\n\n/transfers — рынок игроков. Здесь можно покупать игроков, продавать своих и выставлять игроков на трансфер. Предложения и стоимость зависят от игрока и сделки.',
        'matches': '⚽ МАТЧИ\n\nСимуляция и результаты доступны через отдельного бота матчей в группе. В основном боте календарь доступен командой /fixtures.',
        'finances': '💰 ФИНАНСЫ\n\nБюджет клуба используется для трансферов и других расходов. Следи за стоимостью сделок и зарплатами игроков.',
        'board': '📋 РУКОВОДСТВО\n\nЗдесь отображается цель совета директоров и доверие к менеджеру. По итогам сезона выполнение целей влияет на продолжение карьеры.',
        'tournaments': '🏆 ТУРНИРЫ\n\nВ карьере учитываются национальный чемпионат, кубковые турниры и еврокубки. Квалификация в Европу зависит от итогового места в чемпионате.',
        'tactics': '🧠 ТАКТИКА\n\n/tactics — выбор схемы и стиля игры. Настройки влияют на силу команды при симуляции матчей.',
        'calendar': '📅 КАЛЕНДАРЬ\n\n/fixtures — ближайшие матчи и расписание сезона. /match — переход к симуляции текущего тура.'
    }
    if topic in topics:
        return topics[topic]
    return ('❓ ПОДСКАЗКИ\n\n'
            '/start — профиль и главное меню\n'
            '/career — моя карьера и клуб\n'
            '/squad — состав команды\n'
            '/transfers — трансферы и переговоры\n'
            '/tactics — тактика и схема\n'
            '/fixtures — календарь\n'
            '/europe — таблицы и этап еврокубков\n'
            '/medical — травмы, дисквалификации и мораль\n'
            '/events — история случайных событий клуба\n'
            'Матчи — через отдельного бота матчей в группе\n'
            '/table — турнирная таблица\n'
            '/board — требования руководства\n'
            '/help — открыть это меню\n\n'
            'Нажми кнопку ниже, чтобы узнать подробнее о каждом разделе.')

async def help_menu(update,ctx,cb=False,topic=None):
    text=help_text(topic)
    if cb:
        await update.callback_query.edit_message_text(text,reply_markup=help_kb())
    else:
        await update.message.reply_text(text,reply_markup=help_kb())

async def ratings_command(update,ctx):
    lines=['📊 ПОКРЫТИЕ РЕЙТИНГОВ И ПОЗИЦИЙ','Источник EA FC27 импортируется один раз и сохраняется локально. Неподтверждённые рейтинги не генерируются.']
    for key,meta in META.items():
        if not meta.get('playable'):
            continue
        status=provider.rating_status.get(key,{'total':0,'rated':0,'missing':0,'complete':False})
        mark='✅' if status.get('complete') else '⚠️'
        lines.append(f'{mark} {meta["name"]}: {status.get("rated",0)}/{status.get("total",0)}; не подтверждено: {status.get("missing",0)}')
    if provider.rating_import_error:
        lines.append('Источник пока недоступен: '+provider.rating_import_error[:220])
    await update.effective_message.reply_text('\n'.join(lines))


async def help_command(update,ctx):
    await help_menu(update,ctx)

def main_kb():
    rows=[]
    if WEBAPP_URL: rows.append([InlineKeyboardButton('📱 Web App', web_app=WebAppInfo(url=WEBAPP_URL))])
    rows += [[InlineKeyboardButton('👔 Моя карьера',callback_data='career'),InlineKeyboardButton('📊 Таблица',callback_data='table')],
             [InlineKeyboardButton('👥 Состав',callback_data='squad'),InlineKeyboardButton('💼 Трансферы',callback_data='transfers')],
             [InlineKeyboardButton('📅 Календарь',callback_data='fixtures'),InlineKeyboardButton('🎯 Руководство',callback_data='board')],
             [InlineKeyboardButton('🧠 Тактика',callback_data='tactics'),InlineKeyboardButton('📰 Новости',callback_data='news')],
             [InlineKeyboardButton('❓ Подсказки',callback_data='help')]]
    return InlineKeyboardMarkup(rows)

def admin(uid, chat):
    try:
        member = _admin_cache.get((chat,uid)); return bool(member)
    except NameError: return False
_admin_cache = {}

async def is_admin(update, uid=None, bot=None):
    chat=update.effective_chat; uid=uid or update.effective_user.id
    if not chat or chat.type=='private': return False
    bot=bot or (update.get_bot() if hasattr(update,'get_bot') else None)
    if bot is None: return False
    member=await bot.get_chat_member(chat_id=chat.id,user_id=uid)
    ok=member.status in ('administrator','creator'); _admin_cache[(chat.id,uid)]=ok; return ok

async def start(update,ctx):
    uid=update.effective_user.id
    chat=update.effective_chat
    p=profile(uid)
    if chat.type!='private':
        if not p:
            await update.message.reply_text('👋 Профиль создаётся в личном чате с основным ботом. Открой бота в личке и нажми /start.')
            return
        g=game(chat.id); m=manager(chat.id,uid)
        if g and g['phase']!='lobby':
            detail=f' Твой клуб: {m["club"]}.' if m and m['club'] else ''
            await update.message.reply_text(f'👋 С возвращением, {p["nickname"]}!{detail} Управление — в личном чате с основным ботом; эта группа предназначена для матчей.')
        elif g:
            await update.message.reply_text(f'👋 Профиль {p["nickname"]} уже создан. Для участия используй кнопку в сообщении набора менеджеров.')
        else:
            await update.message.reply_text(f'👋 Профиль {p["nickname"]} уже создан. Администратор может начать карьеру командой /newgame.')
        return
    if not p:
        db('INSERT OR REPLACE INTO nickname_wait(user_id) VALUES(?)',(uid,))
        await update.message.reply_text('⚽ TIME TO MANAGER 26/27\n\nДобро пожаловать!\n\nПридумай свой игровой ник:')
        return
    a=achievements(uid)
    mrows=db('SELECT m.club,g.league_key,g.season,g.season_year FROM managers m JOIN games g ON g.chat_id=m.chat_id WHERE m.user_id=? AND m.club IS NOT NULL ORDER BY g.season DESC LIMIT 5',(uid,),True)
    careers='\n\nТвои карьеры:\n'+'\n'.join(f'• {r["club"]} · {META.get(r["league_key"],{}).get("name",r["league_key"])} · сезон {r["season_year"]}' for r in mrows) if mrows else '\n\nУ тебя пока нет активной карьеры. Присоединись к набору менеджеров в группе.'
    await update.message.reply_text(f'⚽ TIME TO MANAGER 26/27\n\n👤 {p["nickname"]}{careers}\n\n🏆 Достижения\nКубки: {a["cups"]}\nЧемпионства: {a["titles"]}\nЕврокубки: {a["europa"]}\nСыграно сезонов: {a["seasons"]}', reply_markup=private_main_kb(uid))

async def text_nickname(update,ctx):
    if update.effective_chat.type!='private': return
    uid=update.effective_user.id
    if not db('SELECT 1 FROM nickname_wait WHERE user_id=?',(uid,),True): return
    nick=update.message.text.strip().lstrip('@')[:24]
    if len(nick)<2: await update.message.reply_text('Ник должен содержать минимум 2 символа.'); return
    db('DELETE FROM nickname_wait WHERE user_id=?',(uid,)); db('INSERT OR REPLACE INTO profiles(user_id,nickname) VALUES(?,?)',(uid,nick)); db('INSERT OR IGNORE INTO achievements(user_id) VALUES(?)',(uid,))
    await update.message.reply_text(f'✅ Профиль создан.\n\n👤 {nick}', reply_markup=private_main_kb(uid))

async def newgame(update,ctx):
    if update.effective_chat.type=='private':
        await update.message.reply_text('🎮 Новую карьеру можно начать только в группе. Добавь бота в группу и используй /newgame.')
        return
    if not profile(update.effective_user.id):
        await update.message.reply_text('Сначала открой личный чат с ботом и создай профиль через /start.')
        return
    if not await is_admin(update,bot=ctx.bot):
        await update.message.reply_text('Только администратор группы может начать новую игру.')
        return
    if game(update.effective_chat.id): await update.message.reply_text('В этой группе уже есть активная карьера.'); return
    rows=[]; unavailable=[]
    for key,m in META.items():
        if not (m.get('playable') and key in provider.database.get('leagues',{}) and provider.database['leagues'][key].get('teams')):
            continue
        status=provider.rating_status.get(key,{'complete':False,'missing':0})
        if provider.is_ratings_complete(key):
            rows.append([InlineKeyboardButton(f'{m["country"]} — {m["name"]}',callback_data='lg:'+key)])
        else:
            unavailable.append(f'{m["name"]}: не подтверждены рейтинги у {status.get("missing",0)} игроков')
    if not rows:
        await update.message.reply_text('⛔ Нельзя создать карьеру: нет ни одной лиги с полным набором подтверждённых рейтингов.\n\nОсновной бот не придумывает OVR и позиции. Проверь источник FC27 рейтингов и список игроков команд.\n\n'+ '\n'.join(unavailable))
        return
    suffix='\n\nНе готовы: '+'; '.join(unavailable) if unavailable else ''
    await update.message.reply_text('🏆 НОВАЯ КАРЬЕРА\n\nДоступны только лиги, где у каждого игрока есть подтверждённый рейтинг и позиция.\nАдминистратор выбирает лигу:'+suffix,reply_markup=InlineKeyboardMarkup(rows))

async def choose_league(update,ctx):
    q=update.callback_query; chat=q.message.chat
    if not await is_admin(update,q.from_user.id,ctx.bot): await q.answer('Только администратор.',show_alert=True); return
    key=q.data[3:]
    if key not in META or not META[key].get('playable'): await q.answer('Эта лига сейчас скрыта.',show_alert=True); return
    if not provider.is_ratings_complete(key):
        status=provider.rating_status.get(key,{'missing':0})
        await q.answer(f'Нельзя начать: у {status.get("missing",0)} игроков нет подтверждённого рейтинга/позиции.',show_alert=True); return
    league=provider.load_league(key)
    if game(chat.id): await q.answer('В этой группе уже существует карьера.',show_alert=True); return
    started=time.perf_counter()
    db('INSERT INTO games(chat_id,league_key,season,phase,matchday,season_year,max_seasons) VALUES(?,?,1,\'lobby\',1,\'2026/27\',5)',(chat.id,key))
    team_rows=[]; player_rows=[]
    for t in league['teams']:
        stadium=t.get('stadium',{})
        team_rows.append((chat.id,t['name'],t['id'],t.get('logo',''),stadium.get('name',''),stadium.get('city',''),stadium.get('capacity',0)))
        for raw in t.get('players',[]):
            p=engine.derive_attributes(raw, t['name'])
            # IDs must be unique across the whole league: raw source IDs collide in some squads.
            unique_id=int(hashlib.sha256(f'{key}:{t["name"]}:{raw.get("id")}:{raw.get("name")}'.encode()).hexdigest()[:15],16)
            player_rows.append((chat.id,t['name'],unique_id,p['name'],p.get('short_name') or p['name'],p['pos'],p.get('age'),p.get('country'),p.get('jersey'),p.get('photo'),p['ovr'],p['potential'],p['value'],p['salary'],p['form'],p['morale'],p['fitness'],p.get('rating_source')))
    db('INSERT OR IGNORE INTO teams(chat_id,club,team_id,logo,stadium_name,stadium_city,capacity) VALUES(?,?,?,?,?,?,?)',team_rows,many=True)
    db('INSERT OR IGNORE INTO players(chat_id,club,player_id,name,short_name,pos,age,country,jersey,photo,ovr,potential,value,salary,form,morale,fitness,rating_source) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',player_rows,many=True)
    create_full_calendar(chat.id)
    log.info('League %s created for chat %s: %d clubs, %d players in %.3fs',key,chat.id,len(team_rows),len(player_rows),time.perf_counter()-started)
    db('UPDATE games SET phase=\'lobby\' WHERE chat_id=?',(chat.id,))
    kb=InlineKeyboardMarkup([[InlineKeyboardButton('🙋 Войти в набор',callback_data='join')],[InlineKeyboardButton('🔒 Завершить набор',callback_data='finish_lobby')]])
    await q.edit_message_text(f'🏆 {META[key]["name"]} · 2026/27\n\n👥 Набор менеджеров открыт.\nНажми «Войти в набор».\n\nПосле завершения набора администратор распределит клубы.',reply_markup=kb)

async def join_game(update,ctx):
    q=update.callback_query; chat=q.message.chat.id; uid=q.from_user.id
    if not profile(uid): await q.answer('Сначала зайди к боту в личку и создай профиль.',show_alert=True); return
    g=game(chat)
    if not g or g['phase']!='lobby': await q.answer('Набор уже закрыт.',show_alert=True); return
    p=profile(uid)
    already_joined = manager(chat,uid) is not None
    if not already_joined:
        db('INSERT OR IGNORE INTO managers(user_id,chat_id,nickname,username,club) VALUES(?,?,?,?,NULL)',(uid,chat,p['nickname'],q.from_user.username))
    joined=db('SELECT nickname FROM managers WHERE chat_id=?',(chat,),True)
    if already_joined:
        await q.answer('Ты уже в наборе.')
    else:
        await q.answer('Ты вошёл в набор!')
    lobby_kb=InlineKeyboardMarkup([
        [InlineKeyboardButton('🙋 Войти в набор',callback_data='join')],
        [InlineKeyboardButton('🔒 Завершить набор',callback_data='finish_lobby')]
    ])
    await q.edit_message_text(
        '👥 НАБОР МЕНЕДЖЕРОВ\n\n'
        + ('\n'.join(f'• {x["nickname"]}' for x in joined) if joined else 'Пока никто не присоединился.')
        + '\n\nНажимайте «Войти в набор». Администратор завершит набор, когда все готовы.',
        reply_markup=lobby_kb
    )

def estimate_club_budget(chat, club):
    """Estimate a club-appropriate transfer budget from its actual squad value."""
    g=game(chat)
    players=db('SELECT value,salary,ovr,form,morale,fitness FROM players WHERE chat_id=? AND club=?',(chat,club),True)
    if not players:
        return 1_500_000, 250_000
    squad_value=sum(max(0,int(p['value'] or 0)) for p in players)
    avg_ovr=sum(int(p['ovr'] or 0) for p in players)/len(players)
    league=(g['league_key'] if g else '')
    rates={'eng_pl':0.16,'esp_laliga':0.14,'ger_bundesliga':0.14,'ita_a':0.12,'fra_l1':0.11,'rus_rpl':0.10,
           'eng_ch':0.075,'esp_laliga2':0.065,'ger_2bundesliga':0.07,'ita_b':0.055,'fra_l2':0.05,'rus_first':0.04}
    rate=rates.get(league,0.07)
    # Strong squads and top divisions get larger budgets; weak/lower-division teams stay modest.
    strength_factor=max(0.65,min(1.35,1.0+(avg_ovr-68)*0.025))
    budget=int(squad_value*rate*strength_factor)
    budget=max(1_000_000,min(250_000_000,budget))
    wage_budget=max(100_000,sum(max(0,int(p['salary'] or 0)) for p in players))
    return budget,wage_budget

def career_launch_text(chat, user_id):
    g=game(chat); m=manager(chat,user_id)
    if not g or not m or not m['club']:
        return 'Карьера создана. Открой /start, чтобы посмотреть меню.'
    club=m['club']
    ps=db('SELECT ovr,form,morale,fitness,value,injured,suspended FROM players WHERE chat_id=? AND club=?',(chat,club),True)
    if ps:
        n=len(ps)
        avg_ovr=sum(int(x['ovr'] or 0) for x in ps)/n
        avg_form=sum(int(x['form'] or 0) for x in ps)/n
        avg_morale=sum(int(x['morale'] or 0) for x in ps)/n
        avg_fit=sum(int(x['fitness'] or 0) for x in ps)/n
        squad_value=sum(int(x['value'] or 0) for x in ps)
        available=sum(1 for x in ps if not int(x['injured'] or 0) and not int(x['suspended'] or 0))
    else:
        n=available=0; avg_ovr=avg_form=avg_morale=avg_fit=0; squad_value=0
    fixtures=db('SELECT md,home,away FROM fixtures WHERE chat_id=? AND played=0 AND (home=? OR away=?) ORDER BY md LIMIT 1',(chat,club,club),True)
    next_match='—'
    if fixtures:
        f=fixtures[0]; next_match=f'Тур {f["md"]}: {f["home"]} — {f["away"]}'
    league=META.get(g['league_key'],{}).get('name',g['league_key'])
    return (f'🚦 КАРЬЕРА НАЧАЛАСЬ · {g["season_year"]}\n\n'
            f'👔 Менеджер: {m["nickname"]}\n🏠 Клуб: {club}\n🏆 Лига: {league}\n\n'
            f'💰 Баланс клуба / трансферный бюджет: €{int(m["money"]):,}\n📈 Стоимость состава: €{squad_value:,}\n'
            f'⭐ Средний рейтинг команды: {avg_ovr:.1f} OVR\n🧠 Средняя мораль: {avg_morale:.0f}/100\n'
            f'🔥 Средняя форма: {avg_form:.0f}/100\n⚡ Физическая готовность: {avg_fit:.0f}/100\n'
            f'👥 Игроков в составе: {n} · доступны: {available}\n'
            f'🤝 Доверие руководства: {m["trust"]}/100\n🎯 Цель: {m["objective"]}\n\n'
            f'📅 Первый матч: {next_match}\n\n'
            'Управляй клубом через кнопки ниже. Для симуляции матчей открой отдельного бота матчей в группе.')

async def send_career_launch_dms(bot, chat):
    managers=db('SELECT user_id,club FROM managers WHERE chat_id=? AND club IS NOT NULL',(chat,),True)
    for row in managers:
        try:
            budget,wages=estimate_club_budget(chat,row['club'])
            db('UPDATE managers SET money=?,wage_budget=? WHERE chat_id=? AND user_id=?',(budget,wages,chat,row['user_id']))
            await bot.send_message(chat_id=int(row['user_id']),text=career_launch_text(chat,int(row['user_id'])),reply_markup=private_main_kb(int(row['user_id'])))
        except Exception as exc:
            log.warning('Could not send career launch DM to user %s: %s',row['user_id'],exc)

async def finish_lobby(update,ctx):
    q=update.callback_query
    if not await is_admin(update,q.from_user.id,ctx.bot): await q.answer('Только администратор.',show_alert=True); return
    chat=q.message.chat.id; g=game(chat)
    if not g or g['phase']!='lobby': await q.answer('Набор уже закрыт.',show_alert=True); return
    joined=db('SELECT user_id,nickname FROM managers WHERE chat_id=? AND club IS NULL',(chat,),True)
    if not joined: await q.answer('Никто не вошёл в набор.',show_alert=True); return
    clubs=[x['club'] for x in db('SELECT club FROM teams WHERE chat_id=? ORDER BY club',(chat,),True)]
    if len(joined)>len(clubs): await q.answer('Менеджеров больше, чем клубов. Удали лишних участников или выбери другую лигу.',show_alert=True); return
    random.SystemRandom().shuffle(clubs)
    for i,m in enumerate(joined): db('UPDATE managers SET club=? WHERE chat_id=? AND user_id=? AND club IS NULL',(clubs[i],chat,m['user_id']))
    db('UPDATE games SET phase=\'active\' WHERE chat_id=?',(chat,))
    create_european_season(chat,int(game(chat)['season']),False)
    await q.answer('Клубы распределены')
    await send_career_launch_dms(ctx.bot,chat)
    await q.edit_message_text(
        '🎮 НАБОР ЗАВЕРШЁН\n\n'
        'Клубы распределены между участниками.\n\n'
        + '\n'.join(f'👔 {m["nickname"]} → {clubs[i]}' for i,m in enumerate(joined))
        + '\n\n🚦 Карьера начинается! Открой основного бота в личном чате для управления клубом.',
        reply_markup=None
    )


async def pick_club(update,ctx):
    q=update.callback_query; chat=q.message.chat.id; uid=q.from_user.id; g=game(chat)
    if not g or g['phase']!='club_select': await q.answer('Выбор клубов закрыт.',show_alert=True); return
    m=manager(chat,uid)
    if not m or m['club']: await q.answer('У тебя уже есть клуб.',show_alert=True); return
    taken={x['club'] for x in db('SELECT club FROM managers WHERE chat_id=? AND club IS NOT NULL',(chat,),True)}
    clubs=[x['club'] for x in db('SELECT club FROM teams WHERE chat_id=? ORDER BY club',(chat,),True) if x['club'] not in taken]
    await q.edit_message_text('🏠 ВЫБОР КЛУБА\n\nВыбери свободный клуб:',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(c,callback_data='takeclub:'+c)] for c in clubs]))

async def take_club(update,ctx):
    q=update.callback_query; chat=q.message.chat.id; uid=q.from_user.id; g=game(chat)
    if not g or g['phase']!='club_select': await q.answer('Выбор закрыт.',show_alert=True); return
    m=manager(chat,uid); club=q.data.split(':',1)[1]
    if not m or m['club']: await q.answer('Клуб уже выбран.',show_alert=True); return
    if db('SELECT 1 FROM managers WHERE chat_id=? AND club=?',(chat,club),True): await q.answer('Этот клуб уже занят.',show_alert=True); return
    db('UPDATE managers SET club=? WHERE chat_id=? AND user_id=?',(club,chat,uid))
    await q.answer(f'Ты возглавил {club}!')
    await finish_club_selection(chat,q.message,ctx.bot)

async def random_club(update,ctx):
    q=update.callback_query; chat=q.message.chat.id; uid=q.from_user.id; g=game(chat)
    if not g or g['phase']!='club_select': await q.answer('Выбор закрыт.',show_alert=True); return
    m=manager(chat,uid)
    if not m or m['club']: await q.answer('У тебя уже есть клуб.',show_alert=True); return
    taken={x['club'] for x in db('SELECT club FROM managers WHERE chat_id=? AND club IS NOT NULL',(chat,),True)}
    clubs=[x['club'] for x in db('SELECT club FROM teams WHERE chat_id=? ORDER BY club',(chat,),True) if x['club'] not in taken]
    if not clubs: await q.answer('Свободных клубов нет.',show_alert=True); return
    club=random.choice(clubs); db('UPDATE managers SET club=? WHERE chat_id=? AND user_id=?',(club,chat,uid)); await q.answer(f'🎲 Тебе достался {club}!'); await finish_club_selection(chat,q.message,ctx.bot)

async def finish_club_selection(chat,message,bot=None):
    left=db('SELECT nickname FROM managers WHERE chat_id=? AND club IS NULL',(chat,),True)
    if left: return
    db('UPDATE games SET phase=\'active\' WHERE chat_id=?',(chat,))
    create_european_season(chat,int(game(chat)['season']),False)
    if bot is not None:
        await send_career_launch_dms(bot,chat)
    ms=db('SELECT nickname,club FROM managers WHERE chat_id=? ORDER BY nickname',(chat,),True)
    await message.reply_text('🚦 КАРЬЕРА НАЧАЛАСЬ\n\n'+'\n'.join(f'👔 {m["nickname"]} → {m["club"]}' for m in ms)+'\n\nКарточка каждого клуба отправлена менеджеру в личный чат. Матчи проводятся отдельным ботом матчей.',reply_markup=None)

async def career(update,ctx,cb=False):
    chat=context_chat(update); uid=update.effective_user.id; m=manager(chat,uid)
    if not m:
        text='У тебя нет клуба в этой карьере. Создай карьеру в группе командой /newgame.'
    else:
        text=career_launch_text(chat,uid)+f'\n\n⭐ Репутация менеджера: {m["reputation"]}/100'
    if cb: await update.callback_query.edit_message_text(text,reply_markup=menu_for(update))
    else: await update.message.reply_text(text,reply_markup=menu_for(update))

async def table(update,ctx,cb=False):
    chat=context_chat(update); rows=db('SELECT * FROM teams WHERE chat_id=? ORDER BY points DESC,(gf-ga) DESC,gf DESC,club',(chat,),True)
    text='📊 ТАБЛИЦА\n\n'+'\n'.join(f'{i:>2}. {r["club"]} — {r["points"]} оч. | {r["gf"]}:{r["ga"]}' for i,r in enumerate(rows,1)) or 'Нет данных.'
    if cb: await update.callback_query.edit_message_text(text,reply_markup=menu_for(update))
    else: await update.message.reply_text(text,reply_markup=menu_for(update))

def player_card(p):
    icons={'GK':'🧤','DF':'🛡️','MF':'🎯','FW':'⚡'}; icon=icons.get(p['pos'],'⚽')
    return (f'{icon} {p["name"]}\n\nPOSITION  {p["pos"]}   ·   OVR {p["ovr"]}\n'
            f'Возраст: {p["age"] or "—"}\nФорма: {p["form"]}/100\nМораль: {p["morale"]}/100\nФизика: {p["fitness"]}/100\n\n'
            f'💶 Стоимость: €{p["value"]:,}\n💰 Зарплата: €{p["salary"]:,}\n📈 Потенциал: {p["potential"]}')

async def squad(update,ctx,cb=False):
    chat=context_chat(update); m=manager(chat,update.effective_user.id)
    if not m: text='Сначала вступи в карьеру.'; kb=menu_for(update)
    else:
        ps=db('SELECT * FROM players WHERE chat_id=? AND club=? ORDER BY ovr DESC,name',(chat,m['club']),True)
        text=f'👥 СОСТАВ · {m["club"]}\n\nВыбери футболиста:'
        kb=InlineKeyboardMarkup([[InlineKeyboardButton(f'{p["name"]} · {p["pos"]} · {p["ovr"]} OVR',callback_data=f'player:{p["player_id"]}')] for p in ps]+[[InlineKeyboardButton('↩️ Назад',callback_data='career')]])
    if cb: await update.callback_query.edit_message_text(text,reply_markup=kb)
    else: await update.message.reply_text(text,reply_markup=kb)

async def player_view(update,ctx):
    q=update.callback_query; chat=context_chat(update); uid=q.from_user.id; pid=int(q.data.split(':')[1]); m=manager(chat,uid)
    p=db('SELECT * FROM players WHERE chat_id=? AND player_id=?',(chat,pid),True)
    if not m or not p: await q.answer('Игрок не найден.',show_alert=True); return
    p=p[0]; own=p['club']==m['club']; buttons=[]
    if own: buttons.append([InlineKeyboardButton('📤 Выставить на трансфер',callback_data=f'list:{pid}')])
    else: buttons.append([InlineKeyboardButton(f'💶 Сделать предложение · €{p["value"]:,}',callback_data=f'buy:{pid}')])
    buttons.append([InlineKeyboardButton('↩️ К составу',callback_data='squad')])
    await q.edit_message_text(player_card(p)+f'\n\n🏠 Клуб: {p["club"]}',reply_markup=InlineKeyboardMarkup(buttons))

async def transfers(update,ctx,cb=False):
    chat=context_chat(update); m=manager(chat,update.effective_user.id)
    if not m: text='Сначала вступи в карьеру.'; kb=menu_for(update)
    else:
        ps=db('SELECT * FROM players WHERE chat_id=? AND club!=? ORDER BY value DESC LIMIT 20',(chat,m['club']),True)
        offers=db("SELECT o.*,p.name FROM transfer_offers o JOIN players p ON p.chat_id=o.chat_id AND p.player_id=o.player_id WHERE o.chat_id=? AND o.from_club=? AND o.status='pending' ORDER BY o.id DESC LIMIT 10",(chat,m['club']),True)
        text=f'💼 ТРАНСФЕРНЫЙ РЫНОК\n\n💰 Бюджет: €{m["money"]:,}\n\nВходящие предложения: {len(offers)}\nВыбери футболиста для предложения:'
        rows=[[InlineKeyboardButton(f'📨 {o["name"]} · {o["to_club"]} · €{o["fee"]:,}',callback_data=f'offer:{o["id"]}:accept')] for o in offers]
        rows += [[InlineKeyboardButton(f'❌ Отклонить: {o["name"]}',callback_data=f'offer:{o["id"]}:reject')] for o in offers]
        rows += [[InlineKeyboardButton(f'{p["name"]} · €{p["value"]:,} · {p["club"]}',callback_data=f'player:{p["player_id"]}')] for p in ps]
        rows += [[InlineKeyboardButton('↩️ Назад',callback_data='career')]]
        kb=InlineKeyboardMarkup(rows)
    if cb: await update.callback_query.edit_message_text(text,reply_markup=kb)
    else: await update.message.reply_text(text,reply_markup=kb)

async def buy_player(update,ctx):
    q=update.callback_query; chat=context_chat(update); uid=q.from_user.id; pid=int(q.data.split(':')[1]); m=manager(chat,uid)
    p=db('SELECT * FROM players WHERE chat_id=? AND player_id=?',(chat,pid),True)
    if not m or not p: await q.answer('Игрок не найден.',show_alert=True); return
    p=p[0]
    if p['club']==m['club']: await q.answer('Он уже у тебя.',show_alert=True); return
    fee=int(p['value']*1.05)
    if m['money']<fee: await q.answer(f'Недостаточно средств: нужно €{fee:,}.',show_alert=True); return
    try:
        with transaction():
            existing=db("SELECT id FROM transfer_offers WHERE chat_id=? AND player_id=? AND to_club=? AND status='pending'",(chat,pid,m['club']),True)
            if existing: raise ValueError('Предложение этому клубу уже отправлено.')
            offer_id=db("INSERT INTO transfer_offers(chat_id,player_id,from_club,to_club,fee,source_user,status) VALUES(?,?,?,?,?,?,'pending')",(chat,pid,p['club'],m['club'],fee,uid))
            add_news(chat,f'📨 {m["club"]} предложил €{fee:,} за {p["name"]}.')
    except (ValueError,sqlite3.IntegrityError) as exc:
        await q.answer(str(exc) or 'Предложение уже отправлено.',show_alert=True); return
    seller=db('SELECT user_id FROM managers WHERE chat_id=? AND club=?',(chat,p['club']),True)
    if seller:
        try:
            await ctx.bot.send_message(chat_id=seller[0]['user_id'],text=f'📨 Предложение за {p["name"]}: {m["club"]} предлагает €{fee:,}. Открой /transfers в личном чате или группе, чтобы принять/отклонить.')
        except Exception: pass
    await q.answer('Предложение отправлено')
    await q.edit_message_text(f'📨 ПРЕДЛОЖЕНИЕ ОТПРАВЛЕНО\n\nИгрок: {p["name"]}\nКлуб продавца: {p["club"]}\nПредложение: €{fee:,}\n\nПереход произойдёт только после принятия продавцом.',reply_markup=menu_for(update))

async def decide_offer(update,ctx):
    q=update.callback_query; chat=context_chat(update); uid=q.from_user.id
    parts=q.data.split(':'); offer_id=int(parts[1]); decision=parts[2]
    rows=db("SELECT * FROM transfer_offers WHERE id=? AND chat_id=? AND status='pending'",(offer_id,chat),True)
    if not rows: await q.answer('Предложение уже обработано или не найдено.',show_alert=True); return
    o=rows[0]; seller=manager(chat,uid)
    if not seller or seller['club']!=o['from_club']:
        await q.answer('Принять или отклонить может только менеджер клуба-продавца.',show_alert=True); return
    if decision=='reject':
        db("UPDATE transfer_offers SET status='rejected' WHERE id=? AND status='pending'",(offer_id,))
        await q.answer('Предложение отклонено'); await transfers(update,ctx,True); return
    buyer_rows=db('SELECT * FROM managers WHERE chat_id=? AND club=?',(chat,o['to_club']),True)
    player_rows=db('SELECT * FROM players WHERE chat_id=? AND player_id=?',(chat,o['player_id']),True)
    if not buyer_rows or not player_rows or player_rows[0]['club']!=o['from_club']:
        db("UPDATE transfer_offers SET status='cancelled' WHERE id=?",(offer_id,))
        await q.answer('Состав изменился — предложение отменено.',show_alert=True); return
    buyer=buyer_rows[0]; player=player_rows[0]
    if buyer['money']<o['fee']:
        db("UPDATE transfer_offers SET status='rejected' WHERE id=?",(offer_id,))
        await q.answer('У покупателя больше недостаточно средств.',show_alert=True); return
    try:
        with transaction():
            fresh=db("SELECT * FROM transfer_offers WHERE id=? AND chat_id=? AND status='pending'",(offer_id,chat),True)
            fresh_player=db('SELECT * FROM players WHERE chat_id=? AND player_id=?',(chat,o['player_id']),True)
            fresh_buyer=db('SELECT * FROM managers WHERE chat_id=? AND club=?',(chat,o['to_club']),True)
            if not fresh or not fresh_player or fresh_player[0]['club']!=o['from_club'] or not fresh_buyer or fresh_buyer[0]['money']<o['fee']:
                raise ValueError('Предложение уже обработано или условия сделки изменились.')
            db("UPDATE transfer_offers SET status='accepted' WHERE id=? AND status='pending'",(offer_id,))
            db('UPDATE players SET club=? WHERE chat_id=? AND player_id=? AND club=?',(o['to_club'],chat,o['player_id'],o['from_club']))
            db('UPDATE managers SET money=money-? WHERE chat_id=? AND club=?',(o['fee'],chat,o['to_club']))
            db('UPDATE managers SET money=money+? WHERE chat_id=? AND club=?',(o['fee'],chat,o['from_club']))
            db('INSERT INTO transfers(chat_id,player_id,player_name,from_club,to_club,fee,kind) VALUES(?,?,?,?,?,?,?)',(chat,o['player_id'],player['name'],o['from_club'],o['to_club'],o['fee'],'purchase'))
            add_news(chat,f'💼 {player["name"]}: {o["from_club"]} → {o["to_club"]} за €{o["fee"]:,}.')
    except ValueError as exc:
        await q.answer(str(exc),show_alert=True); return
    await q.answer('Сделка завершена!'); await q.edit_message_text(f'✅ ТРАНСФЕР СОСТОЯЛСЯ\n\n{player["name"]}\n{o["from_club"]} → {o["to_club"]}\n€{o["fee"]:,}',reply_markup=menu_for(update))

async def list_player(update,ctx):
    q=update.callback_query; chat=context_chat(update); uid=q.from_user.id; pid=int(q.data.split(':')[1]); m=manager(chat,uid); p=db('SELECT * FROM players WHERE chat_id=? AND player_id=?',(chat,pid),True)
    if not m or not p or p[0]['club']!=m['club']: await q.answer('Недоступно.',show_alert=True); return
    p=p[0]; fee=int(p['value']*1.05); db('INSERT INTO transfer_offers(chat_id,player_id,from_club,to_club,fee,source_user,status) VALUES(?,?,?,?,?,?,?)',(chat,pid,m['club'],'FREE_MARKET',fee,uid,'listed')); add_news(chat,f'📤 {p["name"]} выставлен на трансфер за €{fee:,}.')
    await q.edit_message_text(f'📤 {p["name"]} выставлен на трансфер.\n\nСтартовая цена: €{fee:,}\n\nИИ или другой менеджер может прислать предложение.',reply_markup=menu_for(update))

async def fixtures(update,ctx,cb=False):
    chat=context_chat(update); m=manager(chat,update.effective_user.id); rows=db('SELECT * FROM fixtures WHERE chat_id=? AND (home=? OR away=?) ORDER BY md LIMIT 15',(chat,m['club'],m['club']),True) if m else []
    text='📅 КАЛЕНДАРЬ\n\n'+'\n'.join(f'{r["md"]} тур · {r["home"]} — {r["away"]}' + (f' · {r["hs"]}:{r["ascore"]}' if r['played'] else '') for r in rows) if rows else 'Календарь появится после старта тура.'
    if cb: await update.callback_query.edit_message_text(text,reply_markup=menu_for(update))
    else: await update.message.reply_text(text,reply_markup=menu_for(update))

async def board(update,ctx,cb=False):
    chat=context_chat(update); m=manager(chat,update.effective_user.id); text='🎯 РУКОВОДСТВО\n\n'+(f'Доверие: {m["trust"]}/100\nЦель: {m["objective"]}' if m else 'Сначала вступи в карьеру.')
    if cb: await update.callback_query.edit_message_text(text,reply_markup=menu_for(update))
    else: await update.message.reply_text(text,reply_markup=menu_for(update))

EUROPE_NAMES = {'ucl':'🏆 Лига чемпионов','uel':'🥈 Лига Европы','uecl':'🥉 Лига конференций'}


def _club_strength(team):
    ps=team.get('players',[])
    vals=[]
    for p in ps:
        try:
            if p.get('ovr') is not None: vals.append(int(p['ovr']))
        except (TypeError,ValueError): pass
    return sum(sorted(vals,reverse=True)[:18])/max(1,min(18,len(vals))) if vals else 55.0


def create_european_season(chat, season, use_current_table=False):
    """Build three 36-club continental league phases from the embedded six-league DB.
    First season seeds by squad strength; later seasons use the just-finished domestic table.
    """
    db('DELETE FROM europe_fixtures WHERE chat_id=? AND season=?',(chat,season))
    db('DELETE FROM europe_teams WHERE chat_id=? AND season=?',(chat,season))
    db('DELETE FROM europe_champions WHERE chat_id=? AND season=?',(chat,season))
    g=game(chat); active_key=g['league_key'] if g else ''
    active_teams=[]
    if use_current_table:
        rows=db('SELECT club,points,gf,ga,won,draw,lost,played FROM teams WHERE chat_id=? ORDER BY points DESC,(gf-ga) DESC,gf DESC,club',(chat,),True)
        active_teams=[{'name':r['club'],'league_key':active_key,'strength':_saved_club_strength(chat,r['club']),'domestic_rank':i+1} for i,r in enumerate(rows)]
    else:
        league=provider.database.get('leagues',{}).get(active_key,{})
        active_teams=[{'name':t['name'],'league_key':active_key,'strength':_club_strength(t),'domestic_rank':0} for t in league.get('teams',[])]
        active_teams.sort(key=lambda x:(-x['strength'],x['name']))
        for i,t in enumerate(active_teams,1): t['domestic_rank']=i
    external=[]
    for key,league in provider.database.get('leagues',{}).items():
        if key==active_key: continue
        for t in league.get('teams',[]):
            external.append({'name':t['name'],'league_key':key,'strength':_club_strength(t),'domestic_rank':0})
    # Keep each club in one continental competition. Top domestic finishers get the highest tier.
    assigned=set(); participants={'ucl':[],'uel':[],'uecl':[]}
    for t in active_teams[:4]: participants['ucl'].append(t); assigned.add(t['name'])
    for t in active_teams[4:6]: participants['uel'].append(t); assigned.add(t['name'])
    for t in active_teams[6:8]: participants['uecl'].append(t); assigned.add(t['name'])
    ext_by_league={}
    for t in external: ext_by_league.setdefault(t['league_key'],[]).append(t)
    for league_key in ext_by_league:
        ext_by_league[league_key].sort(key=lambda x:(-x['strength'],x['name']))
    # Distribute each country's strongest remaining clubs across tiers, avoiding duplicate clubs.
    for tier,slots in [('ucl',36),('uel',36),('uecl',36)]:
        for key in sorted(ext_by_league):
            already=sum(1 for x in participants[tier] if x['league_key']==key)
            desired={'ucl':4,'uel':2,'uecl':2}[tier]
            candidates=[x for x in ext_by_league[key] if x['name'] not in assigned]
            for t in candidates[:max(0,desired-already)]:
                participants[tier].append(t); assigned.add(t['name'])
        candidates=sorted([x for x in external if x['name'] not in assigned],key=lambda x:(-x['strength'],x['name']))
        # Fill any remaining seats with strongest available clubs from all other leagues.
        for t in sorted([x for x in external+active_teams if x['name'] not in assigned],key=lambda x:(-x['strength'],x['name']))[:max(0,slots-len(participants[tier]))]:
            participants[tier].append(t); assigned.add(t['name'])
        # If a tiny data set leaves fewer than 36 unique clubs, do not duplicate participants.
    rows=[]
    for comp,clubs in participants.items():
        clubs=sorted(clubs,key=lambda x:(-x['strength'],x['name']))[:36]
        for seed,t in enumerate(clubs,1):
            rows.append((chat,season,comp,t['name'],t['league_key'],float(t['strength']),seed,1 if t['league_key']==active_key else 0))
        _make_swiss_fixtures(chat,season,comp,[t['name'] for t in clubs])
    if rows:
        db('INSERT OR REPLACE INTO europe_teams(chat_id,season,competition,club,league_key,strength,seed,qualified) VALUES(?,?,?,?,?,?,?,?)',rows,many=True)
    db('UPDATE games SET europe_round=1 WHERE chat_id=?',(chat,))
    add_news(chat,'🌍 Еврокубки сформированы: Лига чемпионов, Лига Европы и Лига конференций. Стартовая квалификация основана на результатах лиги или силе составов.')


def _saved_club_strength(chat, club):
    ps=db('SELECT ovr FROM players WHERE chat_id=? AND club=? AND ovr IS NOT NULL ORDER BY ovr DESC LIMIT 18',(chat,club),True)
    return sum(int(x['ovr']) for x in ps)/len(ps) if ps else 55.0


def _make_swiss_fixtures(chat,season,comp,clubs):
    # Eight distinct opponents per club; each round has 18 matches for a 36-team league phase.
    if len(clubs)<2: return
    pool=list(clubs); random.Random(f'{chat}:{season}:{comp}:leaguephase').shuffle(pool)
    played={c:set() for c in pool}; rounds=[]
    for rnd in range(1,9):
        remaining=set(pool); pairs=[]
        while len(remaining)>=2:
            a=min(remaining,key=lambda c:sum(1 for x in remaining if x!=c and x not in played[c]))
            opts=[x for x in remaining if x!=a and x not in played[a]]
            if not opts: opts=[x for x in remaining if x!=a]
            # Prefer opponents from another domestic league when the stored participant metadata allows it.
            b=random.choice(opts)
            remaining.remove(a); remaining.remove(b); played[a].add(b); played[b].add(a)
            home,away=(a,b) if random.random()<.5 else (b,a); pairs.append((home,away))
        rounds.extend((chat,season,comp,rnd,h,a) for h,a in pairs)
    if rounds: db('INSERT OR IGNORE INTO europe_fixtures(chat_id,season,competition,round_no,home,away) VALUES(?,?,?,?,?,?)',rounds,many=True)


def _europe_standings(chat,season,comp):
    return db('SELECT * FROM europe_teams WHERE chat_id=? AND season=? AND competition=? ORDER BY points DESC,(gf-ga) DESC,gf DESC,won DESC,seed ASC,club',(chat,season,comp),True)


def _update_europe_team(chat,season,comp,club,gf,ga):
    db('UPDATE europe_teams SET played=played+1,won=won+?,draw=draw+?,lost=lost+?,gf=gf+?,ga=ga+?,points=points+? WHERE chat_id=? AND season=? AND competition=? AND club=?',
       (int(gf>ga),int(gf==ga),int(gf<ga),gf,ga,3 if gf>ga else 1 if gf==ga else 0,chat,season,comp,club))


def process_player_match_events(chat, club, gf, ga, scorers=None):
    """Update rolling form, morale, fitness, injuries and discipline after one match."""
    scorers=set(scorers or [])
    players=db('SELECT * FROM players WHERE chat_id=? AND club=?',(chat,club),True)
    if not players: return []
    outcome=3 if gf>ga else 1 if gf==ga else -3
    available=[p for p in players if int(p['injury_matches'] or 0)<=0 and int(p['suspension_matches'] or 0)<=0]
    starters=set(p['player_id'] for p in sorted(available,key=engine.player_power,reverse=True)[:11])
    updates=[]; events=[]
    for p in players:
        is_starter=p['player_id'] in starters
        injury=max(0,int(p['injury_matches'] or 0)-1)
        ban=max(0,int(p['suspension_matches'] or 0)-1)
        old_fitness=int(p['fitness'] if p['fitness'] is not None else 80)
        old_morale=int(p['morale'] if p['morale'] is not None else 65)
        old_form=int(p['form'] if p['form'] is not None else 65)
        fitness=max(25,min(100,old_fitness + (random.randint(-8,-4) if is_starter else random.randint(3,7))))
        scored=p['name'] in scorers
        morale_delta=(1 if gf>ga else 0 if gf==ga else -2) if is_starter else (0 if gf>=ga else -1)
        if scored: morale_delta+=2
        if is_starter and old_fitness<45: morale_delta-=1
        morale=max(10,min(100,old_morale+morale_delta+random.choice([-1,0,0,0,1])))

        # Form is a rolling average of estimated match performance, not a random reset.
        # Typical match rating is 6.0-7.2; goals and team result affect it, while variance remains modest.
        if is_starter:
            performance=6.45 + (0.38 if gf>ga else 0.08 if gf==ga else -0.38)
            if scored: performance+=0.65
            if p['pos']=='GK' and ga==0: performance+=0.55
            elif p['pos'] in ('CB','LB','RB','DF','LWB','RWB') and ga==0: performance+=0.30
            if ga>=3: performance-=0.25
            performance+=random.uniform(-0.65,0.65)
            target_form=max(25,min(96,round(70+(performance-6.5)*13)))
            form=max(25,min(96,round(old_form*0.76+target_form*0.24)))
            if form-old_form>=7 and form>=82:
                events.append(f'🔥 {p["name"]} ({club}) набирает отличную форму: {form}/100.')
            elif old_form-form>=7 and form<=48:
                events.append(f'📉 {p["name"]} ({club}) переживает спад формы: {form}/100.')
        else:
            # A player who does not feature drifts gently toward neutral form instead of changing sharply.
            form=max(25,min(96,round(old_form*0.96+68*0.04)))

        yellow=int(p['yellow_cards'] or 0); red=int(p['red_cards'] or 0)
        if is_starter:
            if random.random()<0.15:
                yellow+=1
                if yellow>=5:
                    ban=max(ban,1); yellow=0
                    events.append(f'🟨 {p["name"]}: перебор жёлтых, дисквалификация на 1 матч.')
            if random.random()<0.004:
                red+=1; ban=max(ban,2)
                events.append(f'🟥 {p["name"]}: прямая красная карточка, дисквалификация на 2 матча.')
            if random.random()<0.007:
                duration=random.choices([1,2,3,4,6],[.36,.31,.20,.10,.03])[0]
                injury=max(injury,duration); fitness=min(fitness,32)
                events.append(f'🚑 {p["name"]} ({club}) получил травму и пропустит {duration} матч(а/ей).')
        updates.append((injury,ban,int(injury>0),int(ban>0),fitness,morale,form,yellow,red,chat,club,p['player_id']))
    db('UPDATE players SET injury_matches=?,suspension_matches=?,injured=?,suspended=?,fitness=?,morale=?,form=?,yellow_cards=?,red_cards=? WHERE chat_id=? AND club=? AND player_id=?',updates,many=True)
    return events


def roll_random_club_event(chat, season, md, club):
    """Roll one persistent off-pitch event for a human-managed club after a league matchday."""
    if db('SELECT 1 FROM random_events WHERE chat_id=? AND season=? AND md=? AND club=?',(chat,season,md,club),True):
        return None
    if random.random()>0.32:
        return None
    players=db('SELECT * FROM players WHERE chat_id=? AND club=? AND injury_matches<=0 AND suspension_matches<=0',(chat,club),True)
    if not players: return None
    event=random.choices(
        ['breakthrough','fatigue','fans','pressure','sponsor','conflict','training_injury','recovery','board'],
        weights=[14,13,13,10,8,10,8,12,12],k=1)[0]
    text=''; event_type=event
    if event=='breakthrough':
        young=[p for p in players if p['age'] is not None and int(p['age'])<=23]
        target=random.choice(young or players)
        db('UPDATE players SET form=MIN(96,form+7),morale=MIN(100,morale+6) WHERE chat_id=? AND club=? AND player_id=?',(chat,club,target['player_id']))
        text=f'🌟 Прорыв на тренировке: {target["name"]} впечатлил тренерский штаб. Форма +7, мораль +6.'
    elif event=='fatigue':
        tired=random.sample(players,min(len(players),random.randint(2,4)))
        for target in tired:
            db('UPDATE players SET fitness=MAX(25,fitness-7) WHERE chat_id=? AND club=? AND player_id=?',(chat,club,target['player_id']))
        text=f'🪫 Интенсивная тренировка утомила часть состава «{club}». У {len(tired)} игроков физика снизилась на 7.'
    elif event=='fans':
        db('UPDATE players SET morale=MIN(100,morale+4) WHERE chat_id=? AND club=?',(chat,club))
        db('UPDATE managers SET trust=MIN(100,trust+1) WHERE chat_id=? AND club=?',(chat,club))
        text=f'🙌 Болельщики устроили команде тёплую встречу. Мораль игроков «{club}» выросла на 4.'
    elif event=='pressure':
        db('UPDATE players SET morale=MAX(10,morale-3) WHERE chat_id=? AND club=?',(chat,club))
        db('UPDATE managers SET trust=MAX(0,trust-2) WHERE chat_id=? AND club=?',(chat,club))
        text=f'🎙️ Пресса усилила давление на «{club}». Мораль игроков −3, доверие руководства −2.'
    elif event=='sponsor':
        bonus=random.randint(250_000,1_500_000)
        db('UPDATE managers SET money=money+? WHERE chat_id=? AND club=?',(bonus,chat,club))
        text=f'💶 Спонсорская активация принесла «{club}» дополнительные €{bonus:,}.'.replace(',', ' ')
    elif event=='conflict':
        target=min(players,key=lambda p:int(p['morale'] or 60))
        db('UPDATE players SET morale=MAX(10,morale-9) WHERE chat_id=? AND club=? AND player_id=?',(chat,club,target['player_id']))
        text=f'⚠️ Напряжение в раздевалке «{club}»: {target["name"]} недоволен своей ролью. Его мораль снизилась на 9.'
    elif event=='training_injury':
        target=random.choice(players); duration=random.choices([1,2,3],[.55,.32,.13])[0]
        db('UPDATE players SET injury_matches=MAX(injury_matches,?),injured=1,fitness=MAX(25,fitness-15) WHERE chat_id=? AND club=? AND player_id=?',(duration,chat,club,target['player_id']))
        text=f'🚑 Травма на тренировке: {target["name"]} («{club}») пропустит примерно {duration} матч(а/ей).'
    elif event=='recovery':
        resting=random.sample(players,min(len(players),random.randint(3,6)))
        for target in resting:
            db('UPDATE players SET fitness=MIN(100,fitness+8) WHERE chat_id=? AND club=? AND player_id=?',(chat,club,target['player_id']))
        text=f'🧊 Медицинский штаб изменил восстановительную программу «{club}». Физика {len(resting)} игроков выросла на 8.'
    else:
        bonus=random.randint(500_000,2_000_000)
        db('UPDATE managers SET money=money+?,trust=MIN(100,trust+2) WHERE chat_id=? AND club=?',(bonus,chat,club))
        text=f'🤝 Руководство довольно работой команды «{club}» и выделило премию €{bonus:,}.'.replace(',', ' ')
    db('INSERT OR IGNORE INTO random_events(chat_id,season,md,club,event_type,text) VALUES(?,?,?,?,?,?)',(chat,season,md,club,event_type,text))
    add_news(chat,text)
    return text


def _create_knockout_round(chat,season,comp,round_no):
    standings=_europe_standings(chat,season,comp)
    by_seed={int(r['seed']):r['club'] for r in standings}
    rows=[]
    if round_no==9: # play-offs: 9-24, seeds 9 vs 24 etc.
        for seed in range(9,17):
            a=by_seed.get(seed); b=by_seed.get(33-seed)
            if a and b: rows.append((chat,season,comp,round_no,a,b))
    elif round_no==10: # Round of 16: top eight join play-off winners.
        prev=db('SELECT * FROM europe_fixtures WHERE chat_id=? AND season=? AND competition=? AND round_no=9 AND played=1',(chat,season,comp),True)
        winners=[]
        for f in prev:
            winner=f['home'] if f['hs']>f['ascore'] else f['away'] if f['ascore']>f['hs'] else random.choice([f['home'],f['away']])
            seedrow=db('SELECT seed FROM europe_teams WHERE chat_id=? AND season=? AND competition=? AND club=?',(chat,season,comp,winner),True)
            winners.append((int(seedrow[0]['seed']) if seedrow else 99,winner))
        winners.sort()
        for i,seed in enumerate(range(1,9)):
            top=by_seed.get(seed); other=winners[-1-i][1] if len(winners)>=8 else None
            if top and other: rows.append((chat,season,comp,round_no,top,other))
    else:
        prev=_europe_round_winners(chat,season,comp,round_no-1)
        for i in range(0,len(prev)-1,2): rows.append((chat,season,comp,round_no,prev[i],prev[i+1]))
    if rows: db('INSERT OR IGNORE INTO europe_fixtures(chat_id,season,competition,round_no,home,away) VALUES(?,?,?,?,?,?)',rows,many=True)


def _europe_round_winners(chat,season,comp,round_no):
    fs=db('SELECT * FROM europe_fixtures WHERE chat_id=? AND season=? AND competition=? AND round_no=? AND played=1',(chat,season,comp,round_no),True)
    winners=[]
    for f in fs:
        if f['hs']==f['ascore']:
            winner=random.choice([f['home'],f['away']])
        else: winner=f['home'] if f['hs']>f['ascore'] else f['away']
        winners.append(winner)
    return winners


def _record_european_champion(chat, season, comp, champion):
    if not champion: return
    exists=db('SELECT 1 FROM europe_champions WHERE chat_id=? AND season=? AND competition=?',(chat,season,comp),True)
    if exists: return
    db('INSERT INTO europe_champions(chat_id,season,competition,champion) VALUES(?,?,?,?)',(chat,season,comp,champion))
    prize={'ucl':25_000_000,'uel':12_000_000,'uecl':7_000_000}.get(comp,5_000_000)
    winners=db('SELECT user_id FROM managers WHERE chat_id=? AND club=?',(chat,champion),True)
    for manager_row in winners:
        uid=int(manager_row['user_id'])
        db('INSERT OR IGNORE INTO achievements(user_id) VALUES(?)',(uid,))
        db('UPDATE managers SET money=money+?,reputation=MIN(100,reputation+8),trust=MIN(100,trust+8) WHERE chat_id=? AND user_id=?',(prize,chat,uid))
        db('UPDATE achievements SET europa=europa+1,cups=cups+1 WHERE user_id=?',(uid,))
    add_news(chat,f'🏆 {EUROPE_NAMES[comp]}: победитель — {champion}. Призовой фонд клуба: €{prize:,}.')


def simulate_europe(chat, requested_round=None):
    with SIM_LOCK, transaction():
        g=game(chat)
        if not g: raise ValueError('Карьера не найдена')
        if not db('SELECT 1 FROM europe_teams WHERE chat_id=? AND season=? LIMIT 1',(chat,g['season']),True):
            create_european_season(chat,g['season'],False)
        rnd=int(g['europe_round'] or 1)
        if requested_round is not None and int(requested_round)!=rnd: raise ValueError('Этот еврокубковый раунд уже обработан или устарел.')
        results=[]; events=[]
        for comp in ('ucl','uel','uecl'):
            if rnd<=8:
                fs=db('SELECT * FROM europe_fixtures WHERE chat_id=? AND season=? AND competition=? AND round_no=? AND played=0 ORDER BY home,away',(chat,g['season'],comp,rnd),True)
                for f in fs:
                    hr=db('SELECT strength FROM europe_teams WHERE chat_id=? AND season=? AND competition=? AND club=?',(chat,g['season'],comp,f['home']),True)
                    ar=db('SELECT strength FROM europe_teams WHERE chat_id=? AND season=? AND competition=? AND club=?',(chat,g['season'],comp,f['away']),True)
                    hp=float(hr[0]['strength']) if hr else _saved_club_strength(chat,f['home']); ap=float(ar[0]['strength']) if ar else _saved_club_strength(chat,f['away'])
                    hplayers=db('SELECT * FROM players WHERE chat_id=? AND club=?',(chat,f['home']),True); aplayers=db('SELECT * FROM players WHERE chat_id=? AND club=?',(chat,f['away']),True)
                    if hplayers: hp=engine.squad_power(hplayers)
                    if aplayers: ap=engine.squad_power(aplayers)
                    r=engine.play(f['home'],f['away'],hp,ap,home_adv=1.0)
                    db('UPDATE europe_fixtures SET hs=?,ascore=?,played=1 WHERE chat_id=? AND season=? AND competition=? AND round_no=? AND home=? AND away=? AND played=0',(r.hs,r.ascore,chat,g['season'],comp,rnd,r.home,r.away))
                    _update_europe_team(chat,g['season'],comp,r.home,r.hs,r.ascore); _update_europe_team(chat,g['season'],comp,r.away,r.ascore,r.hs)
                    events += process_player_match_events(chat,r.home,r.hs,r.ascore) if hplayers else []
                    events += process_player_match_events(chat,r.away,r.ascore,r.hs) if aplayers else []
                    results.append((comp,r.home,r.hs,r.ascore,r.away))
            elif rnd<=13:
                existing=db('SELECT COUNT(*) AS n FROM europe_fixtures WHERE chat_id=? AND season=? AND competition=? AND round_no=?',(chat,g['season'],comp,rnd),True)[0]['n']
                if not existing:
                    _create_knockout_round(chat,g['season'],comp,rnd)
                fs=db('SELECT * FROM europe_fixtures WHERE chat_id=? AND season=? AND competition=? AND round_no=? AND played=0 ORDER BY home,away',(chat,g['season'],comp,rnd),True)
                for f in fs:
                    hr=db('SELECT strength FROM europe_teams WHERE chat_id=? AND season=? AND competition=? AND club=?',(chat,g['season'],comp,f['home']),True); ar=db('SELECT strength FROM europe_teams WHERE chat_id=? AND season=? AND competition=? AND club=?',(chat,g['season'],comp,f['away']),True)
                    hp=float(hr[0]['strength']) if hr else 55; ap=float(ar[0]['strength']) if ar else 55
                    hplayers=db('SELECT * FROM players WHERE chat_id=? AND club=?',(chat,f['home']),True); aplayers=db('SELECT * FROM players WHERE chat_id=? AND club=?',(chat,f['away']),True)
                    if hplayers: hp=engine.squad_power(hplayers)
                    if aplayers: ap=engine.squad_power(aplayers)
                    r=engine.play(f['home'],f['away'],hp,ap,home_adv=0.5)
                    hs,ascore=r.hs,r.ascore
                    if hs==ascore:
                        if random.random()<.5: hs+=1
                        else: ascore+=1
                    db('UPDATE europe_fixtures SET hs=?,ascore=?,played=1 WHERE chat_id=? AND season=? AND competition=? AND round_no=? AND home=? AND away=? AND played=0',(hs,ascore,chat,g['season'],comp,rnd,r.home,r.away))
                    events += process_player_match_events(chat,r.home,hs,ascore) if hplayers else []
                    events += process_player_match_events(chat,r.away,ascore,hs) if aplayers else []
                    results.append((comp,r.home,hs,ascore,r.away))
                # Record champions immediately after the final.
                if rnd==13:
                    winners=_europe_round_winners(chat,g['season'],comp,13)
                    if winners: _record_european_champion(chat,g['season'],comp,winners[0])
        if rnd==8:
            for comp in ('ucl','uel','uecl'):
                rows=_europe_standings(chat,g['season'],comp)
                for seed,row in enumerate(rows,1): db('UPDATE europe_teams SET seed=? WHERE chat_id=? AND season=? AND competition=? AND club=?',(seed,chat,g['season'],comp,row['club']))
        elif rnd in (9,10,11,12,13):
            for comp in ('ucl','uel','uecl'):
                if rnd==13 and db('SELECT 1 FROM europe_fixtures WHERE chat_id=? AND season=? AND competition=? AND round_no=13 AND played=1',(chat,g['season'],comp),True):
                    winners=_europe_round_winners(chat,g['season'],comp,13)
                    if winners: _record_european_champion(chat,g['season'],comp,winners[0])
        next_rnd=rnd+1
        db('UPDATE games SET europe_round=? WHERE chat_id=?',(next_rnd,chat))
        if events:
            for ev in events[:30]: add_news(chat,ev)
        for comp,h,hs,ascore,a in results: add_news(chat,f'{EUROPE_NAMES[comp]} · {h} {hs}:{ascore} {a}')
        return rnd,results,events


def create_full_calendar(chat):
    """Create a double round-robin once: every pair meets home and away."""
    teams=[x['club'] for x in db('SELECT club FROM teams WHERE chat_id=? ORDER BY club',(chat,),True)]
    if not teams: return
    teams=sorted(teams)
    if len(teams)%2: teams.append('BYE')
    n=len(teams); first=[]; arr=teams[:]
    for rnd in range(n-1):
        pairs=[]
        for i in range(n//2):
            a,b=arr[i],arr[n-1-i]
            if a!='BYE' and b!='BYE':
                # Alternate home side to balance the first half.
                home,away=(a,b) if (rnd+i)%2==0 else (b,a)
                pairs.append((home,away))
        first.append(pairs)
        arr=[arr[0]]+[arr[-1]]+arr[1:-1]
    all_rounds=first+[[ (away,home) for home,away in rnd ] for rnd in first]
    db('DELETE FROM fixtures WHERE chat_id=?',(chat,))
    rows=[]
    for md,pairs in enumerate(all_rounds,1):
        for home,away in pairs: rows.append((chat,md,home,away))
    if rows: db('INSERT OR IGNORE INTO fixtures(chat_id,md,home,away) VALUES(?,?,?,?)',rows,many=True)

def create_round(chat,md):
    # Compatibility helper: calendar is pre-generated at career creation.
    if not db('SELECT 1 FROM fixtures WHERE chat_id=? AND md=? LIMIT 1',(chat,md),True):
        create_full_calendar(chat)

def update_team(chat,club,gf,ga):
    db('UPDATE teams SET played=played+1,won=won+?,draw=draw+?,lost=lost+?,gf=gf+?,ga=ga+?,points=points+? WHERE chat_id=? AND club=?',(int(gf>ga),int(gf==ga),int(gf<ga),gf,ga,3 if gf>ga else 1 if gf==ga else 0,chat,club))

def simulate(chat, requested_md=None):
    with SIM_LOCK, transaction():
        g=game(chat)
        if not g: raise ValueError('Карьера не найдена')
        md=int(g['matchday'])
        if requested_md is not None and int(requested_md)!=md:
            raise ValueError('Этот тур уже обработан или устарел. Открой /match заново.')
        create_round(chat,md)
        unrated=db("SELECT COUNT(*) AS n FROM players WHERE chat_id=? AND (rating_source NOT IN ('EA SPORTS FC 27 official ratings export (snapshot 2026-09-12)','EA SPORTS FC 27 via FCCareer','EA SPORTS FC 26 via public EA ratings export','rpl_estimated_status_results_2026_27') OR rating_source IS NULL OR ovr IS NULL OR pos IS NULL)",(chat,),True)[0]['n']
        if unrated:
            raise ValueError(f'Нельзя симулировать матчи: у {unrated} игроков нет подтверждённого источника рейтинга/позиции. Старые карьеры с прежними оценками нужно пересоздать после импорта данных.')
        fs=db('SELECT * FROM fixtures WHERE chat_id=? AND md=? AND played=0 ORDER BY home,away',(chat,md),True)
        if not fs:
            # Never advance a round twice. Return a clear state instead.
            raise ValueError('В этом туре нет несыгранных матчей. Повторный расчёт запрещён.')
        results=[]
        for f in fs:
            hp=db('SELECT * FROM players WHERE chat_id=? AND club=?',(chat,f['home']),True)
            ap=db('SELECT * FROM players WHERE chat_id=? AND club=?',(chat,f['away']),True)
            hm=db('SELECT formation,style FROM managers WHERE chat_id=? AND club=?',(chat,f['home']),True)
            am=db('SELECT formation,style FROM managers WHERE chat_id=? AND club=?',(chat,f['away']),True)
            hpw=engine.squad_power(hp,hm[0]['formation'] if hm else '4-3-3',hm[0]['style'] if hm else 'Balanced')
            apw=engine.squad_power(ap,am[0]['formation'] if am else '4-3-3',am[0]['style'] if am else 'Balanced')
            r=engine.play(f['home'],f['away'],hpw,apw)
            def scorer_list(players,count):
                ranked=sorted(players,key=engine.player_power,reverse=True)
                if not ranked or count<=0:return []
                weights=[max(1,engine.player_power(x)-35) for x in ranked[:min(len(ranked),11)]]
                return random.choices([x['name'] for x in ranked[:len(weights)]],weights=weights,k=count)
            r.scorers_home=scorer_list(hp,r.hs); r.scorers_away=scorer_list(ap,r.ascore)
            # A guarded update ensures a duplicate callback cannot add table points twice.
            db('UPDATE fixtures SET hs=?,ascore=?,played=1 WHERE chat_id=? AND md=? AND home=? AND away=? AND played=0',(r.hs,r.ascore,chat,md,r.home,r.away))
            update_team(chat,r.home,r.hs,r.ascore); update_team(chat,r.away,r.ascore,r.hs)
            db('UPDATE managers SET wins=wins+?,draws=draws+?,losses=losses+? WHERE chat_id=? AND club=?',(int(r.hs>r.ascore),int(r.hs==r.ascore),int(r.hs<r.ascore),chat,r.home))
            db('UPDATE managers SET wins=wins+?,draws=draws+?,losses=losses+? WHERE chat_id=? AND club=?',(int(r.ascore>r.hs),int(r.hs==r.ascore),int(r.ascore<r.hs),chat,r.away))
            event_msgs=process_player_match_events(chat,r.home,r.hs,r.ascore,r.scorers_home)+process_player_match_events(chat,r.away,r.ascore,r.hs,r.scorers_away)
            for event_msg in event_msgs: add_news(chat,event_msg)
            results.append(r)
        for r in results: add_news(chat,f'⚽ {r.home} {r.hs} — {r.ascore} {r.away}')
        managed=db('SELECT DISTINCT club FROM managers WHERE chat_id=? AND club IS NOT NULL',(chat,),True)
        for managed_row in managed:
            roll_random_club_event(chat,int(g['season']),md,managed_row['club'])
        max_md=db('SELECT MAX(md) AS m FROM fixtures WHERE chat_id=?',(chat,),True)[0]['m'] or md
        if md >= max_md:
            db('UPDATE games SET phase=\'season_complete\' WHERE chat_id=?',(chat,))
        else:
            db('UPDATE games SET matchday=matchday+1 WHERE chat_id=?',(chat,))
        return md,results

async def news(update,ctx,cb=False):
    chat=context_chat(update); rows=db('SELECT text FROM news WHERE chat_id=? ORDER BY id DESC LIMIT 10',(chat,),True); text='📰 НОВОСТИ\n\n'+'\n'.join(x['text'] for x in rows) if rows else '📰 Пока новостей нет.'
    if cb: await update.callback_query.edit_message_text(text,reply_markup=menu_for(update))
    else: await update.message.reply_text(text,reply_markup=menu_for(update))

async def tactics(update,ctx,cb=False):
    chat=context_chat(update); m=manager(chat,update.effective_user.id)
    if not m: text='Сначала вступи в карьеру.'; kb=menu_for(update)
    else:
        forms=['4-3-3','4-2-3-1','4-4-2','3-5-2','3-4-3','5-3-2']; styles=['Balanced','Possession','Pressing','Counter','Defensive']
        rows=[[InlineKeyboardButton(f,callback_data='formation:'+f) for f in forms[i:i+2]] for i in range(0,len(forms),2)]+[[InlineKeyboardButton(x,callback_data='style:'+x) for x in styles[i:i+2]] for i in range(0,len(styles),2)]
        text=f'🧠 ТАКТИКА\n\nСхема: {m["formation"]}\nСтиль: {m["style"]}'; kb=InlineKeyboardMarkup(rows)
    if cb: await update.callback_query.edit_message_text(text,reply_markup=kb)
    else: await update.message.reply_text(text,reply_markup=kb)

async def set_tactic(update,ctx):
    q=update.callback_query; await q.answer(); chat=context_chat(update); uid=q.from_user.id; m=manager(chat,uid)
    if not m:return
    if q.data.startswith('formation:'): db('UPDATE managers SET formation=? WHERE chat_id=? AND user_id=?',(q.data.split(':',1)[1],chat,uid))
    else: db('UPDATE managers SET style=? WHERE chat_id=? AND user_id=?',(q.data.split(':',1)[1],chat,uid))
    await tactics(update,ctx,True)

async def profile_ach(update,ctx):
    q=update.callback_query; a=achievements(q.from_user.id); await q.edit_message_text(f'🏆 ДОСТИЖЕНИЯ\n\nКубки: {a["cups"]}\nЧемпионства: {a["titles"]}\nЕврокубки: {a["europa"]}\nФиналы: {a["finals"]}\nСезонов: {a["seasons"]}',reply_markup=private_main_kb(q.from_user.id))

async def callbacks(update,ctx):
    q=update.callback_query
    if q.message.chat.type!='private':
        g=game(q.message.chat.id)
        if g and g['phase']!='lobby':
            await q.answer('Управление клубом — в личном чате; матчи — через отдельный бот.',show_alert=True)
            return
    if q.data=='profile_ach':
        await q.answer(); return await profile_ach(update,ctx)
    if q.data=='help':
        await q.answer(); return await help_menu(update,ctx,True)
    if q.data=='help:back':
        await q.answer()
        if q.message.chat.type=='private':
            p=profile(q.from_user.id); a=achievements(q.from_user.id)
            return await q.edit_message_text(f'⚽ TIME TO MANAGER 26/27\n\n👤 {p["nickname"] if p else q.from_user.first_name}\n\n🏆 Достижения\nКубки: {a["cups"]}\nЧемпионства: {a["titles"]}\nЕврокубки: {a["europa"]}\nСыграно сезонов: {a["seasons"]}',reply_markup=private_main_kb(q.from_user.id))
        return await q.edit_message_text(help_text(),reply_markup=help_kb())
    if q.data.startswith('help:'):
        await q.answer(); return await help_menu(update,ctx,True,q.data.split(':',1)[1])
    if q.data=='new_game_private': await q.answer('Новую игру можно создать только в группе.',show_alert=True); return
    if q.data=='join': return await join_game(update,ctx)
    if q.data=='finish_lobby': return await finish_lobby(update,ctx)
    if q.data=='pickclub': return await pick_club(update,ctx)
    if q.data=='randomclub': return await random_club(update,ctx)
    if q.data.startswith('takeclub:'): return await take_club(update,ctx)
    if q.data.startswith('lg:'): return await choose_league(update,ctx)
    if q.data.startswith('player:'):
        await q.answer(); return await player_view(update,ctx)
    if q.data.startswith('buy:'): return await buy_player(update,ctx)
    if q.data.startswith('list:'): return await list_player(update,ctx)
    if q.data.startswith('offer:'): return await decide_offer(update,ctx)
    if q.data.startswith('formation:') or q.data.startswith('style:'): return await set_tactic(update,ctx)
    await q.answer()
    mp={'career':career,'table':table,'squad':squad,'transfers':transfers,'news':news,'fixtures':fixtures,'board':board,'tactics':tactics,'medical':medical_command,'events':events_command}
    fn=mp.get(q.data)
    if fn:return await fn(update,ctx,True)

app=FastAPI(title='Time to Manager 26/27 API', version='1.0.0')

@app.get('/api/health')
async def api_health():
    return {'ok': True, 'service': 'time-to-manager-api', 'version': '1.0.0'}
@app.get('/')
async def index(): return FileResponse(WEB/'index.html')
@app.get('/app.js')
async def js(): return FileResponse(WEB/'app.js')
@app.get('/style.css')
async def css(): return FileResponse(WEB/'style.css')

def validate_init_data(init_data):
    if not init_data or not TOKEN:return {}
    data=dict(urllib.parse.parse_qsl(init_data,keep_blank_values=True)); received=data.pop('hash',None)
    if not received:return {}
    secret=hmac.new(b'WebAppData',TOKEN.encode(),hashlib.sha256).digest(); check='\n'.join(f'{k}={data[k]}' for k in sorted(data)); calc=hmac.new(secret,check.encode(),hashlib.sha256).hexdigest()
    return data if hmac.compare_digest(calc,received) else {}

def web_user(req):
    data=validate_init_data(req.headers.get('X-Telegram-Init-Data',''))
    if not data: raise HTTPException(401,'Invalid Telegram initData')
    return json.loads(data['user'])

def resolve_manager_chat(uid, chat_hint=0):
    if chat_hint:
        m=manager(chat_hint,uid)
        if m: return chat_hint,m
    rows=db('SELECT chat_id FROM managers WHERE user_id=? AND club IS NOT NULL ORDER BY rowid DESC',(uid,),True)
    for row in rows:
        m=manager(row['chat_id'],uid)
        if m: return row['chat_id'],m
    return int(chat_hint or 0),None

@app.get('/api/state')
async def api_state(request:Request):
    u=web_user(request); chat,m=resolve_manager_chat(int(u['id']),int(request.headers.get('X-Chat-Id','0')))
    if not m:return {'manager':None}
    rows=db('SELECT * FROM teams WHERE chat_id=? ORDER BY points DESC,(gf-ga) DESC,gf DESC,club',(chat,),True); ps=db('SELECT * FROM players WHERE chat_id=? AND club=? ORDER BY ovr DESC',(chat,m['club']),True); fx=db('SELECT * FROM fixtures WHERE chat_id=? AND (home=? OR away=?) ORDER BY md LIMIT 10',(chat,m['club'],m['club']),True)
    market=db('SELECT * FROM players WHERE chat_id=? AND club!=? ORDER BY value DESC LIMIT 100',(chat,m['club']),True)
    offers=db("SELECT o.id,o.player_id,o.from_club,o.to_club,o.fee,p.name FROM transfer_offers o JOIN players p ON p.chat_id=o.chat_id AND p.player_id=o.player_id WHERE o.chat_id=? AND o.from_club=? AND o.status='pending' ORDER BY o.id DESC LIMIT 20",(chat,m['club']),True)
    g=game(chat); season=int(g['season'])
    eu_teams={}
    for comp in ('ucl','uel','uecl'):
        eu_teams[comp]=[dict(x) for x in _europe_standings(chat,season,comp)]
    eu_fixtures=[dict(x) for x in db('SELECT * FROM europe_fixtures WHERE chat_id=? AND season=? ORDER BY round_no,competition,home',(chat,season),True)]
    eu_champions=[dict(x) for x in db('SELECT * FROM europe_champions WHERE chat_id=? AND season=?',(chat,season),True)]
    news_rows=db('SELECT text FROM news WHERE chat_id=? ORDER BY id DESC LIMIT 10',(chat,),True)
    return {'manager':dict(m),'game':dict(g),'chat_id':chat,'table':[dict(x) for x in rows],'players':[dict(x) for x in ps],'market':[dict(x) for x in market],'offers':[dict(x) for x in offers],'fixtures':[dict(x) for x in fx],'europe_teams':eu_teams,'europe_fixtures':eu_fixtures,'europe_champions':eu_champions,'news':[dict(x) for x in news_rows]}

@app.post('/api/match')
async def api_match(request:Request):
    u=web_user(request); chat,m=resolve_manager_chat(int(u['id']),int(request.headers.get('X-Chat-Id','0')))
    if not m: raise HTTPException(403,'No career')
    g=game(chat)
    if not g or g['phase'] not in ('active','lobby'): raise HTTPException(409,'Сейчас нельзя провести тур.')
    try:
        md,results=simulate(chat)
    except ValueError as e:
        raise HTTPException(409,str(e))
    own=[r for r in results if r.home==m['club'] or r.away==m['club']]
    return {'ok':True,'matchday':md,'results':[{'home':r.home,'away':r.away,'hs':r.hs,'ascore':r.ascore,'scorers_home':getattr(r,'scorers_home',[]),'scorers_away':getattr(r,'scorers_away',[])} for r in results],'own':([{'home':r.home,'away':r.away,'hs':r.hs,'ascore':r.ascore} for r in own]),'game':dict(game(chat))}

@app.post('/api/offer')
async def api_offer(request:Request):
    u=web_user(request); chat,m=resolve_manager_chat(int(u['id']),int(request.headers.get('X-Chat-Id','0')))
    if not m: raise HTTPException(403,'Сначала вступи в карьеру в Telegram.')
    payload=await request.json()
    try: pid=int(payload.get('player_id',0))
    except (TypeError,ValueError): raise HTTPException(400,'Некорректный ID игрока')
    players=db('SELECT * FROM players WHERE chat_id=? AND player_id=?',(chat,pid),True)
    if not players: raise HTTPException(404,'Игрок не найден')
    p=players[0]
    if p['club']==m['club']: raise HTTPException(400,'Это твой игрок')
    fee=int(p['value']*1.05)
    if int(m['money'])<fee: raise HTTPException(400,'Недостаточно средств для предложения')
    try:
        with transaction():
            if db("SELECT 1 FROM transfer_offers WHERE chat_id=? AND player_id=? AND to_club=? AND status='pending'",(chat,pid,m['club']),True): raise HTTPException(409,'Предложение уже отправлено')
            oid=db("INSERT INTO transfer_offers(chat_id,player_id,from_club,to_club,fee,source_user,status) VALUES(?,?,?,?,?,?,'pending')",(chat,pid,p['club'],m['club'],fee,int(u['id'])))
            add_news(chat,f'📨 {m["club"]} предложил €{fee:,} за {p["name"]}.')
    except sqlite3.IntegrityError: raise HTTPException(409,'Предложение уже отправлено')
    return {'ok':True,'offer_id':oid,'fee':fee,'status':'pending'}

@app.post('/api/offer/decision')
async def api_offer_decision(request:Request):
    u=web_user(request); chat,m=resolve_manager_chat(int(u['id']),int(request.headers.get('X-Chat-Id','0')))
    if not m: raise HTTPException(403,'Активная карьера не найдена')
    payload=await request.json()
    try: offer_id=int(payload.get('offer_id',0))
    except (TypeError,ValueError): raise HTTPException(400,'Некорректный ID предложения')
    decision=str(payload.get('decision',''))
    if decision not in ('accept','reject'): raise HTTPException(400,'Некорректное решение')
    offers=db("SELECT * FROM transfer_offers WHERE id=? AND chat_id=? AND from_club=? AND status='pending'",(offer_id,chat,m['club']),True)
    if not offers: raise HTTPException(404,'Предложение не найдено или уже обработано')
    offer=offers[0]
    if decision=='reject':
        db("UPDATE transfer_offers SET status='rejected' WHERE id=? AND status='pending'",(offer_id,))
        return {'ok':True,'status':'rejected'}
    with transaction():
        fresh=db("SELECT * FROM transfer_offers WHERE id=? AND chat_id=? AND from_club=? AND status='pending'",(offer_id,chat,m['club']),True)
        player=db('SELECT * FROM players WHERE chat_id=? AND player_id=?',(chat,offer['player_id']),True)
        buyer=db('SELECT * FROM managers WHERE chat_id=? AND club=?',(chat,offer['to_club']),True)
        if not fresh or not player or player[0]['club']!=offer['from_club'] or not buyer or buyer[0]['money']<offer['fee']:
            raise HTTPException(409,'Состав или бюджет изменился; предложение нельзя принять')
        db("UPDATE transfer_offers SET status='accepted' WHERE id=? AND status='pending'",(offer_id,))
        db('UPDATE players SET club=? WHERE chat_id=? AND player_id=? AND club=?',(offer['to_club'],chat,offer['player_id'],offer['from_club']))
        db('UPDATE managers SET money=money-? WHERE chat_id=? AND club=?',(offer['fee'],chat,offer['to_club']))
        db('UPDATE managers SET money=money+? WHERE chat_id=? AND club=?',(offer['fee'],chat,offer['from_club']))
        db('INSERT INTO transfers(chat_id,player_id,player_name,from_club,to_club,fee,kind) VALUES(?,?,?,?,?,?,?)',(chat,offer['player_id'],player[0]['name'],offer['from_club'],offer['to_club'],offer['fee'],'purchase'))
        add_news(chat,f'💼 {player[0]["name"]}: {offer["from_club"]} → {offer["to_club"]} за €{offer["fee"]:,}.')
    return {'ok':True,'status':'accepted'}

@app.post('/api/tactics')
async def api_tactics(request:Request):
    u=web_user(request); chat,m=resolve_manager_chat(int(u['id']),int(request.headers.get('X-Chat-Id','0')))
    if not m: raise HTTPException(403,'Сначала вступи в карьеру в Telegram.')
    payload=await request.json(); formation=str(payload.get('formation',m['formation'])); style=str(payload.get('style',m['style']))
    if formation not in ('4-3-3','4-2-3-1','4-4-2','3-5-2','3-4-3','5-3-2'): raise HTTPException(400,'Недопустимая схема')
    if style not in ('Balanced','Possession','Pressing','Counter','Defensive'): raise HTTPException(400,'Недопустимый стиль')
    db('UPDATE managers SET formation=?,style=? WHERE chat_id=? AND user_id=?',(formation,style,chat,int(u['id'])))
    return {'ok':True,'formation':formation,'style':style}

async def medical_command(update,ctx,cb=False):
    chat=context_chat(update); m=manager(chat,update.effective_user.id)
    if not m:
        text='У тебя нет активного клуба в этой карьере.'
        if cb: await update.callback_query.edit_message_text(text,reply_markup=menu_for(update))
        else: await update.message.reply_text(text)
        return
    players=db('SELECT name,pos,morale,form,fitness,injury_matches,suspension_matches,yellow_cards,red_cards FROM players WHERE chat_id=? AND club=? ORDER BY injury_matches DESC,suspension_matches DESC,morale ASC',(chat,m['club']),True)
    injured=[p for p in players if int(p['injury_matches'] or 0)>0]
    banned=[p for p in players if int(p['suspension_matches'] or 0)>0]
    low=[p for p in players if int(p['morale'] or 0)<45]
    lines=[f'🩺 МЕДШТАБ · {m["club"]}',f'Травмы: {len(injured)} · Дисквалификации: {len(banned)} · Низкая мораль: {len(low)}','']
    if injured:
        lines.append('🚑 ТРАВМЫ')
        lines.extend(f'• {p["name"]} — пропустит ещё {p["injury_matches"]} матч.' for p in injured)
    if banned:
        lines.append('⛔ ДИСКВАЛИФИКАЦИИ')
        lines.extend(f'• {p["name"]} — ещё {p["suspension_matches"]} матч. Жёлтые: {p["yellow_cards"]}; красные: {p["red_cards"]}' for p in banned)
    if low:
        lines.append('🧠 НИЗКАЯ МОРАЛЬ')
        lines.extend(f'• {p["name"]} — мораль {p["morale"]}/100' for p in low[:10])
    if not injured and not banned and not low: lines.append('Состав в хорошем состоянии.')
    text='\n'.join(lines)
    if cb: await update.callback_query.edit_message_text(text,reply_markup=menu_for(update))
    else: await update.message.reply_text(text)


async def events_command(update,ctx,cb=False):
    chat=context_chat(update); m=manager(chat,update.effective_user.id)
    if not m:
        text='У тебя нет активного клуба в этой карьере.'
        if cb: await update.callback_query.edit_message_text(text,reply_markup=menu_for(update))
        else: await update.message.reply_text(text)
        return
    rows=db('SELECT season,md,text,created_at FROM random_events WHERE chat_id=? AND club=? ORDER BY season DESC,md DESC,created_at DESC LIMIT 10',(chat,m['club']),True)
    if not rows:
        body='Случайных событий пока не было. Они могут появляться после игровых туров.'
    else:
        body='\n\n'.join(f'Сезон {r["season"]}, тур {r["md"]}\n{r["text"]}' for r in rows)
    text=f'🎲 СОБЫТИЯ КЛУБА · {m["club"]}\n\n{body}'
    if cb: await update.callback_query.edit_message_text(text,reply_markup=menu_for(update))
    else: await update.message.reply_text(text)


async def europe_command(update,ctx):
    chat=context_chat(update); g=game(chat)
    if not g:
        await update.message.reply_text('Сначала создай карьеру командой /newgame в группе.')
        return
    if not db('SELECT 1 FROM europe_teams WHERE chat_id=? AND season=? LIMIT 1',(chat,g['season']),True):
        create_european_season(chat,int(g['season']),False)
    rnd=int(g['europe_round'] or 1)
    labels={1:'Лига-этап · тур 1/8',2:'Лига-этап · тур 2/8',3:'Лига-этап · тур 3/8',4:'Лига-этап · тур 4/8',5:'Лига-этап · тур 5/8',6:'Лига-этап · тур 6/8',7:'Лига-этап · тур 7/8',8:'Лига-этап · тур 8/8',9:'Стыковые матчи',10:'1/8 финала',11:'Четвертьфиналы',12:'Полуфиналы',13:'Финалы'}
    chunks=[]
    for comp in ('ucl','uel','uecl'):
        rows=_europe_standings(chat,int(g['season']),comp)
        if not rows: continue
        top='\n'.join(f'{i}. {r["club"]} — {r["points"]} оч. ({r["gf"]}:{r["ga"]})' for i,r in enumerate(rows[:8],1))
        chunks.append(f'{EUROPE_NAMES[comp]}\n{top}')
    await update.message.reply_text(f'🌍 ЕВРОКУБКИ · {g["season_year"]}\nСледующий этап: {labels.get(rnd,"Сезон еврокубков завершён")}\n\n'+'\n\n'.join(chunks)+'\n\nЧтобы сыграть следующий еврокубковый раунд, открой бота матчей и нажми «🌍 Еврокубки».')


async def next_season_command(update,ctx):
    uid=update.effective_user.id
    if update.effective_chat.type!='private':
        await update.message.reply_text('Следующий сезон запускается в личном чате с ботом управления командой.')
        return
    chat=active_career_chat(uid); g=game(chat) if chat else None; m=manager(chat,uid) if chat else None
    if not g or not m:
        await update.message.reply_text('Активная карьера не найдена.'); return
    try: member=await ctx.bot.get_chat_member(chat_id=chat,user_id=uid)
    except Exception:
        await update.message.reply_text('Не удалось проверить права администратора в группе карьеры.'); return
    if member.status not in ('administrator','creator'):
        await update.message.reply_text('Только администратор карьеры может начать следующий сезон.'); return
    if g['phase']!='season_complete':
        await update.message.reply_text('Текущий сезон ещё не завершён.'); return
    europe_done=int(g['europe_round'] or 1)>13 and len(db('SELECT competition FROM europe_champions WHERE chat_id=? AND season=?',(chat,int(g['season'])),True))==3
    if not europe_done:
        await update.message.reply_text('Национальный чемпионат завершён, но еврокубки ещё не доиграны. Открой бота матчей командой /match в группе и заверши все 13 этапов Лиги чемпионов, Лиги Европы и Лиги конференций. Новый сезон пока не запускается, чтобы не потерять европейские матчи.')
        return
    if int(g['season'])>=int(g['max_seasons']):
        await update.message.reply_text('Карьера достигла лимита сезонов.'); return
    season=int(g['season'])+1; year_start=2026+season-1; season_year=f'{year_start}/{str(year_start+1)[-2:]}'
    try: backup_database('season')
    except Exception as exc: log.exception('Season backup failed: %s',exc); await update.message.reply_text('Не удалось создать резервную копию. Переход сезона отменён, попробуй позже.'); return
    with transaction():
        create_european_season(chat,season,True)
        db('INSERT OR IGNORE INTO fixture_history(chat_id,season,md,home,away,hs,ascore) SELECT chat_id,?,md,home,away,hs,ascore FROM fixtures WHERE chat_id=? AND played=1',(g['season'],chat))
        db('UPDATE teams SET played=0,won=0,draw=0,lost=0,gf=0,ga=0,points=0 WHERE chat_id=?',(chat,))
        db('UPDATE players SET age=CASE WHEN age IS NULL THEN NULL ELSE age+1 END,form=CAST(ROUND(form*0.35+68*0.65) AS INTEGER),morale=CAST(ROUND(morale*0.45+72*0.55) AS INTEGER),fitness=100,injured=0,suspended=0,injury_matches=0,suspension_matches=0,yellow_cards=0,red_cards=0 WHERE chat_id=?',(chat,))
        db('UPDATE managers SET wins=0,draws=0,losses=0,trust=MAX(35,trust-5) WHERE chat_id=?',(chat,))
        db('UPDATE achievements SET seasons=seasons+1 WHERE user_id IN (SELECT user_id FROM managers WHERE chat_id=?)',(chat,))
        db('UPDATE games SET season=?,season_year=?,phase=\'active\',matchday=1,europe_round=1 WHERE chat_id=?',(season,season_year,chat))
        create_full_calendar(chat); add_news(chat,f'📅 Начался сезон {season_year}. Предыдущий сезон сохранён в истории.')
    await update.message.reply_text(f'🏆 Начался сезон {season_year}. Календарь и таблица обновлены, история предыдущего сезона сохранена.')

def run_telegram():
    if not TOKEN:
        log.error('BOT_TOKEN is not set. Configure BOT_TOKEN in Bothost environment variables.')
        raise RuntimeError('BOT_TOKEN is not set')

    log.info('Telegram bot starting; token is present (length=%d).', len(TOKEN))
    if ENABLE_WEBAPP:
        web_thread=threading.Thread(target=lambda: uvicorn.run(app,host='0.0.0.0',port=PORT,log_level='info'),daemon=True,name='webapp-server')
        web_thread.start()
    application = Application.builder().token(TOKEN).build()
    management_commands={'career','table','squad','transfers','fixtures','tactics','medical','events'}
    for command, fn in [('start', start), ('help', help_command), ('ratings', ratings_command), ('newgame', newgame), ('career', career), ('table', table), ('squad', squad), ('transfers', transfers), ('fixtures', fixtures), ('tactics', tactics), ('europe', europe_command), ('medical', medical_command), ('events', events_command), ('nextseason', next_season_command)]:
        if command in management_commands:
            async def guarded(update, context, handler=fn):
                await guarded_management_command(update,context,handler)
            application.add_handler(CommandHandler(command, guarded))
        else:
            application.add_handler(CommandHandler(command, fn))
    async def safe_callbacks(update, context):
        try:
            await callbacks(update,context)
        except Exception as exc:
            log.exception('Callback failed for data=%s', getattr(getattr(update,'callback_query',None),'data',None))
            q=getattr(update,'callback_query',None)
            if q:
                try: await q.answer('Ошибка при открытии раздела. Ошибка записана в logs/bot.log.',show_alert=True)
                except Exception: pass
    application.add_handler(CallbackQueryHandler(safe_callbacks))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_nickname))
    log.info('Handlers registered. Starting Telegram polling...')
    application.run_polling(drop_pending_updates=False, allowed_updates=Update.ALL_TYPES)

def main():
    log.info('Starting Time to Manager 26/27...')
    log.info('BOT_TOKEN present: %s', bool(TOKEN))
    run_telegram()

if __name__ == '__main__':
    try:
        main()
    except Exception:
        log.exception('BOT PROCESS STOPPED')
        raise

