"""Dedicated group match bot. Shares the exact same SQLite database as bot.py.
Run as a separate service with MATCH_BOT_TOKEN and the same persistent project volume.
"""
import os, asyncio, logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler
import bot as core

TOKEN=(os.getenv('MATCH_BOT_TOKEN') or '').strip()
log=logging.getLogger('time_to_manager.matches')

def match_kb(md, er=1):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton('⚡ Быстрый счёт',callback_data=f'msim:quick:{md}'),InlineKeyboardButton('🎙 Обычный отчёт',callback_data=f'msim:normal:{md}')],
        [InlineKeyboardButton('📖 Подробный матч',callback_data=f'msim:detailed:{md}')],
        [InlineKeyboardButton('🌍 Еврокубки · сыграть раунд',callback_data=f'meuro:{er}')]
    ])

def europe_kb(er=1):
    return InlineKeyboardMarkup([[InlineKeyboardButton('🌍 Еврокубки · сыграть раунд',callback_data=f'meuro:{er}')]])

async def start(update,ctx):
    if update.effective_chat.type=='private':
        await update.message.reply_text('⚽ Бот матчей Time to Manager 26/27 работает в группах карьеры. Добавь его в группу, где создан сезон.')
        return
    g=core.game(update.effective_chat.id)
    if not g:
        await update.message.reply_text('Карьера не найдена. Сначала создай её через основной бот управления.')
        return
    if g['phase']=='season_complete':
        er=int(g['europe_round'] or 1)
        if er<=13:
            await update.message.reply_text(f'🏁 Национальный чемпионат {g["season_year"]} завершён. Еврокубки ещё продолжаются: этап {er}/13.',reply_markup=europe_kb(er))
        else:
            await update.message.reply_text(f'🏁 Сезон {g["season_year"]} завершён. Все еврокубки доиграны; можно начинать следующий сезон в основном боте.')
    else:
        await update.message.reply_text(f'⚽ MATCH CENTER · {g["season_year"]}\nТур: {g["matchday"]}\n\nЗапустить симуляцию может администратор группы.',reply_markup=match_kb(g['matchday'],int(g['europe_round'] or 1)))

async def match(update,ctx):
    if update.effective_chat.type=='private':
        await update.message.reply_text('Команда /match доступна только в группе карьеры.')
        return
    g=core.game(update.effective_chat.id)
    if not g:
        await update.message.reply_text('Сначала создай карьеру через основной бот.')
        return
    if g['phase']=='season_complete':
        er=int(g['europe_round'] or 1)
        if er<=13:
            await update.message.reply_text(f'🏁 Национальный чемпионат {g["season_year"]} завершён, но еврокубки ещё не доиграны. Сначала заверши европейский сезон: этап {er}/13.',reply_markup=europe_kb(er))
        else:
            await update.message.reply_text(f'🏁 Сезон {g["season_year"]} завершён вместе с еврокубками. Администратор может перейти к следующему сезону командой /nextseason в личном чате основного бота.')
        return
    await update.message.reply_text(f'⚽ ТУР {g["matchday"]}\nВыбери формат симуляции:',reply_markup=match_kb(g['matchday'],int(g['europe_round'] or 1)))

async def simulate_callback(update,ctx):
    q=update.callback_query; chat=q.message.chat.id
    if q.message.chat.type=='private':
        await q.answer('Матчи проводятся в групповой карьере.',show_alert=True); return
    try:
        member=await ctx.bot.get_chat_member(chat_id=chat,user_id=q.from_user.id)
    except Exception:
        await q.answer('Не удалось проверить права администратора.',show_alert=True); return
    if member.status not in ('administrator','creator'):
        await q.answer('Только администратор группы запускает тур.',show_alert=True); return
    is_europe=q.data.startswith('meuro:')
    if is_europe:
        requested=int(q.data.split(':')[1])
        try: rnd,eu_results,events=await asyncio.to_thread(core.simulate_europe,chat,requested)
        except ValueError as exc:
            await q.answer(str(exc),show_alert=True); return
        await q.answer('Еврокубковый раунд рассчитан')
        labels=core.EUROPE_NAMES
        body='\n'.join(f'{labels[c]}: {h} {hs}:{a} {away}' for c,h,hs,a,away in eu_results) or 'В этом этапе нет матчей.'
        if events: body+='\n\n'+'\n'.join(events[:12])
        g=core.game(chat)
        if not g:
            kb=None
        elif g['phase']=='season_complete':
            kb=europe_kb(int(g['europe_round'] or 1)) if int(g['europe_round'] or 1)<=13 else None
        else:
            kb=match_kb(g['matchday'],int(g['europe_round'] or 1))
        await q.edit_message_text(f'🌍 ЕВРОКУБКИ · ЭТАП {rnd}\n\n{body}\n\nСледующий этап: {int(g["europe_round"] or rnd+1) if g else rnd+1}',reply_markup=kb)
        return
    parts=q.data.split(':'); mode=parts[1]; requested=int(parts[2])
    try: md,results=await asyncio.to_thread(core.simulate,chat,requested)
    except ValueError as exc:
        await q.answer(str(exc),show_alert=True); return
    await q.answer('Тур рассчитан')
    if mode=='quick':
        body='\n'.join(f'{r.home} {r.hs}:{r.ascore} {r.away}' for r in results)
    elif mode=='normal':
        body='\n'.join(f'⚽ {r.home} {r.hs}:{r.ascore} {r.away}\nГолы: {", ".join(r.scorers_home) or "—"} | {", ".join(r.scorers_away) or "—"}' for r in results)
    else:
        lines=[]
        import random
        for r in results:
            names=[(r.home,n) for n in r.scorers_home]+[(r.away,n) for n in r.scorers_away]
            minutes=sorted(random.sample(range(4,90),k=len(names))) if names else []
            events=[f'{minute}′ ⚽ {name} — {club}' for minute,(club,name) in zip(minutes,names)]
            lines.append(f'🏟 {r.home} — {r.away}\n'+'\n'.join(events or ['Голы не забиты.'])+f'\nФИНАЛ: {r.hs}:{r.ascore}')
        body='\n\n'.join(lines)
    g=core.game(chat)
    if g and g['phase']=='season_complete':
        if int(g['europe_round'] or 1)<=13:
            body+='\n\n🏁 Национальный чемпионат завершён. Еврокубки ещё продолжаются — сыграй следующий европейский этап.'
            kb=europe_kb(int(g['europe_round'] or 1))
        else:
            body+='\n\n🏁 Сезон и еврокубки завершены. Администратор может выполнить /nextseason в личном чате основного бота.'
            kb=None
    else:
        kb=match_kb(g['matchday'],int(g['europe_round'] or 1)) if g else None
    await q.edit_message_text(f'⚽ РЕЗУЛЬТАТЫ · ТУР {md}\n\n{body}',reply_markup=kb)

async def table(update,ctx):
    if update.effective_chat.type=='private': return await update.message.reply_text('Таблица доступна в группе карьеры.')
    chat=update.effective_chat.id
    rows=core.db('SELECT * FROM teams WHERE chat_id=? ORDER BY points DESC,(gf-ga) DESC,gf DESC,club',(chat,),True)
    await update.message.reply_text('📊 ТАБЛИЦА\n\n'+'\n'.join(f'{i}. {r["club"]} — {r["points"]} оч. ({r["gf"]}:{r["ga"]})' for i,r in enumerate(rows,1)) or 'Нет данных.')

def main():
    if not TOKEN: raise RuntimeError('MATCH_BOT_TOKEN is not set')
    app=Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler('start',start)); app.add_handler(CommandHandler('match',match)); app.add_handler(CommandHandler('table',table)); app.add_handler(CommandHandler('europe',lambda update,ctx: update.message.reply_text('Открой /match и нажми кнопку «🌍 Еврокубки».'))); app.add_handler(CallbackQueryHandler(simulate_callback,pattern=r'^(msim:|meuro:)'))
    log.info('Dedicated match bot starting; token present.')
    app.run_polling(drop_pending_updates=False,allowed_updates=Update.ALL_TYPES)

if __name__=='__main__': main()
