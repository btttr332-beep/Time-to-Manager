import json
import logging
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DB_FILE = ROOT / 'data' / 'football_database.json'
LEAGUES_FILE = ROOT / 'data' / 'leagues.json'
RPL_SOURCE = 'rpl_estimated_status_results_2026_27'
OFFICIAL_SOURCES = {'EA SPORTS FC 27 official ratings export (snapshot 2026-09-12)', 'EA SPORTS FC 27 via FCCareer', 'EA SPORTS FC 26 via public EA ratings export'}
SUPPORTED_RATED = {'eng_pl', 'esp_laliga', 'ger_bundesliga', 'ita_a', 'fra_l1'}
log = logging.getLogger('time_to_manager.ratings')


class SquadProvider:
    """Local embedded database; rating data is bundled and startup stays offline."""
    def __init__(self):
        self.rating_import_error = None
        try:
            if os.getenv('RATINGS_IMPORT_ON_START', '').strip().lower() in {'1','true','yes'}:
                from tools.import_fc27_ratings import ensure_official_ratings
                report = ensure_official_ratings(log=lambda message: log.info('%s', message))
                log.info('Official rating import state: %s', report)
            else:
                log.info('Using embedded ratings by default; online import is disabled unless RATINGS_IMPORT_ON_START=1.')
        except Exception as exc:
            # Do not fabricate values if network/source access fails. The completeness
            # checks below prevent an unrated league from being selected for a new career.
            self.rating_import_error = str(exc)
            log.warning('Official FC27 ratings unavailable; no fallback ratings will be invented: %s', exc)
        self.database = json.loads(DB_FILE.read_text(encoding='utf-8'))
        self.leagues = json.loads(LEAGUES_FILE.read_text(encoding='utf-8'))['leagues']
        self.rating_status = self._build_rating_status()

    def _build_rating_status(self):
        status = {}
        for key, league in self.database.get('leagues', {}).items():
            if key not in SUPPORTED_RATED and key != 'rus_rpl':
                continue
            players = [p for team in league.get('teams', []) for p in team.get('players', [])]
            if key == 'rus_rpl':
                rated = [p for p in players if p.get('rating_source') == RPL_SOURCE and p.get('ovr') is not None and p.get('position_detail')]
            else:
                rated = [p for p in players if p.get('rating_source') in OFFICIAL_SOURCES and p.get('ovr') is not None and p.get('position_detail')]
            missing = [p for p in players if p not in rated]
            status[key] = {'total': len(players), 'rated': len(rated), 'missing': len(missing),
                           'complete': bool(players) and len(rated) == len(players),
                           'missing_names': [str(p.get('name') or 'Unknown') for p in missing[:20]]}
        return status

    def is_ratings_complete(self, key: str) -> bool:
        return bool(self.rating_status.get(key, {}).get('complete'))

    def load_league(self, key: str, force: bool = False) -> dict[str, Any]:
        if key not in self.database['leagues']:
            raise KeyError(f'Embedded league not found: {key}')
        return self.database['leagues'][key]

    def load(self, force: bool = False) -> dict[str, Any]:
        return self.database

    def refresh_all(self) -> dict[str, Any]:
        # Ratings are imported/cached during initialization; refresh stays offline.
        return self.database
