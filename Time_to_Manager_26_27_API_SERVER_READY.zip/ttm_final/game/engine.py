import random
from dataclasses import dataclass
import hashlib

VALID_RATING_SOURCES = {'EA SPORTS FC 27 official ratings export (snapshot 2026-09-12)', 'EA SPORTS FC 27 via FCCareer', 'EA SPORTS FC 26 via public EA ratings export', 'rpl_estimated_status_results_2026_27'}

POS_MAP = {'G':'GK','GK':'GK','D':'DF','DF':'DF','M':'MF','MF':'MF','F':'FW','FW':'FW',
           'CB':'DF','LB':'DF','RB':'DF','LWB':'DF','RWB':'DF',
           'CDM':'MF','CM':'MF','CAM':'MF','LM':'MF','RM':'MF',
           'LW':'FW','RW':'FW','CF':'FW','ST':'FW'}
STYLES = {'Balanced':0, 'Possession':1, 'Pressing':2, 'Counter':-1, 'Defensive':-2}
@dataclass
class MatchResult:
    home: str
    away: str
    hs: int
    ascore: int
    scorers_home: list
    scorers_away: list

class GameEngine:
    def __init__(self, db=None): self.db = db

    def player_ovr(self, p):
        p = dict(p)
        if p.get('rating_source') not in VALID_RATING_SOURCES:
            raise ValueError(f"Unverified rating source for {p.get('name', 'Unknown')}")
        value = p.get('ovr') if p.get('ovr') is not None else p.get('overall')
        if value is not None:
            try: return max(1, min(99, int(value)))
            except (TypeError, ValueError): pass
        # No invented OVR: the provider blocks new careers for leagues with missing ratings.
        raise ValueError(f"No confirmed player OVR available for {p.get('name', 'Unknown')}")

    def player_power(self, p):
        p = dict(p)
        o = self.player_ovr(p)
        morale = int(p.get('morale') if p.get('morale') is not None else 70)
        form = int(p.get('form') if p.get('form') is not None else 70)
        fit = int(p.get('fitness') if p.get('fitness') is not None else 80)
        return o + (morale-70)*0.10 + (form-70)*0.12 + (fit-80)*0.08

    def squad_power(self, players, formation='4-3-3', style='Balanced'):
        vals = sorted([self.player_power(dict(p)) for p in players if not dict(p).get('injured') and not dict(p).get('suspended')], reverse=True)[:11]
        if not vals: return 60
        return sum(vals)/len(vals) + STYLES.get(style, 0)*0.7

    def play(self, home, away, hp, ap, home_adv=2.5):
        diff = (hp + home_adv) - ap
        lam_h = max(.20, min(3.2, 1.35 + diff/18))
        lam_a = max(.15, min(2.8, 1.05 - diff/22))
        # Poisson sampling; capped for a plausible football score.
        def poisson(lam):
            limit = pow(2.718281828, -lam); k=0; prod=1.0
            while prod > limit and k < 10:
                k += 1; prod *= random.random()
            return min(7, max(0, k-1))
        hs, a = poisson(lam_h), poisson(lam_a)
        return MatchResult(home, away, hs, a, [], [])

    def game_value(self, age, pos, market_hint=None, ovr=68):
        if market_hint and market_hint > 0: return int(market_hint)
        age = age or 24
        base = max(150_000, int((max(25, ovr-40) ** 3) * 350))
        if age < 21: base = int(base * 1.25)
        elif age > 30: base = int(base * max(.35, 1 - (age-30)*.08))
        if pos == 'GK': base = int(base*.78)
        return max(100_000, base)

    def derive_attributes(self, p, club=None):
        # Accept only a sourced rating record. No fallback OVR/position is generated.
        name = str(p.get('name') or p.get('short_name') or 'Unknown')
        if p.get('rating_source') not in VALID_RATING_SOURCES:
            raise ValueError(f"Unverified rating source for {name}; refusing to invent OVR/position")
        detail_pos = str(p.get('position_detail') or p.get('position') or p.get('pos') or 'M').upper()
        pos_group = POS_MAP.get(detail_pos, POS_MAP.get(str(p.get('position') or p.get('pos') or 'M').upper(), 'MF'))
        # Store exact positions in the players table for display (e.g. CAM, RWB).
        pos = detail_pos if detail_pos in POS_MAP else pos_group
        age = p.get('age')
        digest = hashlib.sha256(f'{club or ""}:{name}'.encode('utf-8')).digest()
        supplied_ovr = p.get('ovr') if p.get('ovr') is not None else p.get('overall')
        if supplied_ovr is None:
            raise ValueError(f"No confirmed OVR available for {name}; refusing to invent one")
        try: ovr = max(1, min(99, int(supplied_ovr)))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Invalid sourced OVR for {name}: {supplied_ovr!r}") from exc
        supplied_potential = p.get('potential')
        if supplied_potential is not None:
            try: potential = max(ovr, min(99, int(supplied_potential)))
            except (TypeError, ValueError): supplied_potential = None
        if supplied_potential is None:
            # Do not invent potential. Preserve an unknown value as None.
            potential = None
        value = self.game_value(age, pos_group, p.get('market_value'), ovr)
        form = p.get('form') if p.get('form') is not None else 60 + digest[1] % 31
        morale = p.get('morale') if p.get('morale') is not None else 60 + digest[2] % 31
        fitness = p.get('fitness') if p.get('fitness') is not None else 75 + digest[3] % 26
        return {**p, 'pos':pos, 'ovr':int(ovr), 'potential':int(potential) if potential is not None else None, 'value':int(value),
                'rating_source':p.get('rating_source'),
                'salary':max(1000, int(value*.012)), 'form':int(form), 'morale':int(morale), 'fitness':int(fitness)}
