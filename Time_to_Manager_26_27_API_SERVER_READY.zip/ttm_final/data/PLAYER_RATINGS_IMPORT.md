# Player ratings and positions — offline embedded source

The project bundles the EA SPORTS FC 27 player export at `data/ea_fc27_players.csv` (snapshot **2026-09-12**, 19,789 total records; 17,849 men's football records). The full official export is embedded alongside the already-built game database; no network fetch or separate import is needed at runtime.

## Embedded coverage

| League | Players | Sourced OVR + detailed position |
|---|---:|---:|
| Premier League | 612 | 612 (EA FC 27) |
| LaLiga | 548 | 548 (EA FC 27) |
| Bundesliga | 548 | 548 (EA FC 27) |
| Serie A | 578 | 578 (EA FC 27) |
| Ligue 1 | 500 | 500 (EA FC 27) |
| Russian Premier League | 279 | 279 (custom estimates; max 81) |

The five EA leagues contain **2,786 official FC 27 ratings and specific positions**. Primary positions and published player attributes are copied from the source export, matched by the stable EA player ID. The project does not generate replacement OVRs for these leagues.

**RPL:** EA FC 27 does not include the Russian Premier League. Its 279 players retain separately labelled game estimates based on club status, player role and results, capped at OVR 81 as requested. They must not be described as official EA ratings.

The source export does not provide potential or market values; potential is left unknown instead of invented. The game may calculate economy values for gameplay, which are not official Transfermarkt valuations.

## Validate

Run `python tools/import_fc27_ratings.py` from the project root to refresh the embedded official attributes from the bundled CSV and generate `data/ratings_audit_2026-10-04.json`. It is fully offline and is not required to start the bot. `data/ratings_audit_2026-10-04.json` lists coverage and per-club totals.
