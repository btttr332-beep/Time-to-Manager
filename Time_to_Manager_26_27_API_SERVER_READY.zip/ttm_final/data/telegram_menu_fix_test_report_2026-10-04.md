# Telegram menu and onboarding regression report — 2026-10-04

## Fixed
- Root cause: callback dispatcher referenced undefined `match` while building its route map. This raised `NameError` before the requested menu handler could be selected, so buttons such as Squad appeared not to respond.
- Added callback exception handling that logs failures and displays an alert instead of leaving the client waiting.
- Before career activation, the private menu has only Achievements and Hints. Active career menu includes Career, Squad, Transfers, Calendar, Table, Tactics, Board, News, Medical, Events, Achievements and Hints.
- Career launch DMs contain realistic estimated transfer budget, squad value, average OVR, morale, form, fitness, availability, objective/trust and first fixture.
- New player market-value estimates and club transfer budgets were recalibrated.

## Test results
- Python compilation: passed (`bot.py`, `match_bot.py`, `game/engine.py`, `game/provider.py`).
- Menu test: passed; pre-career menu only exposes Hints/Achievements.
- Callback test: passed; dispatcher responded for every active menu button.
- Career-start DM test: passed; a private report and active menu are sent to the manager.
- Budget test: passed; budget is derived from squad value and league tier, bounded from €1m to €250m.
- Full simulation regression: passed two complete domestic seasons, 3 European competitions through all 13 stages, event persistence, duplicate-callback rejection and season gate.
- Season gate regression: passed.

## Scope limitation
Live Telegram polling and token delivery cannot be verified in this offline test environment. The test harness used Telegram API stubs while exercising real project callbacks, database logic and match simulation.
