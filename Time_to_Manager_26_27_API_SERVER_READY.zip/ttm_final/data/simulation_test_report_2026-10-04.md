# Simulation regression test report — 2026-10-04

## Automated scenario

- Created an isolated SQLite career using embedded Premier League club/player data.
- Simulated a full 20-club domestic season: 380 fixtures across 38 matchdays.
- Checked every club played 38 matches; wins/draws/losses sum to 38; league wins equal losses; total goals for equal total goals against; points match 3/1/0 scoring.
- Simulated all 13 stages in the Champions League, Europa League and Conference League: 36 clubs per competition, 18 fixtures in each of eight league-phase rounds, followed by play-offs, round of 16, quarter-finals, semi-finals and finals.
- Confirmed one champion is recorded for each of the three competitions.
- Simulated the transition to 2027/28 and a second complete domestic season and all three European competitions.
- Confirmed the new domestic calendar contains 380 unplayed fixtures, the previous season's 380 results are stored in history, the league table resets, and the new European season has 36 clubs in each competition.
- Confirmed player form, morale and fitness remain in their configured ranges; match events produced injuries, suspensions and card counters during the simulation; random events were stored.
- Confirmed duplicate domestic-match and European-round requests are rejected.
- Added a regression test for the season gate: after the domestic season ends, the match center still offers the next European round, and `/nextseason` is blocked until all three European champions are recorded and the European round counter has passed the final.

## Checks

- Python syntax compilation passed for `bot.py`, `match_bot.py`, `game/engine.py`, and `tools/merge_fc27_full_export.py`.
- `node --check web/app.js` passed.
- Core simulations used the real SQLite database layer, embedded data provider and match engine in an isolated test database. Telegram classes were stubbed for UI/control-flow tests; live Telegram polling, actual bot tokens, deployment networking and mobile Telegram Web App authentication were not tested.

## Scope note

The European access list is a playable simplified allocation, not a full recreation of UEFA coefficients and every national cup allocation rule. The simulation is not a proof that every possible career state is bug-free.
