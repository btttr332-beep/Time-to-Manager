# Embedded football data

`football_database.json` is the runtime database. `ea_fc27_players.csv` is the full supplied EA SPORTS FC 27 ratings export (snapshot 2026-09-12) included for source transparency and local validation.

Coverage in the playable leagues:

- Premier League: 20 clubs, 612 players, all with official FC 27 OVR and exact primary position.
- LaLiga: 20 clubs, 548 players, all with official FC 27 OVR and exact primary position.
- Bundesliga: 18 clubs, 548 players, all with official FC 27 OVR and exact primary position.
- Serie A: 20 clubs, 578 players, all with official FC 27 OVR and exact primary position.
- Ligue 1: 18 clubs, 500 players, all with official FC 27 OVR and exact primary position.
- Russian Premier League: 16 clubs, 279 players, with separately labelled estimated ratings capped at 81.

Official OVRs/positions for the five EA leagues are imported by stable EA player ID, not inferred from player names. RPL estimates are the only non-official ratings and are explicitly marked in the database. Potential and market value are not part of the supplied EA export; the game does not claim its calculated gameplay economy values are official market valuations.

See `ratings_audit_2026-10-04.json` for the machine-readable validation report and `RPL_RATING_METHODOLOGY.md` for the RPL policy.
