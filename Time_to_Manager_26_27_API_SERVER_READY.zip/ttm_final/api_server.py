"""Standalone API/WebApp server for Time to Manager 26/27.

Run: python -m uvicorn api_server:app --host 0.0.0.0 --port 8000
"""
from bot import app

__all__ = ["app"]
