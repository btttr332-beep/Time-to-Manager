# Audit fixes — 2026-10-04

## Implemented

- Club assignment uses a fresh system-random shuffle for each career, prevents duplicate club assignments, and rejects more managers than available clubs.
- League creation bulk-inserts club/player records, pre-generates the complete calendar, logs its runtime, and creates unique player IDs even when embedded source IDs collide.
- The round-robin generator creates both halves with reversed home/away fixtures.
- Match simulation is wrapped in a SQLite write transaction and lock; stale callbacks and repeat simulations are rejected, and manager W/D/L counters are updated with the table.
- Transfer purchases create offers instead of instantly moving players. The selling manager must accept; player movement, budgets, history and news are committed in one transaction.
- Added a dedicated `match_bot.py` process using the same configurable SQLite path as the manager bot.
- Manager controls are routed from private chat to the user's active career; active career groups are reserved for the match bot.
- The Web App server starts alongside the manager bot; Web App state, squad, market, incoming offers, transfer offer creation/acceptance, tactics save and calendar views are wired to the shared database.
- Added five-season rollover mechanics, season history, a new calendar and table reset; the rollover first creates a SQLite backup.
- Added duplicate-ID migration for existing career saves, WAL/busy timeout, pending-offer uniqueness, and data-quality reports.

## Complete embedded ratings data

- Bundled the user's supplied EA SPORTS FC 27 CSV snapshot (2026-09-12) as `data/ea_fc27_players.csv`.
- Refreshed **2,786** player records in the five EA leagues directly from the local CSV using stable EA player IDs. All 2,786 have a sourced OVR and detailed primary position; published attributes are included where present in the source.
- RPL contains **279** separately labelled estimates based on club status/results/role; all have a detailed position and OVR no higher than 81.
- No official rating or position is fabricated. Potential and market value are not present in the provided FC 27 export and are not falsely labelled as official.
- Added `data/ratings_audit_2026-10-04.json` with per-league/player coverage.
- Startup remains offline; the database is already embedded, and the local CSV is included for reproducibility.

## Validation

- Python syntax compilation: `bot.py`, `match_bot.py`, `game/engine.py`, `game/provider.py`, and rating tools.
- JavaScript syntax check: `web/app.js`.
- JSON parsing for all `data/*.json` files.
- All five official leagues: 2,786/2,786 records have OVR and a detailed position sourced from the supplied EA FC 27 CSV; all EA player IDs resolve and OVR/position values match the source.
- RPL: 279/279 records have OVR and detailed positions; maximum OVR is 81.
- Full calendar invariants and transfer/Web App smoke tests are documented in the audit history.

## Added career systems — 2026-10-04

- Added three continental competitions: Champions League, Europa League and Conference League, each with 36 unique clubs, an eight-round league phase, 9–24 play-offs, round of 16, quarter-finals, semi-finals and a final.
- European qualification is generated at the start of a career using the selected league's squad-strength ranking, then uses the completed domestic table for subsequent seasons. Clubs are not duplicated across the three competitions.
- Added European fixtures, standings and champion history to SQLite; added `/europe` and a Web App tab with standings, results and winners. Match bot now has a dedicated European-round action.
- Added injury duration, suspension duration, yellow/red-card counters and migration for existing saves. Match events can create injuries and bans; unavailable players are excluded from squad strength until their counters expire.
- Morale and form respond to results and goals; fitness decreases for regular starters and recovers for unused players. These attributes feed the existing player-strength calculation.
- Added `/medical` plus a Web App medical-staff view. Continental champions earn club money and manager reputation/trust, with achievements updated idempotently.
- Added integration smoke tests with a temporary SQLite database: 36 clubs and 18 league-phase fixtures per competition; 54 European fixtures simulated per league-phase round; complete path through all 13 rounds generated 3 champions; domestic simulation updated the table once and changed morale.

## Remaining feature work

Domestic national cups, promotion/relegation and live Telegram polling still require separate implementation/verification. Telegram bot tokens and the live Telegram connection were not available in this environment, so live deployment was not tested.

## Realistic form and random events upgrade — 2026-10-04
- Replaced result-only form swings with a rolling form model based on estimated individual match performance, goals, clean sheets, team result, and small performance variance.
- Players who do not feature drift gradually toward neutral form rather than receiving the same result-based boost/penalty as starters.
- Fitness now responds to minutes/load: starters lose more fitness, unused players recover, and low fitness can affect morale. Form, morale and fitness continue to influence simulated squad strength.
- Reduced baseline card and match-injury probabilities to avoid excessive suspensions/injuries.
- Added nine persistent random off-pitch events after league matchdays: young-player breakthrough, training fatigue, fan support, media pressure, sponsor income, dressing-room conflict, training injury, recovery session, and board bonus.
- Random events apply real changes to player form/morale/fitness/availability or club money/trust and are written to news plus a persistent event-history table.
- Added `/events` to view the club's latest random events. New fields/tables are created by safe SQLite migrations; existing careers are preserved.
- At season rollover, form and morale now regress toward realistic preseason baselines instead of being hard-reset to identical values; fitness fully recovers.


## Season progression guard — 2026-10-04

- The match center keeps a dedicated European-round button available after the domestic league finishes, so the final league match cannot strand unfinished continental competitions.
- `/nextseason` now refuses to advance until all three continental competitions have reached round 13 and recorded their champions.
- Fixed SQLite `Row` access in match-center European-round navigation; use indexed row access rather than `.get()`.
- Regression test: two complete 20-team domestic seasons, all three 36-team European competitions through their finals, random events, duplicate callbacks, and the end-of-season gate.

## Telegram menu and career onboarding fix — 2026-10-04

- Fixed the root cause of unresponsive inline-menu buttons: the callback dispatcher constructed a handler map containing an undefined `match` function, raising `NameError` before any menu route could execute. Match simulation remains the responsibility of `match_bot.py`.
- Added safe callback error handling: unexpected callback exceptions are logged to `logs/bot.log` and surfaced to the user instead of leaving the Telegram button spinner indefinitely.
- Before a manager owns a club, the private main menu now contains only **Achievements** and **Hints**. After career activation it switches to the career-management menu.
- Career start now sends each manager an immediate private club report with league/season, transfer budget, squad market value, average OVR, average morale/form/fitness, squad availability, board trust/objective and first fixture.
- Transfer budgets are now estimated from actual squad value and league tier instead of giving every club the same default €100m. Player market-value estimation was recalibrated for more plausible new careers.
- Added callback tests for every active menu section, private career-report delivery, pre-career menu visibility, full two-season domestic simulation, all three European cups, and season-progression guards.
